"""Windows clipboard monitor for URLs copied while a browser is active."""

import asyncio
import ctypes
import os
import re
import urllib.parse


_URL_RE = re.compile(r"^https?://[^\s]+$", re.IGNORECASE)
_BROWSER_EXES = {
    "firefox.exe", "waterfox.exe", "chrome.exe", "msedge.exe",
    "brave.exe", "opera.exe", "vivaldi.exe", "librewolf.exe",
}

_user32 = ctypes.windll.user32 if os.name == "nt" else None
_kernel32 = ctypes.windll.kernel32 if os.name == "nt" else None


def _foreground_window_info():
    if not _user32 or not _kernel32:
        return "", ""
    hwnd = _user32.GetForegroundWindow()
    if not hwnd:
        return "", ""

    title_buf = ctypes.create_unicode_buffer(512)
    _user32.GetWindowTextW(hwnd, title_buf, len(title_buf))

    pid = ctypes.c_ulong()
    _user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    if not pid.value:
        return title_buf.value, ""

    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    handle = _kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid.value)
    if not handle:
        return title_buf.value, ""
    try:
        path_buf = ctypes.create_unicode_buffer(1024)
        size = ctypes.c_ulong(len(path_buf))
        if _kernel32.QueryFullProcessImageNameW(handle, 0, path_buf, ctypes.byref(size)):
            return title_buf.value, os.path.basename(path_buf.value).lower()
    finally:
        _kernel32.CloseHandle(handle)
    return title_buf.value, ""


def _read_clipboard():
    if not _user32:
        return ""
    CF_UNICODETEXT = 13
    GMEM_MOVEABLE = 0x0002
    if not _user32.OpenClipboard(None):
        return ""
    try:
        handle = _user32.GetClipboardData(CF_UNICODETEXT)
        if not handle:
            return ""
        ptr = _kernel32.GlobalLock(handle)
        if not ptr:
            return ""
        try:
            return ctypes.wstring_at(ptr)
        finally:
            _kernel32.GlobalUnlock(handle)
    finally:
        _user32.CloseClipboard()


def _is_valid_url(value: str) -> bool:
    value = value.strip()
    if len(value) > 8192 or not _URL_RE.match(value):
        return False
    try:
        parsed = urllib.parse.urlparse(value)
        return bool(parsed.scheme in ("http", "https") and parsed.netloc)
    except Exception:
        return False


async def monitor_clipboard(connections):
    """Broadcast newly copied URLs from an active browser.

    This intentionally runs on Windows only.  The browser title check prevents
    the monitor from injecting a URL while the Stash DLP page itself is the
    active browser tab/window.
    """
    if os.name != "nt":
        return

    last_clipboard = None
    while True:
        try:
            title, exe = _foreground_window_info()
            if exe in _BROWSER_EXES and "stash dlp" not in title.lower():
                text = _read_clipboard().strip()
                if text and text != last_clipboard and _is_valid_url(text):
                    last_clipboard = text
                    await connections.broadcast({"type": "clipboard_url", "url": text})
                elif text != last_clipboard:
                    # Remember non-URL clipboard contents too, so a later
                    # focus change does not repeatedly inject the same URL.
                    last_clipboard = text
            else:
                # Keep tracking clipboard changes even while outside a browser.
                # This avoids replaying an old URL when the user returns to a browser.
                text = _read_clipboard().strip()
                if text != last_clipboard:
                    last_clipboard = text
        except Exception:
            pass
        await asyncio.sleep(0.5)
