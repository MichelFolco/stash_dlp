// Stash DLP Web — ported from stash_dlp.py's YtdlpManagerApp.
// State machine (READY / EDITING / FETCHING / INTERCEPTING) and app_mode
// (DOWNLOAD / SEARCH_HISTORY) mirror the desktop app; URLs are pasted
// manually into the input field rather than auto-read from the
// clipboard, and window-chrome pieces differ due to browser sandboxing.

// The server's snapshot endpoints (GET /api/jobs, refresh, folder-change,
// folder-change, etc.) all return newest-first. We want the Map's own
// insertion order to be true chronological (oldest→newest) always -
// consistent whether jobs arrive via an initial snapshot or one at a
// time via job_added - so sorting logic elsewhere can just trust Map
// order without needing to know which case it came from.
function loadJobsIntoMap(jobsArray) {
  state.jobs.clear();
  for (const job of [...jobsArray].reverse()) state.jobs.set(job.filename, job);
}

const el = (id) => document.getElementById(id);
const navToggleBtn = el("nav-toggle-btn");
const navTray = el("nav-tray");
const folderControlsToggleBtn = el("folder-controls-toggle-btn");

// Folder controls (save/target folder row) are pinned to always show,
// even with the nav tray closed/hidden, when this is on. Purely a
// client-side display preference, so it's kept in localStorage rather
// than synced to the server like the other tray toggles.
let folderControlsPinned = false;
let navTrayPersistedOpen = false;
try {
  folderControlsPinned = localStorage.getItem("stashdlp_folder_controls_pinned") === "1";
  navTrayPersistedOpen = localStorage.getItem("stashdlp_nav_tray_open") === "1";
} catch (err) { /* localStorage unavailable (e.g. privacy mode) - fall back to defaults */ }

// "Manage External Programs" and "Open With..." only make sense on the
// machine actually running the server (that's where the programs and
// the screen to show them on live) - same reasoning as the folder
// browse buttons and Open in Explorer, which the backend already
// localhost-gates. We mirror that here on the client using the
// hostname the browser used to reach the server, so remote (e.g.
// Tailscale) sessions see the options as disabled with an explanation
// rather than have them silently fail server-side.
const IS_LOCAL = ["127.0.0.1", "localhost", "::1"].includes(window.location.hostname);
const REMOTE_ONLY_TOOLTIP = "Only available when browsing from the same machine as the server.";

const state = {
  appMode: "DOWNLOAD",
  encodeModalFilename: null,
  current: "READY",
  targetUrl: "",
  stagedUrl: "",
  tagDomain: true,
  m3uSniffer: false,
  autoM3uRetry: true,
  autoConfirmTitles: false,
  clipboardMonitor: false,
  detectRenames: true,
  titlePrefix: "",
  titlePrefixEnabled: false,
  ytdlpDefaultArgs: "",
  ytdlpDomainArgs: {},
  ytdlpDomainOrder: [],
  sessionJobFilenames: new Set(),
  jobs: new Map(),
  saveDirPath: "",
  historyEntries: [],
  ws: null,
  saveDirRoots: [],
  targetDirRoots: [],
  externalPrograms: [],
  filterText: "",
  audioOnlyFilter: false,
  sessionOnlyFilter: false,
  statusFilters: new Set(),
  sortField: "added",
  sortDir: "desc",
  selectionMode: false,
  selectedFilenames: new Set(),
  renderedCards: new Map(),
  renderedCardSigs: new Map(),
  encodeJobs: new Map(),
  playlistBatchFiles: new Set(),
  encodeCapabilities: null,
  encodeSourceInfo: null,
  encodeEstimateSeq: 0,
  encodeProbeSeq: 0,
  clipboardUrl: "",
};

const inputField = el("input-field");
const downloadSubmitBtn = el("download-submit-btn");
const cancelPlaylistBtn = el("cancel-playlist-btn");
const app = el("app");
const queueList = el("queue-list");
const gearBtn = el("gear-btn");
const logoImg = el("logo");
const dlModeBtn = el("dl-mode-btn");
const historyModeBtn = el("history-mode-btn");
const modeContainer = el("mode-container");
const resDropdown = el("res-dropdown");
const ctxVersion = el("ctx-version");
const ctxSaveDir = el("ctx-save-dir");
const ctxChangeFolder = el("ctx-change-folder");
const jobMenu = el("job-menu");
const historyMenu = el("history-menu");
const folderModal = el("folder-modal");
const stashMenuFlyout = el("stash-menu-flyout");
const stashStatusBtn = el("stash-status-btn");
const stashImportModal = el("stash-import-modal");
const stashImportInput = el("stash-import-input");
const stashImportError = el("stash-import-error");
const stashTagModal = el("stash-tag-modal");
const stashTagInput = el("stash-tag-input");
const stashTagError = el("stash-tag-error");
const stashTagResultsModal = el("stash-tag-results-modal");
const stashTagResultsTitle = el("stash-tag-results-title");
const stashTagResultsList = el("stash-tag-results-list");
const stashTagRecentWrap = el("stash-tag-recent-wrap");
const stashTagRecentList = el("stash-tag-recent-list");
const folderInput = el("folder-input");
const folderError = el("folder-error");
const folderRecentWrap = el("folder-recent-wrap");
const folderRecentList = el("folder-recent-list");
const ctxTargetDir = el("ctx-target-dir");
const folderStatusRow = el("folder-status-row");
const folderStatusSave = el("folder-status-save");
const folderStatusTarget = el("folder-status-target");
const targetFolderModalEl = el("target-folder-modal");
const dlFolderQuickMenu = el("dl-folder-quickmenu");
const dlFolderQuickList = el("dl-folder-quickmenu-list");
const targetFolderQuickMenu = el("target-folder-quickmenu");
const targetFolderQuickList = el("target-folder-quickmenu-list");
const reencodeChoiceModal = el("reencode-choice-modal");
const reencodeChoiceFilename = el("reencode-choice-filename");
const reencodeChoiceOriginalSize = el("reencode-choice-original-size");
const reencodeChoiceOriginalRes = el("reencode-choice-original-res");
const reencodeChoiceReencodedSize = el("reencode-choice-reencoded-size");
const reencodeChoiceReencodedRes = el("reencode-choice-reencoded-res");
const reencodeChoiceCancelBtn = el("reencode-choice-cancel-btn");
const reencodeChoiceOriginalBtn = el("reencode-choice-original-btn");
const reencodeChoiceReencodedBtn = el("reencode-choice-reencoded-btn");
const reencodeChoiceTitle = el("reencode-choice-title");
const reencodeChoiceReencodedLabel = el("reencode-choice-reencoded-label");
const videoModal = el("video-modal");
const videoPlayer = el("video-player");
const videoModalTitle = el("video-modal-title");
const audioPlayerWrap = el("audio-player-wrap");
const audioPlayer = el("audio-player");
const syncAudioModal = el("sync-audio-modal");
const syncAudioPlayer = el("sync-audio-player");
const syncAudioTitle = el("sync-audio-title");
const syncAudioFilename = el("sync-audio-filename");
const syncAudioStageBadge = el("sync-audio-stage-badge");
const syncAudioDelayInput = el("sync-audio-delay-input");
const syncAudioClipDurationInput = el("sync-audio-clip-duration-input");
const syncAudioStatus = el("sync-audio-status");
const syncAudioPrimaryBtn = el("sync-audio-primary-btn");
const syncAudioRedoClipBtn = el("sync-audio-redo-clip-btn");
const syncAudioConfirmBtn = el("sync-audio-confirm-btn");
const syncAudioDiscardBtn = el("sync-audio-discard-btn");
const syncAudioAcceptBtn = el("sync-audio-accept-btn");
const syncAudioCancelBtn = el("sync-audio-cancel-btn");
const openWithFlyout = el("open-with-flyout");
const openWithProgramsList = el("open-with-programs-list");
const copyFlyout = el("copy-flyout");
const fileFlyout = el("file-flyout");
const externalProgramsModal = el("external-programs-modal");
const externalProgramsList = el("external-programs-list");
const programFormModal = el("program-form-modal");
const programFormTitle = el("program-form-title");
const programNameInput = el("program-name-input");
const programPathInput = el("program-path-input");
const programArgsInput = el("program-args-input");
const programFormError = el("program-form-error");
const programDeleteBtn = el("program-delete-btn");
const urlArgsBtn = el("url-args-btn");
const urlArgsFlyout = el("url-args-flyout");
const urlArgsDomainLabel = el("url-args-domain-label");
const urlArgsQuickInput = el("url-args-quick-input");
const ytdlpArgsModal = el("ytdlp-args-modal");
const ytdlpDefaultArgsInput = el("ytdlp-default-args-input");
const ytdlpDefaultArgsError = el("ytdlp-default-args-error");
const ytdlpDomainArgsList = el("ytdlp-domain-args-list");
const ytdlpDomainArgsFormModal = el("ytdlp-domain-args-form-modal");
const ytdlpDomainArgsFormTitle = el("ytdlp-domain-args-form-title");
const ytdlpDomainInput = el("ytdlp-domain-input");
const ytdlpDomainArgsInput = el("ytdlp-domain-args-input");
const ytdlpDomainArgsFormError = el("ytdlp-domain-args-form-error");
const ytdlpDomainArgsDeleteBtn = el("ytdlp-domain-args-delete-btn");

function openStashImportModal() {
  stashImportError.classList.add("hidden");
  stashImportError.textContent = "";
  stashImportInput.value = "";
  stashImportModal.classList.remove("hidden");
  setTimeout(() => stashImportInput.focus(), 0);
}

function closeStashImportModal() {
  stashImportModal.classList.add("hidden");
}

async function importFromStash() {
  const scene = stashImportInput.value.trim();
  if (!scene) {
    stashImportError.textContent = "Enter a Stash scene URL or scene ID.";
    stashImportError.classList.remove("hidden");
    return;
  }
  const btn = el("stash-import-btn-confirm");
  btn.disabled = true;
  btn.textContent = "Importing...";
  stashImportError.classList.add("hidden");
  try {
    const res = await fetch("/api/import/stash", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ scene }),
    });
    const data = await res.json();
    if (!res.ok) {
      stashImportError.textContent = data.error || "Import failed.";
      stashImportError.classList.remove("hidden");
      return;
    }
    if (data.job) state.jobs.set(data.job.filename, data.job);
    renderLedger();
    closeStashImportModal();
    flashStatus(`Imported from Stash: ${data.job.filename}`);
  } catch (e) {
    stashImportError.textContent = "Couldn't reach the server.";
    stashImportError.classList.remove("hidden");
  } finally {
    btn.disabled = false;
    btn.textContent = "Import";
  }
}

el("stash-import-cancel-btn").addEventListener("click", closeStashImportModal);
el("stash-import-btn-confirm").addEventListener("click", importFromStash);
stashImportInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") importFromStash();
  else if (e.key === "Escape") closeStashImportModal();
});

// ── Stash menu (Stash button -> Import from Stash / Check Tag) ──
function openStashMenuFlyout() {
  if (!stashMenuFlyout.classList.contains("hidden")) {
    stashMenuFlyout.classList.add("hidden");
    return;
  }
  closeOtherFlyouts(stashMenuFlyout);
  positionDropdownBelow(stashMenuFlyout, inputField);
}
stashStatusBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  openStashMenuFlyout();
});
el("stash-menu-import").addEventListener("click", () => {
  stashMenuFlyout.classList.add("hidden");
  openStashImportModal();
});
el("stash-menu-check-tag").addEventListener("click", () => {
  stashMenuFlyout.classList.add("hidden");
  openStashTagModal();
});
el("stash-menu-largest-files").addEventListener("click", () => {
  stashMenuFlyout.classList.add("hidden");
  openStashLargestFiles();
});

function openStashTagModal() {
  stashTagError.classList.add("hidden");
  stashTagError.textContent = "";
  stashTagInput.value = "";
  stashTagModal.classList.remove("hidden");
  setTimeout(() => stashTagInput.focus(), 0);
  refreshStashTagRecent();
}

function renderStashTagRecent(tags) {
  stashTagRecentList.innerHTML = "";
  if (!tags || tags.length === 0) {
    stashTagRecentWrap.classList.add("hidden");
    return;
  }
  stashTagRecentWrap.classList.remove("hidden");
  for (const tag of tags) {
    const chip = document.createElement("div");
    chip.className = "stash-tag-chip";
    chip.textContent = tag;
    chip.title = tag;
    chip.addEventListener("click", () => {
      stashTagInput.value = tag;
      checkStashTag();
    });
    stashTagRecentList.appendChild(chip);
  }
}

async function refreshStashTagRecent() {
  try {
    const res = await fetch("/api/stash/recent-tags");
    if (!res.ok) return;
    const data = await res.json();
    renderStashTagRecent(data.recent_tags);
  } catch (e) {
    // Non-critical - just skip showing the recent-tags chips this time.
  }
}

function closeStashTagModal() {
  stashTagModal.classList.add("hidden");
}

async function checkStashTag() {
  const tag = stashTagInput.value.trim();
  if (!tag) {
    stashTagError.textContent = "Enter a Stash tag name.";
    stashTagError.classList.remove("hidden");
    return;
  }
  const btn = el("stash-tag-btn-confirm");
  btn.disabled = true;
  btn.textContent = "Checking...";
  stashTagError.classList.add("hidden");
  try {
    const res = await fetch("/api/stash/check-tag", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ tag }),
    });
    const data = await res.json();
    if (!res.ok) {
      stashTagError.textContent = data.error || "Check failed.";
      stashTagError.classList.remove("hidden");
      return;
    }
    closeStashTagModal();
    openStashTagResultsModal(data);
  } catch (e) {
    stashTagError.textContent = "Couldn't reach the server.";
    stashTagError.classList.remove("hidden");
  } finally {
    btn.disabled = false;
    btn.textContent = "Check";
  }
}

el("stash-tag-cancel-btn").addEventListener("click", closeStashTagModal);
el("stash-tag-btn-confirm").addEventListener("click", checkStashTag);
stashTagInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") checkStashTag();
  else if (e.key === "Escape") closeStashTagModal();
});

let currentStashTagCheck = null; // { id, name } of the most recently checked tag, for tagging imports

function openStashScenesResultsModal(title, scenes, tagContext, emptyMessage) {
  currentStashTagCheck = tagContext;
  stashTagResultsTitle.textContent = title;
  stashTagResultsList.innerHTML = "";

  if (!scenes || scenes.length === 0) {
    const empty = document.createElement("div");
    empty.className = "program-empty-note";
    empty.textContent = emptyMessage || "No scenes found.";
    stashTagResultsList.appendChild(empty);
  } else {
    for (const scene of scenes) {
      const row = document.createElement("div");
      row.className = "stash-scene-row";

      const info = document.createElement("div");
      info.className = "stash-scene-row-info";
      const titleEl = document.createElement("div");
      titleEl.className = "stash-scene-row-title";
      titleEl.textContent = scene.title;
      const pathEl = document.createElement("div");
      pathEl.className = "stash-scene-row-path";
      pathEl.textContent = scene.path || scene.url;
      pathEl.title = scene.path || scene.url;
      info.appendChild(titleEl);
      info.appendChild(pathEl);
      if (scene.size_label) {
        const sizeEl = document.createElement("div");
        sizeEl.className = "stash-scene-row-size";
        sizeEl.textContent = scene.size_label;
        info.appendChild(sizeEl);
      }

      const btnGroup = document.createElement("div");
      btnGroup.className = "stash-scene-row-btns";

      const openBtn = document.createElement("button");
      openBtn.className = "stash-scene-open-btn";
      openBtn.textContent = "Open";
      openBtn.addEventListener("click", () => window.open(scene.url, "_blank"));

      const importBtn = document.createElement("button");
      importBtn.className = "stash-scene-open-btn stash-scene-import-btn";
      importBtn.textContent = "Import";
      importBtn.addEventListener("click", () => importStashSceneFromResults(scene, importBtn));

      btnGroup.appendChild(openBtn);
      btnGroup.appendChild(importBtn);

      row.appendChild(info);
      row.appendChild(btnGroup);
      stashTagResultsList.appendChild(row);
    }
  }

  stashTagResultsModal.classList.remove("hidden");
}

function openStashTagResultsModal(data) {
  openStashScenesResultsModal(
    `Scenes tagged "${data.tag_name}" (${data.count})`,
    data.scenes,
    { id: data.tag_id, name: data.tag_name },
    "No scenes found with this tag."
  );
}

async function openStashLargestFiles() {
  try {
    const res = await fetch("/api/stash/largest-files");
    const data = await res.json();
    if (!res.ok) {
      flashStatus(data.error || "Couldn't load largest files.");
      return;
    }
    openStashScenesResultsModal(
      `50 Largest Files (${data.count})`,
      data.scenes,
      null,
      "No scenes found."
    );
  } catch (e) {
    flashStatus("Couldn't reach the server.");
  }
}

async function importStashSceneFromAddressBar(sceneUrl) {
  inputField.disabled = true;
  const previousPlaceholder = inputField.placeholder;
  inputField.value = "Importing Stash scene...";
  try {
    const res = await fetch("/api/import/stash", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ scene: sceneUrl }),
    });
    const data = await res.json();
    if (!res.ok) {
      inputField.value = "";
      inputField.placeholder = data.error || "Stash import failed.";
      setTimeout(() => { inputField.placeholder = previousPlaceholder; }, 3000);
      inputField.disabled = false;
      inputField.focus();
      return;
    }
    if (data.job) state.jobs.set(data.job.filename, data.job);
    renderLedger();
    flashStatus(`Imported from Stash: ${data.job.filename}`);
    resetToReady();
  } catch (e) {
    inputField.value = "";
    inputField.placeholder = "Couldn't reach Stash.";
    setTimeout(() => { inputField.placeholder = previousPlaceholder; }, 3000);
    inputField.disabled = false;
    inputField.focus();
  }
}

async function importStashSceneFromResults(scene, btn) {
  btn.disabled = true;
  btn.textContent = "Importing...";
  try {
    const res = await fetch("/api/import/stash", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        scene: scene.id,
        tag_id: currentStashTagCheck?.id || null,
        tag_name: currentStashTagCheck?.name || null,
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      btn.disabled = false;
      btn.textContent = "Import";
      flashStatus(data.error || "Import failed.");
      return;
    }
    if (data.job) state.jobs.set(data.job.filename, data.job);
    renderLedger();
    btn.textContent = "Imported";
    flashStatus(`Imported from Stash: ${data.job.filename}`);
  } catch (e) {
    btn.disabled = false;
    btn.textContent = "Import";
    flashStatus("Couldn't reach the server.");
  }
}

function closeStashTagResultsModal() {
  stashTagResultsModal.classList.add("hidden");
}

el("stash-tag-results-close-btn").addEventListener("click", closeStashTagResultsModal);
stashTagResultsModal.addEventListener("click", (e) => {
  if (e.target === stashTagResultsModal) closeStashTagResultsModal();
});

// ── Boot ──────────────────────────────────────────────────────
async function boot() {
  await refreshVersion();
  await refreshSaveDir();
  await refreshTargetDir();
  await refreshExternalPrograms();
  await refreshDownloadPrefs();
  await refreshYtdlpArgs();
  updateUrlArgsChip();
  await loadJobsSnapshot();
  await loadEncodeJobsSnapshot();
  connectWebSocket();
  applyLocalOnlyUI();
  inputField.setPlaceholderText = null; // n/a, kept for readability
  inputField.placeholder = "Paste a link, then press ENTER...";
  inputField.focus();
  refreshStashStatus();
  setInterval(refreshStashStatus, 30000);
}

// Polls Stash's reachability so the Stash button in the top row only
// shows up when Stash is actually running - avoids a dead button that
// just errors out on every click when Stash is off.
// True while a Stash server answers. Stash-related UI (tray button, Settings
// "Stash" section, its tray-list row) is shown only while this is true.
let stashRunning = false;

async function refreshStashStatus() {
  try {
    const res = await fetch("/api/stash/status");
    const data = await res.json();
    stashRunning = !!data.running;
  } catch (e) {
    stashRunning = false;
  }
  stashStatusBtn.classList.toggle("hidden", !stashRunning);
  applySettingsStashVisibility();
}

// Static for the life of the page (IS_LOCAL doesn't change at runtime),
// so this just needs to run once at boot rather than on every menu open.
function applyLocalOnlyUI() {
  if (IS_LOCAL) return;
  for (const id of ["ctx-open-with", "flyout-manage-programs", "ctx-history-open-location"]) {
    const item = el(id);
    item.classList.add("ctx-disabled");
    item.title = REMOTE_ONLY_TOOLTIP;
  }
  for (const id of ["encode-source-browse-btn", "open-converted-btn", "ctx-manage-programs"]) {
    const btn = el(id);
    btn.disabled = true;
    btn.title = REMOTE_ONLY_TOOLTIP;
  }
}

async function refreshExternalPrograms() {
  try {
    const res = await fetch("/api/external-programs");
    const data = await res.json();
    state.externalPrograms = data.programs || [];
  } catch (e) {
    state.externalPrograms = [];
  }
}

async function refreshDownloadPrefs() {
  try {
    const res = await fetch("/api/download-prefs");
    const data = await res.json();
    // Download resolution is intentionally session-scoped: always start
    // at the conservative 480p cap, regardless of the previous setting.
    resDropdown.value = "480p";
    if (data.quality !== "480p") saveDownloadPrefs();
    state.tagDomain = data.tag_domain !== false;
    state.m3uSniffer = !!data.m3u_sniffer;
    state.autoM3uRetry = data.auto_m3u_retry !== false;
    state.autoConfirmTitles = !!data.auto_confirm_titles;
    state.clipboardMonitor = !!data.clipboard_monitor;
    state.detectRenames = data.detect_renames !== false;
    state.titlePrefix = data.title_prefix || "";
    state.titlePrefixEnabled = !!data.title_prefix_enabled;
  } catch (e) {
    // Backend unreachable at boot - just keep the hard-coded defaults
    // already baked into the HTML/state.
  }
  // Auto-download (Clipboard Monitoring) is safety-sensitive - it should
  // never come back on by itself, so every app start forces it off
  // regardless of what was last saved. If it had been left on, persist
  // the change too, so a stale saved "on" doesn't reappear next boot.
  if (state.clipboardMonitor) {
    state.clipboardMonitor = false;
    saveDownloadPrefs();
  }
  syncPrefControls();
}

async function refreshYtdlpArgs() {
  try {
    const res = await fetch("/api/ytdlp-args");
    const data = await res.json();
    state.ytdlpDefaultArgs = data.default_args || "";
    state.ytdlpDomainArgs = data.domain_args || {};
    state.ytdlpDomainOrder = data.domain_order || Object.keys(state.ytdlpDomainArgs);
  } catch (e) {
    // Backend unreachable at boot - keep empty defaults, not worth
    // surfacing an error over what's a purely optional feature.
  }
}

// Mirrors backend get_domain() (ytdlp_utils.py) closely enough for a
// pure client-side lookup key: strip a www/www2/m subdomain, take the
// first label. Doesn't need to be byte-identical to the Python version
// since it's only ever used to look up state.ytdlpDomainArgs (already
// fetched from the server) for the chip's lit/unlit state - the
// authoritative save/apply path always goes back through the backend.
function getDomainClientSide(url) {
  try {
    const host = new URL(url.trim()).hostname || "";
    return host.replace(/^(www\d?|m)\./, "").split(".")[0];
  } catch (e) {
    return "";
  }
}

function updateUrlArgsChip() {
  const domain = getDomainClientSide(inputField.value);
  if (!domain) {
    urlArgsBtn.classList.remove("active");
    urlArgsBtn.title = "Paste a URL to set yt-dlp args for that site";
    return;
  }
  const args = state.ytdlpDomainArgs[domain] || "";
  urlArgsBtn.classList.toggle("active", !!args);
  urlArgsBtn.title = args
    ? `Custom yt-dlp args for "${domain}": ${args}`
    : `No custom yt-dlp args for "${domain}" yet - click to add`;
}

inputField.addEventListener("input", updateUrlArgsChip);

urlArgsBtn.addEventListener("click", () => {
  if (!urlArgsFlyout.classList.contains("hidden")) {
    urlArgsFlyout.classList.add("hidden");
    return;
  }
  const domain = getDomainClientSide(inputField.value);
  urlArgsFlyout.dataset.domain = domain;
  if (!domain) {
    urlArgsDomainLabel.textContent = "Paste a URL first";
    urlArgsQuickInput.value = "";
    urlArgsQuickInput.disabled = true;
  } else {
    urlArgsDomainLabel.textContent = `Args for "${domain}"`;
    urlArgsQuickInput.value = state.ytdlpDomainArgs[domain] || "";
    urlArgsQuickInput.disabled = false;
  }
  closeOtherFlyouts(urlArgsFlyout);
  positionFlyoutNextTo(urlArgsFlyout, urlArgsBtn);
});

async function saveUrlArgsQuick() {
  const domain = urlArgsFlyout.dataset.domain;
  if (!domain) return;
  try {
    const res = await fetch("/api/ytdlp-args/domain", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ domain, args: urlArgsQuickInput.value }),
    });
    const data = await res.json();
    if (!res.ok) { flashStatus(data.error || "Couldn't save args."); return; }
    state.ytdlpDefaultArgs = data.default_args || "";
    state.ytdlpDomainArgs = data.domain_args || {};
    state.ytdlpDomainOrder = data.domain_order || Object.keys(state.ytdlpDomainArgs);
    updateUrlArgsChip();
    urlArgsFlyout.classList.add("hidden");
    flashStatus(`Saved yt-dlp args for "${domain}"`);
  } catch (e) {
    flashStatus("Couldn't reach the server to save args.");
  }
}
el("url-args-quick-save").addEventListener("click", saveUrlArgsQuick);
urlArgsQuickInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") saveUrlArgsQuick();
});

el("url-args-manage-all").addEventListener("click", () => {
  urlArgsFlyout.classList.add("hidden");
  openYtdlpArgsModal();
});

// ── yt-dlp args management modal (default args + per-domain list) ──
function openYtdlpArgsModal() {
  ytdlpDefaultArgsInput.value = state.ytdlpDefaultArgs;
  ytdlpDefaultArgsError.classList.add("hidden");
  renderYtdlpDomainArgsList();
  ytdlpArgsModal.classList.remove("hidden");
}

function closeYtdlpArgsModal() {
  ytdlpArgsModal.classList.add("hidden");
}

function renderYtdlpDomainArgsList() {
  ytdlpDomainArgsList.innerHTML = "";
  const storedOrder = Array.isArray(state.ytdlpDomainOrder) ? state.ytdlpDomainOrder : [];
  const domains = [
    ...storedOrder.filter((domain) => Object.prototype.hasOwnProperty.call(state.ytdlpDomainArgs, domain)),
    ...Object.keys(state.ytdlpDomainArgs).filter((domain) => !storedOrder.includes(domain)),
  ];
  if (domains.length === 0) {
    const empty = document.createElement("div");
    empty.className = "program-empty-note";
    empty.textContent = "No site-specific rules added yet.";
    ytdlpDomainArgsList.appendChild(empty);
    return;
  }
  for (const domain of domains) {
    const row = document.createElement("div");
    row.className = "program-row";

    const info = document.createElement("div");
    info.className = "program-row-info";
    const nameEl = document.createElement("div");
    nameEl.className = "program-row-name";
    nameEl.textContent = domain;
    const argsEl = document.createElement("div");
    argsEl.className = "program-row-path";
    argsEl.textContent = state.ytdlpDomainArgs[domain];
    argsEl.title = state.ytdlpDomainArgs[domain];
    info.appendChild(nameEl);
    info.appendChild(argsEl);

    const controls = document.createElement("div");
    controls.className = "ytdlp-rule-controls";

    const upBtn = document.createElement("button");
    upBtn.className = "program-edit-btn ytdlp-rule-move";
    upBtn.textContent = "↑";
    upBtn.title = "Move up";
    upBtn.disabled = domains.indexOf(domain) === 0;
    upBtn.addEventListener("click", () => reorderYtdlpDomainArgs(domain, -1));

    const downBtn = document.createElement("button");
    downBtn.className = "program-edit-btn ytdlp-rule-move";
    downBtn.textContent = "↓";
    downBtn.title = "Move down";
    downBtn.disabled = domains.indexOf(domain) === domains.length - 1;
    downBtn.addEventListener("click", () => reorderYtdlpDomainArgs(domain, 1));

    const editBtn = document.createElement("button");
    editBtn.className = "program-edit-btn";
    editBtn.textContent = "Edit";
    editBtn.addEventListener("click", () => openYtdlpDomainArgsForm(domain));

    controls.appendChild(upBtn);
    controls.appendChild(downBtn);
    controls.appendChild(editBtn);
    row.appendChild(info);
    row.appendChild(controls);
    ytdlpDomainArgsList.appendChild(row);
  }
}

async function reorderYtdlpDomainArgs(domain, direction) {
  try {
    const res = await fetch("/api/ytdlp-args/domain/reorder", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ domain, direction }),
    });
    const data = await res.json();
    if (!res.ok) {
      window.alert(data.error || "Couldn't reorder that rule.");
      return;
    }
    state.ytdlpDefaultArgs = data.default_args || "";
    state.ytdlpDomainArgs = data.domain_args || {};
    state.ytdlpDomainOrder = data.domain_order || Object.keys(state.ytdlpDomainArgs);
    renderYtdlpDomainArgsList();
  } catch (e) {
    window.alert("Couldn't reach the server to reorder that rule.");
  }
}

el("add-ytdlp-domain-args-btn").addEventListener("click", () => openYtdlpDomainArgsForm(null));
el("ytdlp-args-close-btn").addEventListener("click", closeYtdlpArgsModal);
ytdlpArgsModal.addEventListener("click", (e) => {
  if (e.target === ytdlpArgsModal) closeYtdlpArgsModal();
});

async function saveYtdlpDefaultArgs() {
  try {
    const res = await fetch("/api/ytdlp-args/default", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ args: ytdlpDefaultArgsInput.value }),
    });
    const data = await res.json();
    if (!res.ok) {
      ytdlpDefaultArgsError.textContent = data.error || "Unknown error";
      ytdlpDefaultArgsError.classList.remove("hidden");
      return;
    }
    state.ytdlpDefaultArgs = data.default_args || "";
    state.ytdlpDomainArgs = data.domain_args || {};
    ytdlpDefaultArgsError.classList.add("hidden");
  } catch (e) {
    ytdlpDefaultArgsError.textContent = "Couldn't reach the server.";
    ytdlpDefaultArgsError.classList.remove("hidden");
  }
}
ytdlpDefaultArgsInput.addEventListener("change", saveYtdlpDefaultArgs);

let editingYtdlpDomain = null;

function openYtdlpDomainArgsForm(domain) {
  editingYtdlpDomain = domain;
  ytdlpDomainArgsFormTitle.textContent = domain ? "Edit Site Rule" : "Add Site Rule";
  ytdlpDomainInput.value = domain || "";
  // Domain is the storage key - don't let an edit rename it out from
  // under state.ytdlpDomainArgs; delete + re-add covers that instead.
  ytdlpDomainInput.disabled = !!domain;
  ytdlpDomainArgsInput.value = domain ? (state.ytdlpDomainArgs[domain] || "") : "";
  ytdlpDomainArgsFormError.classList.add("hidden");
  ytdlpDomainArgsDeleteBtn.classList.toggle("hidden", !domain);
  ytdlpDomainArgsFormModal.classList.remove("hidden");
  (domain ? ytdlpDomainArgsInput : ytdlpDomainInput).focus();
}

function closeYtdlpDomainArgsForm() {
  ytdlpDomainArgsFormModal.classList.add("hidden");
  editingYtdlpDomain = null;
  ytdlpDomainInput.disabled = false;
}

function showYtdlpDomainArgsFormError(message) {
  ytdlpDomainArgsFormError.textContent = message;
  ytdlpDomainArgsFormError.classList.remove("hidden");
}

el("ytdlp-domain-args-form-cancel-btn").addEventListener("click", closeYtdlpDomainArgsForm);
ytdlpDomainArgsFormModal.addEventListener("click", (e) => {
  if (e.target === ytdlpDomainArgsFormModal) closeYtdlpDomainArgsForm();
});

async function saveYtdlpDomainArgsForm() {
  const domain = ytdlpDomainInput.value.trim();
  const args = ytdlpDomainArgsInput.value;
  if (!domain) { showYtdlpDomainArgsFormError("Domain can't be empty."); return; }
  try {
    const res = await fetch("/api/ytdlp-args/domain", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ domain, args }),
    });
    const data = await res.json();
    if (!res.ok) { showYtdlpDomainArgsFormError(data.error || "Unknown error"); return; }
    state.ytdlpDefaultArgs = data.default_args || "";
    state.ytdlpDomainArgs = data.domain_args || {};
    state.ytdlpDomainOrder = data.domain_order || Object.keys(state.ytdlpDomainArgs);
    renderYtdlpDomainArgsList();
    updateUrlArgsChip();
    closeYtdlpDomainArgsForm();
  } catch (e) {
    showYtdlpDomainArgsFormError("Couldn't reach the server to save that rule.");
  }
}
el("ytdlp-domain-args-form-save-btn").addEventListener("click", saveYtdlpDomainArgsForm);

el("ytdlp-domain-args-delete-btn").addEventListener("click", async () => {
  if (!editingYtdlpDomain) return;
  if (!window.confirm(`Remove the yt-dlp args rule for "${editingYtdlpDomain}"?`)) return;
  try {
    const res = await fetch("/api/ytdlp-args/domain/delete", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ domain: editingYtdlpDomain }),
    });
    const data = await res.json();
    if (!res.ok) { showYtdlpDomainArgsFormError(data.error || "Unknown error"); return; }
    state.ytdlpDefaultArgs = data.default_args || "";
    state.ytdlpDomainArgs = data.domain_args || {};
    state.ytdlpDomainOrder = data.domain_order || Object.keys(state.ytdlpDomainArgs);
    renderYtdlpDomainArgsList();
    updateUrlArgsChip();
    closeYtdlpDomainArgsForm();
  } catch (e) {
    showYtdlpDomainArgsFormError("Couldn't reach the server to delete that rule.");
  }
});

function saveDownloadPrefs() {
  return fetch("/api/download-prefs", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      quality: resDropdown.value,
      tag_domain: state.tagDomain,
      m3u_sniffer: state.m3uSniffer,
      auto_m3u_retry: state.autoM3uRetry,
      auto_confirm_titles: state.autoConfirmTitles,
      clipboard_monitor: state.clipboardMonitor,
      detect_renames: state.detectRenames,
      title_prefix: state.titlePrefix,
      title_prefix_enabled: state.titlePrefixEnabled,
    }),
  }).then((res) => {
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    reportSaved(true);
  }).catch(() => reportSaved(false));
}

async function refreshSaveDir() {
  try {
    const res = await fetch("/api/settings");
    const data = await res.json();
    setSaveDirDisplay(data.save_dir, data.free_space);
    state.saveDirRoots = data.roots || [];
  } catch (e) {
    ctxSaveDir.querySelector(".ctx-folder-path").textContent = "(unavailable)";
    ctxSaveDir.querySelector("#ctx-save-free").textContent = "";
    folderStatusSave.querySelector(".folder-status-path").textContent = "(unavailable)";
    folderStatusSave.title = "";
  }
}

function setSaveDirDisplay(path, freeSpace) {
  const { compact, tooltip } = compactFolderDisplay(path, freeSpace);
  ctxSaveDir.querySelector(".ctx-folder-path").textContent = path ? compact : "(unavailable)";
  ctxSaveDir.querySelector("#ctx-save-free").textContent = "";
  ctxSaveDir.title = tooltip;

  state.saveDirPath = path || "";

  folderStatusSave.querySelector(".folder-status-path").textContent = path ? compact : "(unavailable)";
  folderStatusSave.title = tooltip;
}

// Builds a display-only full path for a job's file. Not used for any
// file operation - just so the card can show where the file lives (or
// would land, if it's still downloading/pending) without a server
// round-trip. Matches whichever separator style the folder path
// already uses, so it doesn't look out of place on Windows vs. *nix.
function joinDisplayPath(dir, filename, ext) {
  if (!dir) return filename;
  const sep = dir.includes("\\") ? "\\" : "/";
  const trimmedDir = dir.replace(/[\\/]+$/, "");
  const name = ext ? `${filename}.${ext.toLowerCase()}` : filename;
  return `${trimmedDir}${sep}${name}`;
}

// Long folder paths (a GitHub-cloned project several levels deep, a
// user profile with a long name, etc.) otherwise either overflow the
// toolbar/menu or get silently clipped by CSS ellipsis from whichever
// end happens to overflow first - neither shows the one thing that
// actually identifies the folder day-to-day: which drive it's on and
// what it's actually named. This collapses the middle instead, e.g.
// "C:\Users\Phil\Documents\GitHub\project\downloads" -> "C:\...\downloads",
// and folds the already-available free-space label in alongside it
// rather than as a separate element, e.g. "C:\...\downloads (123.3 GB free)".
// The full, uncollapsed path is always still available via the
// tooltip/title attribute wherever this is used.
function compactFolderDisplay(path, freeSpaceLabel) {
  if (!path) return { compact: "", tooltip: "" };
  const sep = path.includes("\\") ? "\\" : "/";
  const trimmed = path.replace(/[\\/]+$/, "");
  const segments = trimmed.split(/[\\/]+/).filter(Boolean);

  let drive = "";
  let rest = segments;
  if (/^[a-zA-Z]:$/.test(segments[0] || "")) {
    // Windows drive letter, e.g. "C:" - anchor on it and treat
    // everything after as the collapsible middle.
    drive = segments[0];
    rest = segments.slice(1);
  }
  // No drive letter (*nix/network path) just leaves drive "" - the
  // leading separator itself (from path.startsWith(sep)) still reads
  // fine as the "root" in the collapsed form, e.g. "/.../outputs".

  const lastFolder = rest[rest.length - 1] || "";
  const compactPath = rest.length <= 1 ? trimmed : `${drive}${sep}...${sep}${lastFolder}`;

  // free_space labels already carry their own drive prefix (see
  // diskspace.get_free_space_label, e.g. "C: 123.3 GB free") - strip
  // that off here since the collapsed path already shows the drive,
  // so it isn't repeated twice in something like "C:\...\downloads (C: 123.3 GB free)".
  let freeSuffix = freeSpaceLabel || "";
  if (drive) {
    freeSuffix = freeSuffix.replace(new RegExp(`^${drive}\\s*`, "i"), "");
  }

  return {
    compact: freeSuffix ? `${compactPath} (${freeSuffix})` : compactPath,
    tooltip: path,
  };
}

async function refreshTargetDir() {
  try {
    const res = await fetch("/api/target-settings");
    const data = await res.json();
    setTargetDirDisplay(data.target_dir, data.free_space);
    state.targetDirRoots = data.roots || [];
  } catch (e) {
    ctxTargetDir.querySelector(".ctx-folder-path").textContent = "(unavailable)";
    ctxTargetDir.querySelector("#ctx-target-free").textContent = "";
    folderStatusTarget.querySelector(".folder-status-path").textContent = "(unavailable)";
    folderStatusTarget.title = "";
  }
}

function setTargetDirDisplay(path, freeSpace) {
  const pathEl = ctxTargetDir.querySelector(".ctx-folder-path");
  const freeEl = ctxTargetDir.querySelector("#ctx-target-free");
  if (!path) {
    pathEl.textContent = "(none set)";
    freeEl.textContent = "";
    folderStatusTarget.querySelector(".folder-status-path").textContent = "(none set)";
    folderStatusTarget.title = "";
  } else {
    const { compact, tooltip } = compactFolderDisplay(path, freeSpace);
    pathEl.textContent = compact;
    freeEl.textContent = "";
    folderStatusTarget.querySelector(".folder-status-path").textContent = compact;
    folderStatusTarget.title = tooltip;
  }
  ctxTargetDir.title = path || "";
}

function applyVersionState(data) {
  let text = data.version ? `yt-dlp v${data.version}` : "yt-dlp version unknown";
  if (data.version && data.just_updated) text += " (just updated)";
  ctxVersion.textContent = text;
  return text;
}

async function refreshVersion() {
  try {
    const res = await fetch("/api/version");
    const data = await res.json();
    applyVersionState(data);
  } catch (e) {
    ctxVersion.textContent = "yt-dlp version unknown";
  }
}

// Clicking the logo shows the app's own version (stash_dlp, not yt-dlp -
// see ctxVersion/refreshVersion above for that). Source of truth is
// APP_VERSION in backend/config.py via /api/app_version.
logoImg.addEventListener("click", async () => {
  try {
    const res = await fetch("/api/app_version");
    const data = await res.json();
    flashStatus(data.version ? `stash_dlp v${data.version}` : "stash_dlp version unknown");
  } catch (e) {
    flashStatus("stash_dlp version unknown");
  }
});

async function loadJobsSnapshot() {
  try {
    const res = await fetch("/api/jobs");
    const jobs = await res.json();
    loadJobsIntoMap(jobs);
    renderLedger();
  } catch (e) {
    // backend not reachable yet; ignore
  }
}


// ── WebSocket ─────────────────────────────────────────────────
function connectWebSocket() {
  const proto = location.protocol === "https:" ? "wss:" : "ws:";
  const ws = new WebSocket(`${proto}//${location.host}/ws`);
  state.ws = ws;

  ws.onopen = () => {
    // Covers both the very first connection and any reconnect (e.g.
    // after a restart) - re-sync everything rather than trusting
    // whatever local state we had before the gap.
    refreshVersion();
    refreshSaveDir();
    refreshTargetDir();
    loadJobsSnapshot();
    loadEncodeJobsSnapshot();

    if (inputField.disabled) {
      inputField.disabled = false;
      inputField.placeholder = "Paste a link, then press ENTER...";
    }
  };

  ws.onmessage = (evt) => {
    const msg = JSON.parse(evt.data);
    if (msg.type === "clipboard_url") {
      const url = (msg.url || "").trim();
      if (/^https?:\/\/[^\s]+$/i.test(url) && state.clipboardMonitor && state.appMode === "DOWNLOAD") {
        state.clipboardUrl = url;
        // A clipboard URL is an explicit request to download. Do not require
        // the input box to be in READY state: the user may have another title
        // staged, be viewing an intermediate fetch state, or simply have the
        // window unfocused. The clipboard event should still take precedence.
        inputField.value = url;
        inputField.dispatchEvent(new Event("input", { bubbles: true }));
        // Clipboard downloads are intentionally non-interactive: use the
        // fetched/sniffed title immediately and never enter title editing.
        beginDownloadPipeline(url, true);
      }
      return;
    } else if (msg.type === "job_added") {
      state.sessionJobFilenames.add(msg.job.filename);
      state.jobs.set(msg.job.filename, msg.job);
      renderLedger();
      updatePlaylistCancelButton();
    } else if (msg.type === "job_progress") {
      const job = state.jobs.get(msg.filename);
      if (job) {
        job.pct = msg.pct; job.total = msg.total; job.speed = msg.speed; job.eta = msg.eta;
        updateJobCardProgress(msg.filename, job);
      }
    } else if (msg.type === "job_finished") {
      const oldFilename = msg.original_filename || msg.filename;
      const job = state.jobs.get(oldFilename) || state.jobs.get(msg.filename);
      if (job) {
        if (oldFilename !== msg.filename) {
          state.jobs.delete(oldFilename);
          if (state.sessionJobFilenames.delete(oldFilename)) {
            state.sessionJobFilenames.add(msg.filename);
          }
        }
        job.filename = msg.filename;
        job.status = msg.status;
        job.file_size = msg.file_size;
        job.is_audio = msg.is_audio;
        job.width = msg.width;
        job.height = msg.height;
        job.duration = msg.duration;
        job.ext = msg.ext;
        job.video_codec = msg.video_codec;
        job.audio_codec = msg.audio_codec;
        job.pending_filename = "";
        state.jobs.set(msg.filename, job);
        renderLedger();
        updatePlaylistCancelButton();
      }
    } else if (msg.type === "job_status") {
      // A QUEUED playlist item flipping to DOWNLOADING once its
      // playlist batch's concurrency slot frees up - distinct from
      // job_finished, which always carries full terminal metadata.
      const job = state.jobs.get(msg.filename);
      if (job) {
        job.status = msg.status;
        renderLedger();
        updatePlaylistCancelButton();
      }
    } else if (msg.type === "job_deleted") {
      state.jobs.delete(msg.filename);
      renderLedger();
    } else if (msg.type === "download_failed_retry_m3u") {
      beginM3uRetryPipeline(msg.url, msg.res_cap, msg.original_pasted_url);
    } else if (msg.type === "refresh") {
      loadJobsIntoMap(msg.jobs);
      renderLedger();
    } else if (msg.type === "encode_job_added") {
      state.encodeJobs.set(msg.job.id, msg.job);
      renderLedger();
    } else if (msg.type === "encode_job_progress") {
      state.encodeJobs.set(msg.job.id, msg.job);
      updateJobCardEncodeProgress(msg.job);
    } else if (msg.type === "encode_job_updated") {
      state.encodeJobs.set(msg.job.id, msg.job);
      renderLedger();
      if (msg.job.status === "DONE") playCompletionPing();
    } else if (msg.type === "encode_job_deleted") {
      state.encodeJobs.delete(msg.job_id);
      renderLedger();
    } else if (msg.type === "history_entry_deleted") {
      state.historyEntries = state.historyEntries.filter(
        (e) => !(e.timestamp === msg.timestamp && e.filename === msg.filename && e.url === msg.url)
      );
      if (state.appMode === "SEARCH_HISTORY") renderHistoryLedger();
    } else if (msg.type === "renames_detected") {
      const renamed = msg.renamed || [];
      if (renamed.length === 1) {
        flashStatus(`Detected rename: "${renamed[0].old}" → "${renamed[0].new}"`);
      } else if (renamed.length > 1) {
        flashStatus(`Detected ${renamed.length} renamed files - history kept in sync.`);
      }
    }
  };

  ws.onclose = () => {
    setTimeout(connectWebSocket, 2000); // reconnect, e.g. after a backend restart
  };
}

// ── Ledger rendering ────────────────────────────────────────────
function parseSizeToBytes(sizeStr) {
  if (!sizeStr) return -1; // unknown/in-progress sizes sort to the bottom
  const m = /^([\d.]+)\s*(B|KB|MB|GB|TB|PB)$/i.exec(sizeStr.trim());
  if (!m) return -1;
  const value = parseFloat(m[1]);
  const units = ["B", "KB", "MB", "GB", "TB", "PB"];
  const exp = units.indexOf(m[2].toUpperCase());
  return value * Math.pow(1024, Math.max(exp, 0));
}

function formatBytes(bytes) {
  if (!isFinite(bytes) || bytes <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB", "PB"];
  let i = 0;
  while (bytes >= 1024 && i < units.length - 1) {
    bytes /= 1024;
    i++;
  }
  return `${bytes.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}

function getFilteredSortedJobs() {
  // "added" order = Map insertion order, oldest first; reverse for
  // newest-first, matching the ledger's existing default look.
  const withIndex = Array.from(state.jobs.values()).map((job, i) => ({ job, addedIndex: i }));

  const query = state.filterText.trim().toLowerCase();
  let filtered = query
    ? withIndex.filter(({ job }) => job.filename.toLowerCase().includes(query))
    : withIndex;

  if (state.audioOnlyFilter) {
    filtered = filtered.filter(({ job }) => job.is_audio);
  }

  if (state.statusFilters.size > 0) {
    filtered = filtered.filter(({ job }) => {
      for (const status of state.statusFilters) {
        if (status === "ENCODING") {
          const encodeJob = findEncodeJobFor(job.filename);
          if (encodeJob && (encodeJob.status === "QUEUED" || encodeJob.status === "ENCODING")) return true;
        } else if (status === "ENCODED") {
          if (isReencoded(job.filename)) return true;
        } else if (job.status === status) {
          return true;
        }
      }
      return false;
    });
  }

  if (state.hideCompletedFilter) {
    filtered = filtered.filter(({ job }) => job.status !== "DONE");
  }

  const dirMul = state.sortDir === "asc" ? 1 : -1;
  // Active downloads always stay at the top of the queue. The selected
  // sort option still applies within the downloading group and within
  // the remaining group, so sorting can never bury an in-progress item.
  filtered.sort((a, b) => {
    const aDownloading = a.job.status === "DOWNLOADING" ? 0 : 1;
    const bDownloading = b.job.status === "DOWNLOADING" ? 0 : 1;
    if (aDownloading !== bDownloading) return aDownloading - bDownloading;

    let cmp;
    if (state.sortField === "size") {
      cmp = parseSizeToBytes(a.job.file_size) - parseSizeToBytes(b.job.file_size);
    } else if (state.sortField === "name") {
      cmp = a.job.filename.toLowerCase().localeCompare(b.job.filename.toLowerCase());
    } else {
      cmp = a.addedIndex - b.addedIndex;
    }
    return cmp * dirMul;
  });

  return filtered.map(({ job }) => job);
}

function getFilteredSortedHistory() {
  const query = state.filterText.trim().toLowerCase();
  let filtered = query
    ? state.historyEntries.filter((e) => e.filename.toLowerCase().includes(query))
    : state.historyEntries.slice();

  const dirMul = state.sortDir === "asc" ? 1 : -1;
  filtered.sort((a, b) => {
    let cmp;
    if (state.sortField === "name") {
      cmp = a.filename.toLowerCase().localeCompare(b.filename.toLowerCase());
    } else {
      // "added" (and "size", which doesn't apply to history entries and
      // is disabled in the sort dropdown while this mode is active)
      // both fall back to chronological order via the log timestamp.
      cmp = a.timestamp < b.timestamp ? -1 : a.timestamp > b.timestamp ? 1 : 0;
    }
    return cmp * dirMul;
  });

  return filtered;
}

function renderLedger() {
  if (state.appMode === "SEARCH_HISTORY") {
    renderHistoryLedger();
    return;
  }
  const jobs = getFilteredSortedJobs();

  // Reuse each job's existing card node when its signature (see
  // jobCardSignature) hasn't changed since the last render, instead of
  // rebuilding every card from scratch every call. A full rebuild would
  // recreate every thumbnail <img> (forcing a re-request/re-decode) and
  // flash the whole ledger, which is wasteful when this fires from the
  // 5s auto-refresh poll and nothing actually changed. Selection state
  // (checkbox/.selected class) lives on the DOM node itself via
  // setCardSelectedVisual(), so it survives reuse untouched.
  const fragment = document.createDocumentFragment();
  const seen = new Set();
  for (const job of jobs) {
    const sig = jobCardSignature(job);
    seen.add(job.filename);
    let card = state.renderedCards.get(job.filename);
    if (!card || state.renderedCardSigs.get(job.filename) !== sig) {
      // Do not animate cards rebuilt by the periodic queue refresh. Dynamic
      // fields such as progress/speed/ETA can change during a refresh, and
      // replaying a fade animation here makes the entire ledger appear to
      // flash even though nothing was actually removed by the user.
      card = buildJobCard(job);
      state.renderedCards.set(job.filename, card);
      state.renderedCardSigs.set(job.filename, sig);
    }
    fragment.appendChild(card); // moves the node out of queueList if it's already there
  }
  for (const filename of Array.from(state.renderedCards.keys())) {
    if (!seen.has(filename)) {
      state.renderedCards.delete(filename);
      state.renderedCardSigs.delete(filename);
    }
  }
  queueList.innerHTML = "";
  queueList.appendChild(fragment);
  renderLedgerStatsBar(jobs);
}

// Everything that visibly (or functionally, e.g. has_twin gating the
// context menu) affects a job's card. state.saveDirPath is folded in
// too since it feeds the path tooltip/filename-path line - keeping it
// out of the per-field list below so a folder change doesn't need its
// own special case.
function jobCardSignature(job) {
  const encodeJob = findEncodeJobFor(job.filename);
  return [
    state.saveDirPath,
    job.status, job.pct, job.total, job.speed, job.eta,
    job.file_size, job.is_audio, job.ext,
    job.width, job.height, job.duration, job.video_codec, job.audio_codec,
    job.url, job.source_type, job.source_path,
    job.stash_tag_name, job.stash_scene_id,
    job.synchronized, job.has_twin, job.playback_position, job.fully_played,
    encodeJob ? encodeJob.id : "", encodeJob ? encodeJob.status : "", encodeJob ? encodeJob.pct : "",
  ].join("\u0001");
}

// Thin summary row under the toolbar: count + total size of whatever's
// currently visible in the ledger, plus a per-status breakdown (queued/
// downloading/error - "done" is left out since it's normally the
// majority and implied by the total) so a mid-batch playlist download
// is readable at a glance without scrolling the list. Stays honest
// against the active filter/audio-only/status-chip state instead of
// always reflecting the full queue.
function renderLedgerStatsBar(jobs) {
  ledgerStatsBar.innerHTML = "";
  if (jobs.length === 0) return;

  let totalBytes = 0;
  let altTotalBytes = 0; // same total, but using each twin's size in place of its source's, when one exists
  let hasAnyTwin = false;
  const counts = { QUEUED: 0, DOWNLOADING: 0, ERROR: 0 };
  for (const job of jobs) {
    const bytes = parseSizeToBytes(job.file_size);
    if (bytes > 0) totalBytes += bytes;
    const twinInfo = getTwinDisplayInfo(job);
    if (twinInfo && twinInfo.sizeBytes) {
      hasAnyTwin = true;
      altTotalBytes += twinInfo.sizeBytes;
    } else if (bytes > 0) {
      altTotalBytes += bytes;
    }
    if (job.status in counts) counts[job.status]++;
  }

  const fileLabel = jobs.length === 1 ? "1 file" : `${jobs.length} files`;
  const summary = document.createElement("span");
  summary.textContent = totalBytes > 0 ? `${fileLabel} \u00b7 ${formatBytes(totalBytes)}` : fileLabel;
  ledgerStatsBar.appendChild(summary);

  // Alternate total using twin (re-encoded) sizes where available -
  // only worth showing once at least one card actually has a twin,
  // otherwise it would just repeat the total above.
  if (hasAnyTwin && altTotalBytes > 0) {
    const altSummary = document.createElement("span");
    altSummary.className = "stat-chip stat-twin-total";
    altSummary.title = "Total size if every twin available were used in place of its source file.";
    altSummary.textContent = `${formatBytes(altTotalBytes)} using twins`;
    ledgerStatsBar.appendChild(altSummary);
  }

  const chipDefs = [
    ["QUEUED", "stat-queued", "queued"],
    ["DOWNLOADING", "stat-downloading", "downloading"],
    ["ERROR", "stat-error", "error"],
  ];
  for (const [status, cls, label] of chipDefs) {
    if (counts[status] === 0) continue;
    const chip = document.createElement("span");
    chip.className = `stat-chip ${cls}`;
    chip.textContent = `${counts[status]} ${label}`;
    ledgerStatsBar.appendChild(chip);
  }
}

function renderHistoryLedger() {
  ledgerStatsBar.textContent = "";
  queueList.innerHTML = "";
  const entries = getFilteredSortedHistory();
  if (entries.length === 0) {
    const empty = document.createElement("div");
    empty.className = "history-empty";
    empty.textContent = state.filterText.trim()
      ? "No history entries match your filter."
      : "No download history found yet.";
    queueList.appendChild(empty);
    return;
  }
  for (const entry of entries) {
    queueList.appendChild(buildHistoryCard(entry));
  }
}

async function refreshSearchHistory() {
  queueList.innerHTML = "";
  const loading = document.createElement("div");
  loading.className = "history-empty";
  loading.textContent = "Loading download history...";
  queueList.appendChild(loading);

  try {
    const res = await fetch("/api/history");
    const data = await res.json();
    state.historyEntries = data.entries || [];
  } catch (e) {
    state.historyEntries = [];
  }

  if (state.appMode === "SEARCH_HISTORY") renderHistoryLedger();
}

// Common video aspect ratios, checked against the actual pixel ratio so
// slightly-off dimensions (e.g. 1918x1080 from some encoders) still snap
// to the label a person would recognize, rather than showing "959:540".
const COMMON_ASPECT_RATIOS = [
  [1, 1], [4, 3], [3, 2], [16, 9], [16, 10], [21, 9], [9, 16], [3, 4], [2, 3], [10, 16],
];

function aspectRatioLabel(width, height) {
  if (!width || !height) return "";
  const ratio = width / height;
  for (const [rw, rh] of COMMON_ASPECT_RATIOS) {
    if (Math.abs(ratio - rw / rh) < 0.02) return `${rw}:${rh}`;
  }
  const divisor = gcd(width, height);
  return `${width / divisor}:${height / divisor}`;
}

function gcd(a, b) {
  return b === 0 ? a : gcd(b, a % b);
}

function stemOf(filename) {
  const idx = filename.lastIndexOf(".");
  return idx > 0 ? filename.slice(0, idx) : filename;
}

// Picks the single most relevant Encode Manager job whose source traces
// back to this download (matched by filename stem - see enqueueing
// code). An active (queued/encoding) job always wins over a stale
// done/error one from an earlier encode of the same source; among
// same-priority matches, the most recently added one wins (Map
// iteration order = insertion order).
function findEncodeJobFor(filename) {
  const activeStatuses = new Set(["QUEUED", "ENCODING"]);
  let found = null;
  for (const job of state.encodeJobs.values()) {
    if (stemOf(job.source_filename || "") !== filename) continue;
    if (!found) { found = job; continue; }
    const jobActive = activeStatuses.has(job.status);
    const foundActive = activeStatuses.has(found.status);
    if (jobActive || !foundActive) found = job;
  }
  return found;
}

// A download is considered re-encoded if its most relevant Encode
// Manager job (see findEncodeJobFor) has finished.
function isReencoded(filename) {
  const job = findEncodeJobFor(filename);
  return !!(job && job.status === "DONE");
}

function encodeSavingsLabel(encodeJob) {
  if (!encodeJob.source_size || !encodeJob.final_bytes) return null;
  const pct = Math.round((1 - encodeJob.final_bytes / encodeJob.source_size) * 100);
  return `${encodeJob.source_size_label} \u2192 ${encodeJob.final_size_label} (${pct >= 0 ? "-" : "+"}${Math.abs(pct)}%)`;
}

// Twin size/resolution for card display. Prefers a completed Encode
// Manager job's own numbers (precise final_bytes/output_width/height,
// available the instant that job finishes) and falls back to the
// backend's direct Converted/ probe (job.twin_*, see
// job_manager.seed_from_filesystem) for a twin with no matching
// in-memory encode job - e.g. one dropped in by hand, or left over
// from before a server restart. Returns null when neither has a twin.
function getTwinDisplayInfo(job) {
  const encodeJob = findEncodeJobFor(job.filename);
  if (encodeJob && encodeJob.status === "DONE" && encodeJob.final_bytes) {
    const sourceBytes = encodeJob.source_size || parseSizeToBytes(job.file_size);
    const pct = sourceBytes ? Math.round((encodeJob.final_bytes / sourceBytes) * 100) : null;
    return {
      sizeBytes: encodeJob.final_bytes,
      sizeLabel: encodeJob.final_size_label || formatBytes(encodeJob.final_bytes),
      width: encodeJob.output_width || 0,
      height: encodeJob.output_height || 0,
      pct,
    };
  }
  if (job.has_twin && job.twin_size) {
    const sourceBytes = parseSizeToBytes(job.file_size);
    const pct = sourceBytes ? Math.round((job.twin_size / sourceBytes) * 100) : null;
    return {
      sizeBytes: job.twin_size,
      sizeLabel: job.twin_size_label || formatBytes(job.twin_size),
      width: job.twin_width || 0,
      height: job.twin_height || 0,
      pct,
    };
  }
  return null;
}

// A download is synchronized once its Synchronize Audio twin in
// Converted/ has been confirmed - tracked directly on the job (see
// mark_synchronized on the backend), not derived like isReencoded()
// since sync renders aren't Encode Manager jobs.
function isSynchronized(filename) {
  const job = state.jobs.get(filename);
  return !!(job && job.synchronized);
}

// Short synthesized two-tone chime, so completion has an audible cue
// without needing to ship/load an actual sound file.
function playCompletionPing() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(880, now);
    osc.frequency.exponentialRampToValueAtTime(1320, now + 0.12);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.25, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.35);
    osc.connect(gain).connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.4);
    osc.onended = () => ctx.close();
  } catch (e) {
    // Audio unavailable/blocked (e.g. no user interaction yet) - not
    // critical, the visual completion state still shows either way.
  }
}

const ledgerFilterInput = el("ledger-filter");
const ledgerFilterPresetWrap = el("ledger-filter-preset-wrap");
const ledgerFilterPresetBtn = el("ledger-filter-preset-btn");
const ledgerFilterPresetLabel = el("ledger-filter-preset-label");
const ledgerFilterPresetMenu = el("ledger-filter-preset-menu");
const ledgerSortSelect = el("ledger-sort");
const ledgerSortOrderBtn = el("ledger-sort-order-btn");
const ledgerMoreBtn = el("ledger-more-btn");
const ledgerMoreMenu = el("ledger-more-menu");
const ledgerStatsBar = el("ledger-stats-bar");

// ── Navigation tray toggle ──────────────────────────────────
// Folder controls live outside the tray in the DOM (see index.html) so
// they can stay visible while the tray itself is closed/hidden; this
// keeps that row's visibility in sync whenever the tray's open state
// changes, or the pin toggle is flipped.
function updateFolderStatusRowVisibility() {
  const visible = folderControlsPinned || navTray.classList.contains("open");
  folderStatusRow.classList.toggle("hidden", !visible);
}

navToggleBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  navTray.classList.remove("hidden");
  const isOpen = navTray.classList.toggle("open");
  navToggleBtn.classList.toggle("active", isOpen);
  navTrayPersistedOpen = isOpen;
  try {
    localStorage.setItem("stashdlp_nav_tray_open", isOpen ? "1" : "0");
  } catch (err) { /* ignore - localStorage unavailable */ }
  updateFolderStatusRowVisibility();
});

// Restore the hamburger/tray state from the previous session. This is a
// display preference only and does not affect any download or server state.
if (navTrayPersistedOpen) {
  navTray.classList.remove("hidden");
  navTray.classList.add("open");
}
navToggleBtn.classList.toggle("active", navTrayPersistedOpen);
folderControlsToggleBtn.classList.toggle("active", folderControlsPinned);
updateFolderStatusRowVisibility();

function setFolderControlsPinned(value) {
  folderControlsPinned = !!value;
  folderControlsToggleBtn.classList.toggle("active", folderControlsPinned);
  try {
    localStorage.setItem("stashdlp_folder_controls_pinned", folderControlsPinned ? "1" : "0");
  } catch (err) { /* ignore - localStorage unavailable */ }
  updateFolderStatusRowVisibility();
  el("set-folder-pin").checked = folderControlsPinned;
}

folderControlsToggleBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  setFolderControlsPinned(!folderControlsPinned);
});

ledgerFilterInput.addEventListener("input", () => {
  state.filterText = ledgerFilterInput.value;
  renderLedger();
});

updateLedgerFilterPresetUI();

function updateLedgerFilterPresetUI() {
  const activeStatuses = Array.from(state.statusFilters);
  const activeCount = activeStatuses.length + (state.audioOnlyFilter ? 1 : 0) + (state.sessionOnlyFilter ? 1 : 0);

  let label = "All";
  if (activeCount === 1) {
    if (state.audioOnlyFilter) {
      label = "Audio";
    } else if (state.sessionOnlyFilter) {
      label = "This Session";
    } else {
      const labels = {
        QUEUED: "Queued",
        DOWNLOADING: "Downloading",
        DONE: "Done",
        ERROR: "Error",
        ENCODING: "Encoding",
        ENCODED: "Encoded",
      };
      label = labels[activeStatuses[0]] || "Filter";
    }
  } else if (activeCount > 1) {
    label = `${activeCount} filters`;
  }

  ledgerFilterPresetLabel.textContent = label;
  ledgerFilterPresetBtn.classList.toggle("active", activeCount > 0);
  ledgerFilterPresetBtn.title = activeCount
    ? `Filters: ${activeCount} active`
    : "Filter presets";

  ledgerFilterPresetMenu.querySelectorAll(".ctx-filter-preset[data-status]").forEach((item) => {
    const active = state.statusFilters.has(item.dataset.status);
    item.classList.toggle("active", active);
    item.querySelector(".ctx-check").textContent = active ? "✓" : "";
  });
  const audioItem = el("ledger-filter-audio");
  audioItem.classList.toggle("active", state.audioOnlyFilter);
  audioItem.querySelector(".ctx-check").textContent = state.audioOnlyFilter ? "✓" : "";
  const sessionItem = el("ledger-filter-session");
  sessionItem.classList.toggle("active", state.sessionOnlyFilter);
  sessionItem.querySelector(".ctx-check").textContent = state.sessionOnlyFilter ? "✓" : "";
  el("ledger-filter-all").classList.toggle("active", activeCount === 0);
  el("ledger-filter-all").querySelector(".ctx-check").textContent = activeCount === 0 ? "✓" : "";
}

ledgerFilterPresetBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  closeOtherFlyouts(ledgerFilterPresetMenu);
  ledgerFilterPresetMenu.classList.toggle("hidden");
  ledgerFilterPresetBtn.setAttribute("aria-expanded", String(!ledgerFilterPresetMenu.classList.contains("hidden")));
  if (!ledgerFilterPresetMenu.classList.contains("hidden")) {
    positionDropdownBelow(ledgerFilterPresetMenu, ledgerFilterPresetBtn);
  }
});

el("ledger-filter-all").addEventListener("click", () => {
  state.audioOnlyFilter = false;
  state.sessionOnlyFilter = false;
  state.statusFilters.clear();
  updateLedgerFilterPresetUI();
  ledgerFilterPresetMenu.classList.add("hidden");
  ledgerFilterPresetBtn.setAttribute("aria-expanded", "false");
  renderLedger();
});

el("ledger-filter-audio").addEventListener("click", () => {
  state.audioOnlyFilter = !state.audioOnlyFilter;
  updateLedgerFilterPresetUI();
  renderLedger();
});

el("ledger-filter-session").addEventListener("click", () => {
  state.sessionOnlyFilter = !state.sessionOnlyFilter;
  updateLedgerFilterPresetUI();
  renderLedger();
});

ledgerFilterPresetMenu.querySelectorAll(".ctx-filter-preset[data-status]").forEach((item) => {
  item.addEventListener("click", () => {
    const status = item.dataset.status;
    if (state.statusFilters.has(status)) state.statusFilters.delete(status);
    else state.statusFilters.add(status);
    updateLedgerFilterPresetUI();
    renderLedger();
  });
});

// Sort field and direction are intentionally separate controls:
// the dropdown chooses what to sort by, while the adjacent button
// toggles ascending/descending order.
ledgerSortSelect.addEventListener("change", () => {
  state.sortField = ledgerSortSelect.value;
  renderLedger();
});

function updateLedgerSortOrderUI() {
  const descending = state.sortDir === "desc";
  ledgerSortOrderBtn.innerHTML = `<i class="ti ${descending ? "ti-sort-descending" : "ti-sort-ascending"}" aria-hidden="true"></i>`;
  ledgerSortOrderBtn.title = descending ? "Newest / largest / Z-A first" : "Oldest / smallest / A-Z first";
  ledgerSortOrderBtn.setAttribute("aria-label", ledgerSortOrderBtn.title);
}

ledgerSortOrderBtn.addEventListener("click", () => {
  state.sortDir = state.sortDir === "desc" ? "asc" : "desc";
  updateLedgerSortOrderUI();
  renderLedger();
});
updateLedgerSortOrderUI();

ledgerMoreBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  closeOtherFlyouts(ledgerMoreMenu);
  ledgerMoreMenu.classList.toggle("hidden");
  if (!ledgerMoreMenu.classList.contains("hidden")) {
    positionDropdownBelow(ledgerMoreMenu, ledgerMoreBtn);
  }
});

// ── Multi-select ──────────────────────────────────────────────
// Selection lives as a Set of filenames on state, independent of any
// particular card's DOM node - buildJobCard just reflects it (checked
// state + .selected class) each time a card is (re)built, and the
// checkbox itself is always present in the DOM, shown/hidden purely via
// the .selection-mode class on queueList. That keeps toggling selection
// mode itself cheap (no re-render needed) while still surviving a full
// renderLedger() (e.g. from a websocket update) without losing state.
const selectModeBtn = el("select-mode-btn");
const selectionActionBar = el("selection-action-bar");
const selectionCountLabel = el("selection-count");
const selectionSelectAllBtn = el("selection-select-all-btn");
const selectionClearBtn = el("selection-clear-btn");
const selectionMoveBtn = el("selection-move-btn");
const selectionEncodeBtn = el("selection-encode-btn");
const selectionStashBtn = el("selection-stash-btn");
const selectionDeleteBtn = el("selection-delete-btn");

const batchStashModal = el("batch-stash-modal");
const batchStashCount = el("batch-stash-count");
const batchStashError = el("batch-stash-error");
const closeBatchStashModalBtn = el("close-batch-stash-modal");
const cancelBatchStashModalBtn = el("cancel-batch-stash-modal");
const startBatchStashBtn = el("start-batch-stash-btn");

const batchEncodeModal = el("batch-encode-modal");
const batchEncodeCount = el("batch-encode-count");
const batchEncodePresetSelect = el("batch-encode-preset-select");
const batchEncodeError = el("batch-encode-error");
const closeBatchEncodeModalBtn = el("close-batch-encode-modal");
const cancelBatchEncodeModalBtn = el("cancel-batch-encode-modal");
const startBatchEncodeBtn = el("start-batch-encode-btn");

function isSelectable(job) {
  // Mirrors the single-item options menu's own gating: deleting or
  // moving a file that's still being written to would corrupt that
  // job's in-flight state, so downloading items simply aren't
  // selectable in the first place. QUEUED items (waiting on a
  // playlist batch's concurrency slot) have no file on disk yet
  // either, so the same exclusion applies to them.
  return job.status !== "DOWNLOADING" && job.status !== "QUEUED";
}

function updateSelectionBar() {
  const count = state.selectedFilenames.size;
  selectionCountLabel.textContent = count === 1 ? "1 selected" : `${count} selected`;
  selectionMoveBtn.disabled = count === 0;
  selectionEncodeBtn.disabled = count === 0;
  selectionDeleteBtn.disabled = count === 0;

  // Stash is a batch-only action: it is shown only when every selected
  // completed item is a Stash import. A mixed selection never exposes it.
  const selectedJobs = Array.from(state.selectedFilenames)
    .map((filename) => state.jobs.get(filename))
    .filter(Boolean);
  const allStash = count > 0 &&
    selectedJobs.length === count &&
    selectedJobs.every((job) => job.status === "DONE" && job.source_type === "stash");
  selectionStashBtn.classList.toggle("hidden", !allStash);
  selectionStashBtn.disabled = !allStash;
}

function setCardSelectedVisual(filename, selected) {
  const card = queueList.querySelector(`.job-card[data-filename="${cssEscape(filename)}"]`);
  if (!card) return;
  card.classList.toggle("selected", selected);
  const checkbox = card.querySelector(".job-card-checkbox");
  if (checkbox) checkbox.checked = selected;
}

function toggleSelection(filename) {
  if (state.selectedFilenames.has(filename)) {
    state.selectedFilenames.delete(filename);
    setCardSelectedVisual(filename, false);
  } else {
    state.selectedFilenames.add(filename);
    setCardSelectedVisual(filename, true);
  }
  updateSelectionBar();
}

function enterSelectionMode() {
  state.selectionMode = true;
  selectModeBtn.classList.add("active");
  selectModeBtn.title = "Cancel Select";
  queueList.classList.add("selection-mode");
  selectionActionBar.classList.remove("hidden");
  updateSelectionBar();
}

function exitSelectionMode() {
  if (!state.selectionMode && state.selectedFilenames.size === 0) return;
  state.selectionMode = false;
  state.selectedFilenames.clear();
  selectModeBtn.classList.remove("active");
  selectModeBtn.title = "Select";
  queueList.classList.remove("selection-mode");
  selectionActionBar.classList.add("hidden");
  for (const card of queueList.querySelectorAll(".job-card.selected")) {
    card.classList.remove("selected");
  }
}

selectModeBtn.addEventListener("click", () => {
  if (state.selectionMode) exitSelectionMode();
  else enterSelectionMode();
});

selectionSelectAllBtn.addEventListener("click", () => {
  for (const job of getFilteredSortedJobs()) {
    if (isSelectable(job) && !state.selectedFilenames.has(job.filename)) {
      state.selectedFilenames.add(job.filename);
      setCardSelectedVisual(job.filename, true);
    }
  }
  updateSelectionBar();
});

selectionClearBtn.addEventListener("click", () => {
  for (const filename of state.selectedFilenames) setCardSelectedVisual(filename, false);
  state.selectedFilenames.clear();
  updateSelectionBar();
});

async function openBatchEncodeModal() {
  const filenames = Array.from(state.selectedFilenames);
  if (filenames.length === 0) return;

  batchEncodeError.classList.add("hidden");
  batchEncodeError.textContent = "";
  batchEncodeCount.textContent = `${filenames.length} file(s) selected. Choose the encoding preset to apply to all of them.`;
  batchEncodePresetSelect.innerHTML = "";

  try {
    const res = await fetch("/api/encode/presets");
    const data = await res.json();
    encodeSavedPresets = Array.isArray(data.presets) ? data.presets : [];
  } catch (e) {
    encodeSavedPresets = [];
  }

  const placeholder = document.createElement("option");
  placeholder.value = "";
  placeholder.textContent = encodeSavedPresets.length ? "Select a preset..." : "No saved presets";
  batchEncodePresetSelect.appendChild(placeholder);
  for (const preset of encodeSavedPresets) {
    const opt = document.createElement("option");
    opt.value = preset.name;
    opt.textContent = preset.name;
    batchEncodePresetSelect.appendChild(opt);
  }

  batchEncodePresetSelect.value = "";
  startBatchEncodeBtn.disabled = true;
  batchEncodeModal.classList.remove("hidden");
}

function closeBatchEncodeModal() {
  batchEncodeModal.classList.add("hidden");
}

batchEncodePresetSelect.addEventListener("change", () => {
  startBatchEncodeBtn.disabled = !batchEncodePresetSelect.value;
});

selectionEncodeBtn.addEventListener("click", openBatchEncodeModal);
closeBatchEncodeModalBtn.addEventListener("click", closeBatchEncodeModal);
cancelBatchEncodeModalBtn.addEventListener("click", closeBatchEncodeModal);
batchEncodeModal.addEventListener("click", (e) => {
  if (e.target === batchEncodeModal) closeBatchEncodeModal();
});

startBatchEncodeBtn.addEventListener("click", async () => {
  const filenames = Array.from(state.selectedFilenames);
  const presetName = batchEncodePresetSelect.value;
  const preset = encodeSavedPresets.find(p => p.name === presetName);
  if (!filenames.length || !preset?.options) return;

  batchEncodeError.classList.add("hidden");
  startBatchEncodeBtn.disabled = true;
  cancelBatchEncodeModalBtn.disabled = true;
  closeBatchEncodeModalBtn.disabled = true;

  try {
    const res = await fetch("/api/encode/jobs/batch", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filenames, options: preset.options }),
    });
    const data = await res.json();
    if (!res.ok) {
      batchEncodeError.textContent = data.error || "Couldn't queue the selected files.";
      batchEncodeError.classList.remove("hidden");
      return;
    }

    for (const job of data.jobs || []) state.encodeJobs.set(job.id, job);
    renderLedger();
    state.selectedFilenames.clear();
    exitSelectionMode();
    closeBatchEncodeModal();

    const queued = (data.jobs || []).length;
    const failed = data.failed || [];
    let message = `Queued ${queued} file(s) for encoding using "${presetName}".`;
    if (failed.length) {
      message += `\n\n${failed.length} file(s) could not be queued:\n` +
        failed.map(f => `- ${f.filename}: ${f.error}`).join("\n");
    }
    window.alert(message);
  } catch (e) {
    batchEncodeError.textContent = "Couldn't reach the server.";
    batchEncodeError.classList.remove("hidden");
  } finally {
    startBatchEncodeBtn.disabled = !batchEncodePresetSelect.value;
    cancelBatchEncodeModalBtn.disabled = false;
    closeBatchEncodeModalBtn.disabled = false;
  }
});

function openBatchStashModal() {
  const filenames = Array.from(state.selectedFilenames);
  if (!filenames.length) return;

  batchStashCount.textContent =
    `${filenames.length} Stash source${filenames.length === 1 ? "" : "s"} selected.`;
  batchStashError.classList.add("hidden");
  batchStashError.textContent = "";
  batchStashModal.classList.remove("hidden");
}

function closeBatchStashModal() {
  batchStashModal.classList.add("hidden");
}

selectionStashBtn.addEventListener("click", openBatchStashModal);
closeBatchStashModalBtn.addEventListener("click", closeBatchStashModal);
cancelBatchStashModalBtn.addEventListener("click", closeBatchStashModal);
batchStashModal.addEventListener("click", (e) => {
  if (e.target === batchStashModal) closeBatchStashModal();
});

startBatchStashBtn.addEventListener("click", async () => {
  const filenames = Array.from(state.selectedFilenames);
  if (!filenames.length) return;

  batchStashError.classList.add("hidden");
  startBatchStashBtn.disabled = true;
  cancelBatchStashModalBtn.disabled = true;
  closeBatchStashModalBtn.disabled = true;

  try {
    const res = await fetch("/api/jobs/replace-source/batch", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        filenames,
        transfer_only_twins: true,
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      batchStashError.textContent = data.error || "Couldn't replace the selected Stash sources.";
      batchStashError.classList.remove("hidden");
      return;
    }

    loadJobsIntoMap(data.jobs || []);
    state.selectedFilenames.clear();
    renderLedger();
    updateSelectionBar();
    closeBatchStashModal();

    const replaced = data.succeeded || [];
    const skipped = data.skipped || [];
    const failed = data.failed || [];
    let message = `Transferred ${replaced.length} Stash source${replaced.length === 1 ? "" : "s"}.`;
    if (replaced.length) {
      message += " Stash tags were removed automatically where recorded.";
    }
    if (skipped.length) {
      message += `\n\n${skipped.length} skipped (no twin found):\n` +
        skipped.map((f) => `- ${f.filename}`).join("\n");
    }
    if (failed.length) {
      message += `\n\n${failed.length} item${failed.length === 1 ? "" : "s"} failed:\n` +
        failed.map((f) => `- ${f.filename}: ${f.error}`).join("\n");
    }
    window.alert(message);
  } catch (e) {
    batchStashError.textContent = "Couldn't reach the server to replace the Stash sources.";
    batchStashError.classList.remove("hidden");
  } finally {
    startBatchStashBtn.disabled = false;
    cancelBatchStashModalBtn.disabled = false;
    closeBatchStashModalBtn.disabled = false;
  }
});

selectionDeleteBtn.addEventListener("click", async () => {
  const filenames = Array.from(state.selectedFilenames);
  if (filenames.length === 0) return;
  if (!window.confirm(
    `Delete ${filenames.length} file(s)?\n\nThis removes them from disk and can't be undone.`
  )) return;

  try {
    const res = await fetch("/api/jobs/delete-batch", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filenames }),
    });
    const data = await res.json();
    for (const filename of data.deleted || []) state.jobs.delete(filename);
    state.selectedFilenames.clear();
    renderLedger();
    updateSelectionBar();
    if (data.skipped && data.skipped.length > 0) {
      window.alert(
        `Deleted ${data.deleted.length} file(s).\n\n` +
        `${data.skipped.length} skipped (still downloading):\n` +
        data.skipped.join("\n")
      );
    } else {
      flashStatus(`Deleted ${data.deleted.length} file(s).`);
    }
  } catch (e) {
    window.alert("Couldn't reach the server to delete those files.");
  }
});

selectionMoveBtn.addEventListener("click", async () => {
  const filenames = Array.from(state.selectedFilenames);
  if (filenames.length === 0) return;
  const targetPath = ctxTargetDir.title || "";
  if (!targetPath) {
    window.alert("Set a target folder first (right-click the logo \u2192 Change Target Folder...).");
    return;
  }
  if (!window.confirm(`Move ${filenames.length} file(s) to:\n${targetPath}\n\nThis can't be undone.`)) {
    return;
  }

  try {
    const res = await fetch("/api/jobs/move-selected-to-target", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filenames }),
    });
    const data = await res.json();
    if (!res.ok) {
      window.alert(`Couldn't move files:\n${data.error || "Unknown error"}`);
      return;
    }
    loadJobsIntoMap(data.jobs);
    renderLedger();

    const movedNames = [...data.moved];
    const failed = [...data.failed];

    // Same as move-all-btn: files with a re-encoded twin weren't
    // touched yet - walk them one at a time so each gets its own
    // Original/Re-encoded/Cancel prompt.
    for (const info of data.pending_decisions || []) {
      const choice = await promptReencodeChoice(info);
      if (!choice) continue; // cancelled - leave it in the ledger
      const result = await requestMoveToTarget(info.filename, choice);
      if (result === "moved") {
        state.jobs.delete(info.filename);
        movedNames.push(info.filename);
      } else if (result === "error") {
        failed.push({ filename: info.filename, error: "Move failed - see alert." });
      }
    }

    state.selectedFilenames.clear();
    renderLedger();
    updateSelectionBar();

    let message = `Moved ${movedNames.length} item(s) to target.`;
    if (failed.length > 0) {
      message += `\n\n${failed.length} failed:\n` +
        failed.map((f) => `- ${f.filename}: ${f.error}`).join("\n");
    }
    window.alert(message);
  } catch (e) {
    window.alert("Couldn't reach the server to move those files.");
  }
});

// Convert a local Windows path to a file:// URI suitable for an
// OS-level drag operation. The browser cannot hand an arbitrary local
// file object to another application, but Windows/Firefox can consume
// file URIs supplied through the drag data transfer.
function localPathToFileUri(filePath) {
  if (!filePath) return "";
  const normalized = String(filePath).replace(/\\/g, "/");

  if (/^[A-Za-z]:\//.test(normalized)) {
    const drive = normalized.slice(0, 2);
    const rest = normalized.slice(2).split("/").filter(Boolean)
      .map(part => encodeURIComponent(part)).join("/");
    return `file:///${drive}${rest ? "/" + rest : ""}`;
  }

  if (normalized.startsWith("//")) {
    const parts = normalized.slice(2).split("/").filter(Boolean)
      .map(part => encodeURIComponent(part));
    return `file://${parts.join("/")}`;
  }

  const parts = normalized.split("/").filter(Boolean)
    .map(part => encodeURIComponent(part));
  return `file:///${parts.join("/")}`;
}

function addFileDragSupport(card, job) {
  // Only completed files can be dragged to an external editor. A
  // DOWNLOADING/ERROR card must never advertise a path that may not
  // exist or may still be changing.
  if (job.status !== "DONE" || !state.saveDirPath) return;

  const fullPath = joinDisplayPath(state.saveDirPath, job.filename, job.ext);
  const fileUri = localPathToFileUri(fullPath);
  if (!fileUri) return;

  card.draggable = true;
  card.title = "Drag this card to an editing program to open the file";

  card.addEventListener("dragstart", (e) => {
    if (state.selectionMode) {
      e.preventDefault();
      return;
    }

    const dt = e.dataTransfer;
    if (!dt) return;

    dt.effectAllowed = "copy";
    // text/uri-list is understood by browsers and many desktop
    // applications when a local file is dragged out of a webpage.
    dt.setData("text/uri-list", fileUri);
    dt.setData("text/plain", fileUri);

    // Chromium's DownloadURL format gives applications that support it
    // the filename, MIME type and local file URI in one payload.
    const mime = job.is_audio ? "audio/*" : "video/*";
    dt.setData("DownloadURL", `${mime}:${job.filename}:${fileUri}`);

    // Firefox exposes this custom flavor to some native drag targets.
    dt.setData("application/x-moz-file", fullPath);

    card.classList.add("dragging");
  });

  card.addEventListener("dragend", () => {
    card.classList.remove("dragging");
  });
}

function buildJobCard(job) {
  const card = document.createElement("div");
  card.className = "job-card job-card-row";
  card.dataset.filename = job.filename;
  if (job.is_audio) card.classList.add("audio");
  if (state.selectedFilenames.has(job.filename)) card.classList.add("selected");

  const thumb = document.createElement("div");
  thumb.className = "job-thumb";
  if (job.is_audio) {
    // No point requesting a video-frame thumbnail for an audio-only
    // file - just show a distinct icon directly.
    const placeholder = document.createElement("span");
    placeholder.className = "job-thumb-placeholder";
    placeholder.textContent = "🎵";
    thumb.appendChild(placeholder);
  } else {
    thumb.classList.add("loading");
    const thumbImg = document.createElement("img");
    thumbImg.loading = "lazy";
    thumbImg.alt = "";
    thumbImg.src = `/api/jobs/thumbnail?filename=${encodeURIComponent(job.filename)}`;
    thumbImg.addEventListener("load", () => {
      thumb.classList.remove("loading");
    }, { once: true });
    thumbImg.addEventListener("error", () => {
      thumb.classList.remove("loading");
      thumbImg.remove();
      const placeholder = document.createElement("span");
      placeholder.className = "job-thumb-placeholder";
      placeholder.textContent = "🎬";
      thumb.appendChild(placeholder);
    }, { once: true });
    thumb.appendChild(thumbImg);
  }
  const thumbWrap = document.createElement("div");
  thumbWrap.className = "job-thumb-wrap";
  thumbWrap.appendChild(thumb);

  if (isSelectable(job)) {
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.className = "job-card-checkbox";
    checkbox.checked = state.selectedFilenames.has(job.filename);
    checkbox.setAttribute("aria-label", `Select ${job.filename}`);
    checkbox.addEventListener("click", (e) => {
      e.stopPropagation();
      toggleSelection(job.filename);
    });
    thumbWrap.appendChild(checkbox);
  }

  card.appendChild(thumbWrap);

  const body = document.createElement("div");
  body.className = "job-card-body job-card-body-wide";

  const titlePathCol = document.createElement("div");
  titlePathCol.className = "job-title-path-col";

  const titleRow = document.createElement("div");
  titleRow.className = "job-title-row";
  const title = document.createElement("div");
  title.className = "job-title";
  title.textContent = job.filename;
  title.title = buildTooltip(job);
  titleRow.appendChild(title);
  if (job.is_audio) {
    const badge = document.createElement("span");
    badge.className = "audio-badge";
    badge.textContent = "AUDIO";
    titleRow.appendChild(badge);
  }

  // Compact icon cluster for informational (non-urgent) status flags -
  // full-text pills for all of these at once could crowd out the title
  // itself on a card that's re-encoded AND synced AND a Stash import.
  // Each icon keeps its meaning as a hover tooltip instead.
  const statusIcons = document.createElement("span");
  statusIcons.className = "job-status-icons";
  if (job.status === "DONE" && isReencoded(job.filename)) {
    const icon = document.createElement("i");
    icon.className = "ti ti-recycle job-status-icon-reencoded";
    const encodeJob = findEncodeJobFor(job.filename);
    icon.title = (encodeJob && encodeSavingsLabel(encodeJob))
      ? `Re-encoded: ${encodeSavingsLabel(encodeJob)}`
      : "Re-encoded: a converted twin exists in Converted/.";
    statusIcons.appendChild(icon);
  }
  {
    const encodeJob = findEncodeJobFor(job.filename);
    if (encodeJob && encodeJob.status === "ERROR") {
      const icon = document.createElement("i");
      icon.className = "ti ti-alert-triangle job-status-icon-error";
      icon.title = `Encoding failed: ${encodeJob.error_message || "Unknown error"}`;
      statusIcons.appendChild(icon);
    }
  }
  if (job.status === "DONE" && job.synchronized) {
    const icon = document.createElement("i");
    icon.className = "ti ti-adjustments job-status-icon-synchronized";
    icon.title = "Audio synchronized.";
    statusIcons.appendChild(icon);
  }
  // Direct filesystem check (done server-side on every Refresh, see
  // job_manager.seed_from_filesystem) for a twin sitting in Converted/.
  // Shown/hidden purely on that check - stacks with RE-ENCODED/
  // SYNCHRONIZED rather than being suppressed by them, since this is
  // the more general "there's a file in Converted/" signal (also
  // catches a twin left over from before a server restart, since
  // Encode Manager history is in-memory).
  if (job.status === "DONE" && job.has_twin) {
    const icon = document.createElement("i");
    icon.className = "ti ti-copy job-status-icon-has-twin";
    icon.title = "A file already exists for this download in Converted/. Press Refresh if this seems out of date.";
    statusIcons.appendChild(icon);
  }
  if (job.source_type === "stash" && !job.is_audio) {
    const icon = document.createElement("i");
    icon.className = "ti ti-database job-status-icon-stash";
    icon.title = "Stash file";
    statusIcons.appendChild(icon);
  }
  if (statusIcons.children.length > 0) titleRow.appendChild(statusIcons);

  if (job.stash_tag_name) {
    const pill = document.createElement("span");
    pill.className = "stash-tag-badge";
    pill.textContent = job.stash_tag_name;
    pill.title = `Imported via Stash Check Tag: "${job.stash_tag_name}". Renaming is disabled for this item.`;
    titleRow.appendChild(pill);
  }
  if (job.status === "DONE" && job.fully_played) {
    const pill = document.createElement("span");
    pill.className = "watched-badge";
    pill.textContent = job.is_audio ? "✓ LISTENED" : "✓ WATCHED";
    pill.title = job.is_audio
      ? "Fully listened to at least once - still tracks your current position if you listen again."
      : "Fully watched at least once - still tracks your current position if you rewatch.";
    titleRow.appendChild(pill);
  }
  titlePathCol.appendChild(titleRow);

  const folderPath = state.saveDirPath || "";
  const fullFilePath = joinDisplayPath(state.saveDirPath, job.filename, job.ext);
  const pathEl = document.createElement("div");
  pathEl.className = "job-path";
  pathEl.textContent = folderPath ? compactFolderDisplay(folderPath, "").compact : "(unknown folder)";
  pathEl.title = fullFilePath;
  titlePathCol.appendChild(pathEl);

  body.appendChild(titlePathCol);

  const status = job.status;
  const isDownloadingCard = status === "DOWNLOADING";
  const isDoneCard = status === "DONE";
  const isQueuedCard = status === "QUEUED";

  // Quick-action icons - the same four operations available from the
  // card's options menu (copy link, copy filename, rename, move to
  // target), surfaced directly on the card so they're one tap away.
  // Gating mirrors openJobMenu: copy actions work at any status, rename
  // needs the download to be finished writing, and move-to-target needs
  // a completed file to actually move. On wide desktop layouts they sit
  // as a visible column at the end of the row (there's width to spare);
  // the mobile media query hides this column entirely since the tap
  // options menu already covers the same four actions there.
  function makeCardIconBtn(iconClass, title, onClick) {
    const btn = document.createElement("button");
    btn.className = "job-mini-btn";
    btn.title = title;
    btn.setAttribute("aria-label", title);
    const icon = document.createElement("i");
    icon.className = `ti ti-${iconClass}`;
    icon.setAttribute("aria-hidden", "true");
    btn.appendChild(icon);
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      onClick(e);
    });
    return btn;
  }

  const cardIconBtns = [
    makeCardIconBtn("external-link", "Copy URL", (e) => {
      if (e.ctrlKey && job.url) {
        // Ctrl+click opens the source URL in a new tab; a normal click
        // keeps the existing "copy URL" behavior.
        window.open(job.url, "_blank", "noopener,noreferrer");
        return;
      }
      copyJobLink(job.filename, job.url);
    }),
    makeCardIconBtn("file-text", "Copy file name", () => copyJobFilename(job.filename)),
  ];
  if (!job.stash_tag_name) {
    cardIconBtns.push(makeCardIconBtn("forms", job.pending_filename ? "Rename (pending)" : "Rename", () => renameJobPrompt(job.filename)));
  }
  if (isDoneCard && job.source_type !== "stash") {
    cardIconBtns.push(makeCardIconBtn("arrow-right", "Move to target folder", () => moveJobToTarget(job.filename)));
  }
  if (status === "ERROR" || status === "CANCELLED") {
    cardIconBtns.push(makeCardIconBtn("refresh", "Retry", () => retryJob(job.filename)));
  }
  const cardIcons = document.createElement("div");
  cardIcons.className = "job-card-icons";
  cardIconBtns.forEach((btn) => cardIcons.appendChild(btn));

  // Footer row - meta/size text (when present) plus the icon group,
  // on their own line below the title/path so the icons no longer
  // share the title's line and eat into its available width.
  const footer = document.createElement("div");
  footer.className = "job-card-footer";

  if (isDownloadingCard) {
    const stats = document.createElement("div");
    stats.className = "job-stats";
    stats.textContent = "Initializing metrics...";
    titlePathCol.appendChild(stats);

    const track = document.createElement("div");
    track.className = "job-progress-track";
    const fill = document.createElement("div");
    fill.className = "job-progress-fill";
    track.appendChild(fill);
    titlePathCol.appendChild(track);

    footer.appendChild(cardIcons);
    body.appendChild(footer);
    card.appendChild(body);
    updateProgressDOM(card, job);
  } else if (isQueuedCard) {
    card.classList.add("queued");
    const stats = document.createElement("div");
    stats.className = "job-stats";
    stats.textContent = "Queued — waiting for a download slot in this playlist...";
    titlePathCol.appendChild(stats);

    footer.appendChild(cardIcons);
    body.appendChild(footer);
    card.appendChild(body);
  } else {
    card.classList.add(status === "DONE" ? "done" : status === "CANCELLED" ? "cancelled" : "error");
    if (status === "DONE") {
      const metaParts = [];
      if (job.ext) metaParts.push(job.ext);
      if (!job.is_audio && job.width && job.height) {
        metaParts.push(`${job.width}\u00d7${job.height}`);
        const ar = aspectRatioLabel(job.width, job.height);
        if (ar) metaParts.push(ar);
      }
      if (!job.is_audio && job.video_codec) metaParts.push(job.video_codec.toUpperCase());
      if (job.is_audio && job.audio_codec) metaParts.push(job.audio_codec.toUpperCase());
      const durText = formatDuration(job.duration);
      if (durText) metaParts.push(durText);
      if (job.file_size) metaParts.push(job.file_size);

      if (metaParts.length) {
        const meta = document.createElement("div");
        meta.className = "job-size";
        meta.textContent = metaParts.join("  •  ");
        footer.appendChild(meta);
      }

      // Twin (re-encoded or otherwise) size/resolution, shown as its
      // own line right under the source file's own meta line so the
      // two are easy to compare at a glance. Carries a data attribute
      // so updateJobCardEncodeProgress() can refresh it in place the
      // instant a matching encode job completes, without a full
      // re-render of the card.
      const twinInfo = getTwinDisplayInfo(job);
      const twinMeta = document.createElement("div");
      twinMeta.className = "job-twin-size";
      twinMeta.dataset.role = "twin-meta";
      if (twinInfo) {
        const twinParts = [];
        if (twinInfo.width && twinInfo.height) twinParts.push(`${twinInfo.width}\u00d7${twinInfo.height}`);
        if (twinInfo.sizeLabel) twinParts.push(twinInfo.sizeLabel);
        if (twinInfo.pct !== null) twinParts.push(`${twinInfo.pct}% of source`);
        twinMeta.textContent = `Twin: ${twinParts.join("  •  ")}`;
      } else {
        twinMeta.classList.add("hidden");
      }
      footer.appendChild(twinMeta);

      // Playback progress - shown for every completed file (not just
      // ones with a saved position) so scanning the ledger tells you
      // at a glance what you've started vs. never touched. A file
      // marked fully_played but currently at position 0 (i.e. not
      // mid-rewatch) shows a full green bar rather than an empty one -
      // an empty bar would misleadingly suggest "never watched", when
      // finishing playback is exactly what resets playback_position
      // back to 0 for next time. A rewatch-in-progress always takes
      // priority in what's displayed, using the normal amber
      // in-progress color even if fully_played is also set.
      // Only show the playback bar when there is actual playback progress
      // (or the file has been fully watched). A saved position of 0/null
      // means there is nothing useful to display, so don't leave an empty bar.
      if (job.duration > 0 && (job.playback_position > 0 || job.fully_played)) {
        const track = document.createElement("div");
        track.className = "job-playback-track";
        const fill = document.createElement("div");
        fill.className = "job-playback-fill";
        const inProgress = job.playback_position > 0;
        let pct;
        if (job.fully_played && !inProgress) {
          pct = 100;
          fill.classList.add("watched-complete");
        } else {
          pct = Math.max(0, Math.min(100, (job.playback_position / job.duration) * 100));
        }
        fill.style.width = `${pct}%`;
        track.title = !inProgress && !job.fully_played
          ? "Not started yet"
          : `${formatDuration(job.playback_position)} / ${formatDuration(job.duration)}`;
        track.appendChild(fill);
        titlePathCol.appendChild(track);
      }

      // Live encode progress, if this file currently has an active
      // Encode Manager job (queued or actively encoding) - see
      // findEncodeJobFor(). Independent of the playback bar above; a
      // file can be re-encoded while its original still tracks its own
      // watch position.
      const encodeJob = findEncodeJobFor(job.filename);
      if (encodeJob && (encodeJob.status === "QUEUED" || encodeJob.status === "ENCODING")) {
        const row = document.createElement("div");
        row.className = "job-encode-row";
        row.dataset.encodeJobId = encodeJob.id;

        const track = document.createElement("div");
        track.className = "job-encode-track";
        const fill = document.createElement("div");
        fill.className = "job-encode-fill";
        const pct = encodeJob.status === "ENCODING" ? Math.max(0, Math.min(100, parseFloat(encodeJob.pct) || 0)) : 0;
        fill.style.width = `${pct}%`;
        track.title = encodeJob.status === "QUEUED" ? "Queued for encoding..." : `Encoding: ${pct}%`;
        track.appendChild(fill);
        row.appendChild(track);

        const label = document.createElement("span");
        label.className = "job-encode-label";
        label.textContent = encodeJob.status === "QUEUED" ? "Queued" : `${pct}%`;
        row.appendChild(label);

        const cancelBtn = document.createElement("button");
        cancelBtn.className = "job-encode-cancel";
        cancelBtn.title = "Cancel encoding";
        cancelBtn.innerHTML = '<i class="ti ti-x" aria-hidden="true"></i>';
        cancelBtn.addEventListener("click", async (e) => {
          e.stopPropagation();
          await cancelEncodeJob(encodeJob.id);
        });
        row.appendChild(cancelBtn);

        titlePathCol.appendChild(row);
      }
    }
    footer.appendChild(cardIcons);
    body.appendChild(footer);
    card.appendChild(body);
  }

  // Clicking the thumbnail itself starts playback directly (for
  // completed items); clicking anywhere else on the card opens the
  // options menu. For non-completed items there's nothing to play yet,
  // so a thumbnail click there just falls through to the same menu
  // behavior as the rest of the card.
  addFileDragSupport(card, job);

  thumb.addEventListener("click", (e) => {
    if (state.selectionMode) {
      if (!isSelectable(job)) return;
      e.stopPropagation();
      toggleSelection(job.filename);
      return;
    }
    if (job.status === "DONE") {
      e.stopPropagation();
      openMediaModal(job.filename, job.is_audio);
    }
  });

  card.addEventListener("click", (e) => {
    e.stopPropagation();
    if (state.selectionMode) {
      if (!isSelectable(job)) return;
      toggleSelection(job.filename);
      return;
    }
    openJobMenu(e.clientX, e.clientY, job);
  });

  return card;
}

async function retryJob(filename) {
  try {
    const res = await fetch("/api/jobs/retry", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename }),
    });
    const data = await res.json();
    if (res.ok) {
      state.jobs.set(data.job.filename, data.job);
      renderLedger();
    } else {
      flashStatus(data.error || "Couldn't retry that download.");
    }
  } catch (e) {
    flashStatus("Couldn't reach the server to retry that download.");
  }
}

function buildTooltip(job) {
  let t = `File: ${job.filename}\nPath: ${joinDisplayPath(state.saveDirPath, job.filename, job.ext)}\nURL: ${job.url || ""}`;
  if (job.ext) t += `\nType: ${job.ext}`;
  if (!job.is_audio && job.width && job.height) {
    t += `\nResolution: ${job.width}\u00d7${job.height}`;
    const ar = aspectRatioLabel(job.width, job.height);
    if (ar) t += ` (${ar})`;
  }
  if (!job.is_audio && job.video_codec) t += `\nCodec: ${job.video_codec.toUpperCase()}`;
  if (job.is_audio && job.audio_codec) t += `\nCodec: ${job.audio_codec.toUpperCase()}`;
  const durText = formatDuration(job.duration);
  if (durText) t += `\nDuration: ${durText}`;
  if (job.file_size) t += `\nSize: ${job.file_size}`;
  if (job.status === "DONE" && job.has_twin) t += `\nTwin copy available in Converted/`;
  return t;
}

// A history entry is a plain log record (timestamp/status/filename/url) -
// not a ledger job, since the file it refers to may have been moved,
// renamed, or deleted since it was downloaded. It gets its own simpler
// card, built from the same visual pieces as buildJobCard for a
// consistent look, with a status icon standing in for the thumbnail.
const HISTORY_STATUS_ICON = { DONE: "🎬", ERROR: "⚠️", CANCELLED: "🚫" };

function buildHistoryCard(entry) {
  const card = document.createElement("div");
  card.className = "job-card history-card";
  card.classList.add(
    entry.status === "DONE" ? "done" : entry.status === "CANCELLED" ? "cancelled" : "error"
  );
  card.dataset.filename = entry.filename;

  const thumb = document.createElement("div");
  thumb.className = "job-thumb";
  const placeholder = document.createElement("span");
  placeholder.className = "job-thumb-placeholder";
  placeholder.textContent = HISTORY_STATUS_ICON[entry.status] || "🕓";
  thumb.appendChild(placeholder);
  card.appendChild(thumb);

  const body = document.createElement("div");
  body.className = "job-card-body";

  const titleRow = document.createElement("div");
  titleRow.className = "job-title-row";
  const title = document.createElement("div");
  title.className = "job-title";
  title.textContent = entry.filename;
  title.title = `File: ${entry.filename}\nURL: ${entry.url}\nWhen: ${entry.timestamp}\nStatus: ${entry.status}`;
  titleRow.appendChild(title);
  body.appendChild(titleRow);

  const meta = document.createElement("div");
  meta.className = "job-size";
  meta.textContent = `${entry.timestamp}  •  ${entry.status}`;
  body.appendChild(meta);

  card.appendChild(body);

  card.addEventListener("click", (e) => {
    e.stopPropagation();
    openHistoryMenu(e.clientX, e.clientY, entry);
  });

  return card;
}

function updateJobCardProgress(filename, job) {
  const card = queueList.querySelector(`.job-card[data-filename="${cssEscape(filename)}"]`);
  if (card) updateProgressDOM(card, job);
}

function updateProgressDOM(card, job) {
  const stats = card.querySelector(".job-stats");
  const fill = card.querySelector(".job-progress-fill");
  if (!stats || !fill) return;
  if (job.speed === "mrg") {
    stats.textContent = "Merging audio and video streams...";
  } else {
    stats.textContent = `${job.pct}%  |  ${job.total}  |  ${job.speed}  |  ETA: ${job.eta}`;
  }
  const pct = parseFloat(job.pct) || 0;
  fill.style.width = `${Math.max(0, Math.min(100, pct))}%`;
}

function cssEscape(s) {
  return s.replace(/["\\]/g, "\\$&");
}

// Targeted DOM patch for a throttled encode-progress tick, mirroring
// updateJobCardProgress()/updateProgressDOM() above for the same
// reason: rebuilding the whole card on every tick (via renderLedger's
// signature diffing) would replay the .job-card-enter fade-in
// constantly and is needless work besides. If the row isn't in the DOM
// yet (job just started, card not yet rebuilt to show it), this is a
// harmless no-op - the next structural event (encode_job_added/updated)
// triggers a real renderLedger() that adds it.
function updateJobCardEncodeProgress(encodeJob) {
  const filename = stemOf(encodeJob.source_filename || "");
  const card = queueList.querySelector(`.job-card[data-filename="${cssEscape(filename)}"]`);
  if (!card) return;
  const row = card.querySelector(`.job-encode-row[data-encode-job-id="${cssEscape(encodeJob.id)}"]`);
  if (!row) return;
  const fill = row.querySelector(".job-encode-fill");
  const label = row.querySelector(".job-encode-label");
  const track = row.querySelector(".job-encode-track");
  if (!fill || !label) return;
  const pct = Math.max(0, Math.min(100, parseFloat(encodeJob.pct) || 0));
  fill.style.width = `${pct}%`;
  label.textContent = `${pct}%`;
  if (track) track.title = `Encoding: ${pct}%`;
}

// Every submenu flyout in the app - Copy/File (job menu) and
// Folders/Settings (logo menu) all share this one open/close/position
// mechanism, so anything that resets menu state just walks this list.
const ALL_FLYOUTS = [openWithFlyout, copyFlyout, fileFlyout, dlFolderQuickMenu, targetFolderQuickMenu, urlArgsFlyout, stashMenuFlyout, ledgerMoreMenu, ledgerFilterPresetMenu];

function hideAllFlyouts() {
  for (const flyout of ALL_FLYOUTS) flyout.classList.add("hidden");
  closeAllTreeFlyouts();
}

// ── Context menus ─────────────────────────────────────────────
function openJobMenu(x, y, job) {
  historyMenu.classList.add("hidden");
  hideAllFlyouts();

  const isDownloading = job.status === "DOWNLOADING";
  const isQueued = job.status === "QUEUED";
  const isDone = job.status === "DONE";
  const isVideo = isDone && !job.is_audio;
  const isAudioDone = isDone && job.is_audio;
  el("ctx-cancel-job").classList.toggle("hidden", !isDownloading && !isQueued);
  el("ctx-play-video").classList.toggle("hidden", !isVideo);
  el("ctx-play-audio").classList.toggle("hidden", !isAudioDone);
  // Offered whenever this file has a twin sitting in Converted/ -
  // regardless of how it got there (re-encode, audio sync, or just
  // dropped in by hand). Driven by job.has_twin, the direct Converted/
  // filesystem check refreshed on every Refresh press/auto-refresh -
  // NOT isReencoded()/isSynchronized(), since those miss a twin left
  // over from before a server restart or placed manually.
  el("ctx-play-converted").classList.toggle(
    "hidden",
    !isDone || !job.has_twin,
  );
  el("ctx-extract-audio").classList.toggle("hidden", !isVideo);
  // Jumps straight into the encode setup modal with this file
  // preselected as the source - only makes sense for a completed,
  // non-audio download since that's all the encoder can take as input
  // (mirrors the /api/encode/sources gating). Hidden if the file is
  // already synchronized, since a re-encode twin and a sync twin would
  // both want the same Converted/<stem> slot (see isSynchronized), or
  // if an encode job for this file is already queued/running (its live
  // progress already shows right on the card - starting a second one
  // for the same source would just confuse the single progress slot).
  const activeEncode = findEncodeJobFor(job.filename);
  const isEncodingNow = activeEncode && (activeEncode.status === "QUEUED" || activeEncode.status === "ENCODING");
  el("ctx-reencode-file").classList.toggle("hidden", !isVideo || isSynchronized(job.filename) || isEncodingNow);
  // Same twin-slot logic in reverse: only offered for a completed video
  // with an audio track, and only if there isn't already a re-encode
  // twin sitting in Converted/ for this file.
  el("ctx-sync-audio").classList.toggle(
    "hidden",
    !isVideo || !job.audio_codec || isReencoded(job.filename),
  );
  // Shown for any completed item (video or audio) once at least one
  // external program is configured; enabled/disabled state (local vs
  // remote) is applied once at boot via applyLocalOnlyUI.
  el("ctx-open-with").classList.toggle("hidden", !(isDone && state.externalPrograms.length > 0));

  // Copy and File are submenu triggers now (see copy-flyout/file-flyout)
  // rather than flat top-level items - the trigger itself is shown
  // whenever at least one of its children would be, and the individual
  // rows inside each flyout are toggled the same way they always were.
  // Copying the link/filename works fine mid-download too (both are
  // already known the moment the job starts), so these stay visible
  // regardless of status - only file-system actions below (rename,
  // move, open folder, delete) still require the download to be done.
  el("ctx-copy-link").classList.remove("hidden");
  el("ctx-copy-filename").classList.remove("hidden");
  el("ctx-copy-submenu").classList.remove("hidden");

  el("ctx-rename-file").classList.toggle("hidden", !!job.stash_tag_name);
  el("ctx-rename-file").textContent = job.pending_filename ? "Rename (pending)" : "Rename File";
  el("ctx-move-to-target").classList.toggle("hidden", !isDone || job.source_type === "stash");
  el("ctx-replace-source").classList.toggle("hidden", !isDone || job.source_type !== "stash" || !job.source_path);
  el("ctx-replace-with-twin").classList.toggle("hidden", !isDone || !job.has_twin);
  el("ctx-open-folder").classList.toggle("hidden", !isDone);
  el("ctx-open-twin-folder").classList.toggle("hidden", !isDone || !job.has_twin);
  el("ctx-delete-twin").classList.toggle("hidden", !isDone || !job.has_twin);
  el("ctx-file-submenu").classList.toggle("hidden", isDownloading || isQueued);

  el("ctx-delete-file").classList.toggle("hidden", isDownloading || isQueued);

  jobMenu.dataset.filename = job.filename;
  jobMenu.dataset.url = job.url || "";
  positionMenu(jobMenu, x, y);
}

// Search History Mode's per-card menu - flat (no submenus needed for
// just four actions) and independent of job status, since a history
// record isn't a ledger job.
function openHistoryMenu(x, y, entry) {
  jobMenu.classList.add("hidden");
  hideAllFlyouts();

  historyMenu.dataset.filename = entry.filename;
  historyMenu.dataset.url = entry.url;
  historyMenu.dataset.timestamp = entry.timestamp;
  positionMenu(historyMenu, x, y);
}

el("ctx-cancel-job").addEventListener("click", async () => {
  const filename = jobMenu.dataset.filename;
  closeMenus();
  await fetch("/api/jobs/cancel", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ filename }),
  });
});

el("ctx-play-video").addEventListener("click", () => {
  const filename = jobMenu.dataset.filename;
  closeMenus();
  openMediaModal(filename, false);
});

el("ctx-play-audio").addEventListener("click", () => {
  const filename = jobMenu.dataset.filename;
  closeMenus();
  openMediaModal(filename, true);
});

el("ctx-play-converted").addEventListener("click", () => {
  const filename = jobMenu.dataset.filename;
  const job = state.jobs.get(filename);
  closeMenus();
  if (!job) return;
  openMediaModal(filename, !!job.is_audio, "converted");
});

el("ctx-replace-with-twin").addEventListener("click", async () => {
  const filename = jobMenu.dataset.filename;
  closeMenus();
  if (!filename) return;

  if (!window.confirm(`Replace "${filename}" with its twin?`)) return;

  flashStatus(`Replacing "${filename}" with twin...`);
  try {
    const res = await fetch("/api/jobs/replace-with-twin", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename }),
    });
    const data = await res.json();
    if (!res.ok) {
      window.alert(`Couldn't replace "${filename}":\n${data.error || "Unknown error"}`);
      return;
    }
    loadJobsIntoMap(data.jobs);
    renderLedger();
    flashStatus(`Replaced "${filename}" with twin.`);
  } catch (e) {
    window.alert("Couldn't reach the server to replace the file.");
  }
});

el("ctx-extract-audio").addEventListener("click", async () => {
  const filename = jobMenu.dataset.filename;
  closeMenus();
  flashStatus(`Extracting audio from "${filename}"...`);
  try {
    const res = await fetch("/api/jobs/extract-audio", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename }),
    });
    const data = await res.json();
    if (!res.ok) {
      window.alert(`Couldn't extract audio:\n${data.error || "Unknown error"}`);
      return;
    }
    state.jobs.set(data.job.filename, data.job);
    renderLedger();
    flashStatus(`Audio extracted: ${data.job.filename}`);
  } catch (e) {
    window.alert("Couldn't reach the server to extract audio.");
  }
});

el("ctx-reencode-file").addEventListener("click", () => {
  const filename = jobMenu.dataset.filename;
  closeMenus();
  openNewEncodeJobModal(filename);
});

el("ctx-sync-audio").addEventListener("click", () => {
  const filename = jobMenu.dataset.filename;
  closeMenus();
  openSyncAudioModal(filename);
});

el("ctx-open-with").addEventListener("click", () => {
  if (!IS_LOCAL) {
    flashStatus(REMOTE_ONLY_TOOLTIP);
    return;
  }
  // Click toggles the flyout open/closed rather than hover, so this
  // behaves sanely with touch/Moonlight-style input.
  if (!openWithFlyout.classList.contains("hidden")) {
    openWithFlyout.classList.add("hidden");
    return;
  }
  openOpenWithFlyout();
});

function closeOtherFlyouts(except) {
  for (const flyout of ALL_FLYOUTS) {
    if (flyout !== except) flyout.classList.add("hidden");
  }
  closeAllTreeFlyouts();
}

function positionFlyoutNextTo(flyoutEl, anchorMenu) {
  const anchorRect = anchorMenu.getBoundingClientRect();
  flyoutEl.classList.remove("hidden");
  const flyoutRect = flyoutEl.getBoundingClientRect();

  // Prefer opening to the right of the anchor menu; flip to the left if
  // that would run off the edge of the viewport.
  let left = anchorRect.right + 4;
  if (left + flyoutRect.width > window.innerWidth - 8) {
    left = anchorRect.left - flyoutRect.width - 4;
  }
  left = Math.max(8, left);

  let top = anchorRect.top;
  const maxTop = window.innerHeight - flyoutRect.height - 8;
  top = Math.min(top, Math.max(8, maxTop));

  flyoutEl.style.left = `${left}px`;
  flyoutEl.style.top = `${top}px`;
  lastMenuOpenAt = Date.now(); // extend the ghost-click grace window
}

// Used by the DL/Target quick-select dropdowns, which drop straight down
// from the folder-status line that was clicked rather than opening to
// the side like the submenu flyouts above.
function positionDropdownBelow(dropdownEl, anchorEl) {
  dropdownEl.classList.remove("hidden");
  const anchorRect = anchorEl.getBoundingClientRect();
  const dropdownRect = dropdownEl.getBoundingClientRect();

  let left = anchorRect.left;
  if (left + dropdownRect.width > window.innerWidth - 8) {
    left = window.innerWidth - dropdownRect.width - 8;
  }
  left = Math.max(8, left);

  let top = anchorRect.bottom + 4;
  const maxTop = window.innerHeight - dropdownRect.height - 8;
  top = Math.min(top, Math.max(8, maxTop));

  dropdownEl.style.left = `${left}px`;
  dropdownEl.style.top = `${top}px`;
  lastMenuOpenAt = Date.now();
}

function openOpenWithFlyout() {
  closeOtherFlyouts(openWithFlyout);
  openWithProgramsList.innerHTML = "";
  for (const prog of state.externalPrograms) {
    const item = document.createElement("div");
    item.className = "ctx-item";
    item.textContent = prog.name;
    item.title = prog.path;
    item.addEventListener("click", () => launchExternalProgram(prog.id));
    openWithProgramsList.appendChild(item);
  }
  positionFlyoutNextTo(openWithFlyout, jobMenu);
}

el("ctx-copy-submenu").addEventListener("click", () => {
  if (!copyFlyout.classList.contains("hidden")) {
    copyFlyout.classList.add("hidden");
    return;
  }
  closeOtherFlyouts(copyFlyout);
  positionFlyoutNextTo(copyFlyout, jobMenu);
});

el("ctx-file-submenu").addEventListener("click", () => {
  if (!fileFlyout.classList.contains("hidden")) {
    fileFlyout.classList.add("hidden");
    return;
  }
  closeOtherFlyouts(fileFlyout);
  positionFlyoutNextTo(fileFlyout, jobMenu);
});

async function launchExternalProgram(programId) {
  const filename = jobMenu.dataset.filename;
  closeMenus();
  try {
    const res = await fetch("/api/jobs/open-with", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename, program_id: programId }),
    });
    const data = await res.json();
    if (!res.ok) {
      window.alert(`Couldn't launch program:\n${data.error || "Unknown error"}`);
    }
  } catch (e) {
    window.alert("Couldn't reach the server to launch that program.");
  }
}

el("flyout-manage-programs").addEventListener("click", () => {
  closeMenus();
  if (!IS_LOCAL) {
    flashStatus(REMOTE_ONLY_TOOLTIP);
    return;
  }
  openExternalProgramsModal();
});

const NEAR_END_THRESHOLD_SECONDS = 5;
const POSITION_SAVE_INTERVAL_MS = 5000;
let mediaTracking = null; // { filename, element, lastSentAt }

function openMediaModal(filename, isAudio, source = "original") {
  videoModalTitle.textContent = source === "converted" ? `${filename} (Converted)` : filename;
  videoModalTitle.title = filename;
  const streamUrl = `/api/jobs/stream?filename=${encodeURIComponent(filename)}&source=${source}`;

  videoPlayer.classList.toggle("hidden", isAudio);
  audioPlayerWrap.classList.toggle("hidden", !isAudio);

  const job = state.jobs.get(filename);
  // The converted twin is a distinct file from the original, so resuming
  // at the original's last position (and tracking position against it
  // below) wouldn't make sense - play it from the start untracked.
  const resumePosition = source === "original" && job && job.playback_position > 0 ? job.playback_position : 0;
  const activeEl = isAudio ? audioPlayer : videoPlayer;

  const onLoadedMetadata = () => {
    if (resumePosition > 0 && activeEl.duration && resumePosition < activeEl.duration - NEAR_END_THRESHOLD_SECONDS) {
      activeEl.currentTime = resumePosition;
    }
    activeEl.removeEventListener("loadedmetadata", onLoadedMetadata);
  };
  activeEl.addEventListener("loadedmetadata", onLoadedMetadata);

  activeEl.src = streamUrl;
  videoModal.classList.remove("hidden");
  if (source === "original") {
    attachPlaybackTracking(filename, activeEl);
  } else {
    detachPlaybackTracking();
  }
  activeEl.play().catch(() => {}); // ignore autoplay-blocked rejections
}

function closeMediaModal() {
  flushPlaybackPosition();
  detachPlaybackTracking();

  videoPlayer.pause();
  videoPlayer.removeAttribute("src");
  videoPlayer.load(); // release the buffered stream instead of leaving it open
  audioPlayer.pause();
  audioPlayer.removeAttribute("src");
  audioPlayer.load();
  videoModal.classList.add("hidden");
}

function attachPlaybackTracking(filename, element) {
  detachPlaybackTracking();

  const tracking = { filename, element, lastSentAt: 0 };

  tracking.onTimeUpdate = () => {
    const now = Date.now();
    if (now - tracking.lastSentAt < POSITION_SAVE_INTERVAL_MS) return;
    tracking.lastSentAt = now;
    flushPlaybackPosition();
  };
  tracking.onPause = () => flushPlaybackPosition();
  tracking.onEnded = () => {
    // Work out the next queue item before marking this one complete. This is
    // important when "Hide completed" is enabled because completing the
    // current item can immediately remove it from the visible queue.
    const nextFilename = getNextPlaybackQueueItem(filename);

    sendPlaybackPosition(filename, 0, true);

    if (nextFilename) {
      const nextJob = state.jobs.get(nextFilename);
      if (nextJob) {
        // Let the current ended event finish before replacing the media
        // element's source. Keeping the transition asynchronous also gives
        // the position/completion update above a chance to settle.
        setTimeout(() => {
          if (mediaTracking && mediaTracking.filename === filename) {
            openMediaModal(nextFilename, !!nextJob.is_audio, "original");
          }
        }, 0);
      }
    }
  }; // finished - replay from the start next time, but remember it was fully watched/listened

  element.addEventListener("timeupdate", tracking.onTimeUpdate);
  element.addEventListener("pause", tracking.onPause);
  element.addEventListener("ended", tracking.onEnded);

  mediaTracking = tracking;
}

// Return the item immediately after the currently playing item in the
// queue's current sort/filter order. The queue UI is the source of truth for
// what "next" means, so changing the sort order or active filters also changes
// playback order.
function getNextPlaybackQueueItem(filename) {
  const jobs = getFilteredSortedJobs();
  const currentIndex = jobs.findIndex((job) => job.filename === filename);
  if (currentIndex < 0 || currentIndex >= jobs.length - 1) return null;
  return jobs[currentIndex + 1].filename;
}

function detachPlaybackTracking() {
  if (!mediaTracking) return;
  const { element, onTimeUpdate, onPause, onEnded } = mediaTracking;
  element.removeEventListener("timeupdate", onTimeUpdate);
  element.removeEventListener("pause", onPause);
  element.removeEventListener("ended", onEnded);
  mediaTracking = null;
}

function flushPlaybackPosition() {
  if (!mediaTracking) return;
  const { filename, element } = mediaTracking;
  if (!element.duration || isNaN(element.duration)) return;
  const nearEnd = element.currentTime >= element.duration - NEAR_END_THRESHOLD_SECONDS;
  sendPlaybackPosition(filename, nearEnd ? 0 : element.currentTime, nearEnd);
}

function sendPlaybackPosition(filename, position, completed = false) {
  fetch("/api/jobs/playback-position", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ filename, position, completed }),
  }).catch(() => {}); // best-effort - a dropped save just means less-precise resume next time

  const job = state.jobs.get(filename);
  if (job) {
    job.playback_position = position; // keep local state fresh within this session too
    // fully_played is sticky - only ever flips False -> True here, and
    // is never reset elsewhere (e.g. a partial rewatch afterwards still
    // updates playback_position normally, but doesn't un-mark it).
    if (completed) job.fully_played = true;
    renderLedger();
  }
}

el("video-modal-close").addEventListener("click", closeMediaModal);
videoModal.addEventListener("click", (e) => {
  if (e.target === videoModal) closeMediaModal();
});

// ── Synchronize Audio ────────────────────────────────────────
// syncAudioState.stage walks through: "original" -> "clip" -> "full",
// with Redo Clip stepping back to "original" and Discard stepping
// back to "clip". everCreatedThisSession tracks whether any render
// exists server-side yet, so a plain Close/Cancel with nothing done
// can skip the cleanup call entirely.
let syncAudioState = null; // { filename, stage, clipStart, everCreatedThisSession }

function openSyncAudioModal(filename) {
  const job = state.jobs.get(filename);
  if (!job) return;

  // appliedDelayMs tracks the delay actually baked into whatever's
  // currently playing (updated by createClip()/applyClipDelay()) - the
  // value Confirm Sync trusts, as opposed to whatever's live in the
  // delay input field, which can drift ahead of it via typing/nudging.
  syncAudioState = { filename, stage: "original", clipStart: null, everCreatedThisSession: false, appliedDelayMs: null };
  // A previous sync operation may have disabled the action buttons while
  // rendering. Reinitialize them every time the dialog is opened.
  setSyncButtonsDisabled(false);
  syncAudioTitle.textContent = "Synchronize Audio";
  // Placeholder until setSyncPlayerSource's header fetch (below) resolves
  // the literal on-disk filename actually loaded in the player.
  syncAudioFilename.textContent = filename;
  syncAudioFilename.title = filename;
  syncAudioDelayInput.value = job.audio_delay_ms || 0;
  syncAudioClipDurationInput.value = 10;
  fetch("/api/jobs/sync-audio/settings")
    .then(r => r.json())
    .then(data => { if (data.clip_duration_s > 0) syncAudioClipDurationInput.value = data.clip_duration_s; })
    .catch(() => {});
  setSyncAudioStatus("");

  // Already-synchronized files play their confirmed twin at first;
  // anything else starts from the original download. Either way, the
  // sync workflow itself (Create Clip, Confirm Sync) always renders
  // off the true original media, never off a previous twin.
  const source = job.synchronized ? "converted" : "original";
  setSyncPlayerSource(filename, source);
  syncAudioStageBadge.textContent = job.synchronized ? "Synchronized file loaded" : "Original file loaded";
  applySyncStageUI();
  syncAudioModal.classList.remove("hidden");
}

function setSyncPlayerSource(filename, source) {
  const url = `/api/jobs/stream?filename=${encodeURIComponent(filename)}&source=${source}&t=${Date.now()}`;
  syncAudioPlayer.src = url;
  // The <video> element gives no way to read response headers, so grab
  // the actual on-disk filename (with extension) via a tiny ranged fetch
  // of the same URL - this is what shows in the filename line, since the
  // sync workflow's in-progress files (clip/staging) don't share the
  // job's own filename.
  fetch(url, { headers: { Range: "bytes=0-0" } })
    .then(res => {
      const name = res.headers.get("X-Media-Filename");
      if (name) {
        const decoded = decodeURIComponent(name);
        syncAudioFilename.textContent = decoded;
        syncAudioFilename.title = decoded;
      }
    })
    .catch(() => {});
}

// Pauses and fully detaches the player before any request that will
// replace/delete the file it's currently showing - on Windows a file
// still open for reading by the player can't be written to, and this
// gives the browser (and the server's streaming generator) a moment
// to actually let go of it before the file op runs.
function detachSyncPlayer() {
  syncAudioPlayer.pause();
  syncAudioPlayer.removeAttribute("src");
  syncAudioPlayer.load();
  return new Promise((resolve) => setTimeout(resolve, 150));
}

function setSyncAudioStatus(text, kind) {
  syncAudioStatus.textContent = text;
  syncAudioStatus.classList.toggle("error", kind === "error");
  syncAudioStatus.classList.toggle("success", kind === "success");
}

function formatClipTime(seconds) {
  const s = Math.max(0, Math.round(seconds || 0));
  const m = Math.floor(s / 60);
  const rem = s % 60;
  return `${String(m).padStart(2, "0")}:${String(rem).padStart(2, "0")}`;
}

// Shows/hides/relabels the action buttons and delay dial for the
// current stage. The delay dial only makes sense while a clip is
// loaded (nothing to preview it against beforehand, nothing left to
// tweak once the full render is staged).
function applySyncStageUI() {
  const stage = syncAudioState ? syncAudioState.stage : "original";
  el("sync-audio-controls").classList.toggle("hidden", stage === "full");
  syncAudioCancelBtn.classList.toggle("hidden", stage === "full");
  syncAudioRedoClipBtn.classList.toggle("hidden", stage !== "clip");
  syncAudioConfirmBtn.classList.toggle("hidden", stage !== "clip");
  syncAudioDiscardBtn.classList.toggle("hidden", stage !== "full");
  syncAudioAcceptBtn.classList.toggle("hidden", stage !== "full");
  syncAudioPrimaryBtn.classList.toggle("hidden", stage === "full");
  syncAudioPrimaryBtn.textContent = stage === "clip" ? "Apply Sync" : "Create Clip";
}

function setSyncButtonsDisabled(disabled) {
  syncAudioPrimaryBtn.disabled = disabled;
  syncAudioRedoClipBtn.disabled = disabled;
  syncAudioConfirmBtn.disabled = disabled;
  syncAudioDiscardBtn.disabled = disabled;
  syncAudioAcceptBtn.disabled = disabled;
}

function nudgeSyncAudioDelay(deltaMs) {
  const current = parseFloat(syncAudioDelayInput.value) || 0;
  syncAudioDelayInput.value = current + deltaMs;
}

async function saveSyncClipDuration() {
  const value = parseFloat(syncAudioClipDurationInput.value);
  if (!Number.isFinite(value) || value <= 0) {
    setSyncAudioStatus("Clip duration must be greater than 0 seconds.", "error");
    return false;
  }
  try {
    const res = await fetch("/api/jobs/sync-audio/settings", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ clip_duration_s: value }),
    });
    const data = await res.json();
    if (!res.ok) {
      setSyncAudioStatus(data.error || "Couldn't save clip duration.", "error");
      return false;
    }
    syncAudioClipDurationInput.value = data.clip_duration_s;
    return true;
  } catch (e) {
    setSyncAudioStatus("Couldn't save clip duration.", "error");
    return false;
  }
}

syncAudioClipDurationInput.addEventListener("change", saveSyncClipDuration);
syncAudioClipDurationInput.addEventListener("blur", saveSyncClipDuration);

el("sync-audio-dial-down-big").addEventListener("click", () => nudgeSyncAudioDelay(-100));
el("sync-audio-dial-down-small").addEventListener("click", () => nudgeSyncAudioDelay(-10));
el("sync-audio-dial-up-small").addEventListener("click", () => nudgeSyncAudioDelay(10));
el("sync-audio-dial-up-big").addEventListener("click", () => nudgeSyncAudioDelay(100));

// Create Clip / Apply Sync share one button - same slot in the
// workflow, just a different render underneath depending on stage.
syncAudioPrimaryBtn.addEventListener("click", async () => {
  if (!syncAudioState) return;
  if (syncAudioState.stage === "clip") {
    await applyClipDelay();
  } else {
    await createClip();
  }
});

async function createClip() {
  const { filename } = syncAudioState;
  const startSeconds = syncAudioPlayer.currentTime || 0;
  // Carry forward whatever delay is currently dialed in (e.g. after Redo
  // Clip, or a job's previously-confirmed delay on the very first clip of
  // a re-sync session) - matches the backend's create_clip() contract,
  // which bakes this in immediately so the new clip previews accurately
  // instead of silently reverting to 0. See bakedDelayMs below for why
  // this is also the value Confirm Sync should trust afterward.
  const bakedDelayMs = parseFloat(syncAudioDelayInput.value) || 0;

  setSyncButtonsDisabled(true);
  setSyncAudioStatus(`Cutting a clip from ${formatClipTime(startSeconds)}...`);
  await detachSyncPlayer();

  try {
    const res = await fetch("/api/jobs/sync-audio/create-clip", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename, start_seconds: startSeconds, delay_ms: bakedDelayMs }),
    });
    const data = await res.json();
    if (!res.ok) {
      setSyncAudioStatus(data.error || "Couldn't create the clip.", "error");
      return;
    }
    syncAudioState.stage = "clip";
    syncAudioState.clipStart = data.render.clip_start;
    syncAudioState.everCreatedThisSession = true;
    // The field already holds bakedDelayMs - leave it alone rather than
    // zeroing it out, and record it as the delay actually baked into the
    // clip that's about to play, so Confirm Sync can trust it without
    // requiring a redundant Apply Sync click when nothing's changed.
    syncAudioState.appliedDelayMs = bakedDelayMs;
    setSyncPlayerSource(filename, "sync-clip");
    syncAudioStageBadge.textContent = bakedDelayMs
      ? `Clip from ${formatClipTime(syncAudioState.clipStart)} loaded (${bakedDelayMs} ms delay baked in)`
      : `Clip from ${formatClipTime(syncAudioState.clipStart)} loaded`;
    setSyncAudioStatus("");
    applySyncStageUI();
  } catch (e) {
    setSyncAudioStatus("Couldn't reach the server to create the clip.", "error");
  } finally {
    setSyncButtonsDisabled(false);
  }
}

async function applyClipDelay() {
  const { filename } = syncAudioState;
  const delayMs = parseFloat(syncAudioDelayInput.value) || 0;

  setSyncButtonsDisabled(true);
  setSyncAudioStatus(`Rendering the clip with a ${delayMs} ms delay...`);
  await detachSyncPlayer();

  try {
    const res = await fetch("/api/jobs/sync-audio/apply-clip-delay", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename, delay_ms: delayMs }),
    });
    const data = await res.json();
    if (!res.ok) {
      setSyncAudioStatus(data.error || "Couldn't render the synced clip.", "error");
      return;
    }
    // This is now the delay actually baked into what's playing - the
    // value Confirm Sync should trust (see syncAudioConfirmBtn handler).
    syncAudioState.appliedDelayMs = delayMs;
    setSyncPlayerSource(filename, "sync-clip");
    setSyncAudioStatus(`Clip re-rendered with a ${delayMs} ms delay.`, "success");
  } catch (e) {
    setSyncAudioStatus("Couldn't reach the server to render the synced clip.", "error");
  } finally {
    setSyncButtonsDisabled(false);
  }
}

syncAudioRedoClipBtn.addEventListener("click", async () => {
  if (!syncAudioState) return;
  const { filename } = syncAudioState;

  setSyncButtonsDisabled(true);
  setSyncAudioStatus("Reloading the full video...");
  await detachSyncPlayer();

  try {
    const res = await fetch("/api/jobs/sync-audio/redo-clip", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename }),
    });
    const data = await res.json();
    if (!res.ok) {
      setSyncAudioStatus(data.error || "Couldn't reload the full video.", "error");
      return;
    }
    syncAudioState.stage = "original";
    syncAudioState.clipStart = null;
    const job = state.jobs.get(filename);
    setSyncPlayerSource(filename, job && job.synchronized ? "converted" : "original");
    syncAudioStageBadge.textContent = job && job.synchronized ? "Synchronized file loaded" : "Original file loaded";
    setSyncAudioStatus("");
    applySyncStageUI();
  } catch (e) {
    setSyncAudioStatus("Couldn't reach the server to reload the full video.", "error");
  } finally {
    setSyncButtonsDisabled(false);
  }
});

syncAudioConfirmBtn.addEventListener("click", async () => {
  if (!syncAudioState) return;
  const { filename } = syncAudioState;
  const fieldDelayMs = parseFloat(syncAudioDelayInput.value) || 0;
  const appliedDelayMs = syncAudioState.appliedDelayMs != null ? syncAudioState.appliedDelayMs : 0;

  // Confirm Sync must render the full video with the SAME delay the
  // user actually previewed via Create Clip / Apply Sync - not
  // whatever happens to be sitting in the field, which can drift out
  // of sync with the preview if it was typed/nudged (dial buttons)
  // without an Apply Sync click afterward. Rendering an unpreviewed
  // value here is exactly how a full sync ends up not matching the
  // delay the user actually decided on.
  if (Math.abs(fieldDelayMs - appliedDelayMs) > 0.001) {
    setSyncAudioStatus(
      `Delay changed to ${fieldDelayMs} ms since the last preview (clip is playing at ${appliedDelayMs} ms). `
      + `Click "Apply Sync" to preview it before confirming.`,
      "error",
    );
    return;
  }
  const delayMs = appliedDelayMs;

  setSyncButtonsDisabled(true);
  setSyncAudioStatus("Synching full video, please wait...");
  await detachSyncPlayer();

  try {
    const res = await fetch("/api/jobs/sync-audio/render-full", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename, delay_ms: delayMs }),
    });
    const data = await res.json();
    if (!res.ok) {
      setSyncAudioStatus(data.error || "Couldn't render the full synced video.", "error");
      return;
    }
    syncAudioState.stage = "full";
    syncAudioState.everCreatedThisSession = true;
    syncAudioState.lastDelayMs = delayMs;
    setSyncPlayerSource(filename, "sync-full");
    syncAudioStageBadge.textContent = "Full Video Synchronized";
    setSyncAudioStatus("");
    applySyncStageUI();
  } catch (e) {
    setSyncAudioStatus("Couldn't reach the server to render the full synced video.", "error");
  } finally {
    setSyncButtonsDisabled(false);
  }
});

syncAudioAcceptBtn.addEventListener("click", async () => {
  if (!syncAudioState) return;
  const { filename } = syncAudioState;
  const delayMs = syncAudioState.lastDelayMs != null
    ? syncAudioState.lastDelayMs
    : (parseFloat(syncAudioDelayInput.value) || 0);

  setSyncButtonsDisabled(true);
  setSyncAudioStatus("Accepting the sync...");
  await detachSyncPlayer();

  try {
    const res = await fetch("/api/jobs/sync-audio/accept", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename, delay_ms: delayMs }),
    });
    const data = await res.json();
    if (!res.ok) {
      setSyncAudioStatus(data.error || "Couldn't accept the sync.", "error");
      setSyncButtonsDisabled(false);
      return;
    }
    state.jobs.set(filename, data.job);
    renderLedger();
    flashStatus(`Synchronized: ${filename}`);
    hideSyncAudioModal();
  } catch (e) {
    setSyncAudioStatus("Couldn't reach the server to accept the sync.", "error");
    setSyncButtonsDisabled(false);
  }
});

syncAudioDiscardBtn.addEventListener("click", async () => {
  if (!syncAudioState) return;
  const { filename } = syncAudioState;

  setSyncButtonsDisabled(true);
  setSyncAudioStatus("Discarding the full render...");
  await detachSyncPlayer();

  try {
    const res = await fetch("/api/jobs/sync-audio/discard-full", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename }),
    });
    const data = await res.json();
    if (!res.ok) {
      setSyncAudioStatus(data.error || "Couldn't discard the full render.", "error");
      return;
    }
    syncAudioState.stage = "clip";
    setSyncPlayerSource(filename, "sync-clip");
    syncAudioStageBadge.textContent = `Clip from ${formatClipTime(syncAudioState.clipStart)} loaded`;
    setSyncAudioStatus("");
    applySyncStageUI();
  } catch (e) {
    setSyncAudioStatus("Couldn't reach the server to discard the full render.", "error");
  } finally {
    setSyncButtonsDisabled(false);
  }
});

// UI-only teardown used right after a successful Accept - the backend
// has already cleaned up everything, so no cancel call is needed.
function hideSyncAudioModal() {
  syncAudioModal.classList.add("hidden");
  syncAudioPlayer.pause();
  syncAudioPlayer.removeAttribute("src");
  syncAudioPlayer.load();
  syncAudioState = null;
}

async function closeSyncAudioModal(runCancel = true) {
  const session = syncAudioState;
  await detachSyncPlayer();
  syncAudioModal.classList.add("hidden");
  syncAudioState = null;

  if (runCancel && session && session.everCreatedThisSession) {
    try {
      await fetch("/api/jobs/sync-audio/cancel", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ filename: session.filename }),
      });
    } catch (e) {
      // Best-effort - an unconfirmed render being left behind isn't
      // harmful, just untidy; the next sync session will overwrite it.
    }
  }
}

el("sync-audio-close").addEventListener("click", () => closeSyncAudioModal(true));
el("sync-audio-cancel-btn").addEventListener("click", () => closeSyncAudioModal(true));

el("ctx-delete-file").addEventListener("click", async () => {
  const filename = jobMenu.dataset.filename;
  closeMenus();
  if (!window.confirm(`Delete "${filename}"?\n\nThis removes the file from disk and can't be undone.`)) return;

  try {
    await fetch("/api/jobs/delete", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename }),
    });
    state.jobs.delete(filename);
    renderLedger();
  } catch (e) {
    window.alert("Couldn't reach the server to delete that file.");
  }
});

// The four functions below back both the card's options-menu items and
// its quick-action icon row, so the two entry points can't drift apart.
async function renameJobPrompt(filename) {
  const job = state.jobs.get(filename);
  const proposed = window.prompt("Rename to:", (job && job.pending_filename) || filename);
  if (proposed === null) return;
  const trimmed = proposed.trim();
  if (!trimmed || trimmed === filename) return;

  try {
    const res = await fetch("/api/jobs/rename", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename, new_filename: trimmed }),
    });
    const data = await res.json();
    if (!res.ok) {
      window.alert(`Couldn't rename:\n${data.error || "Unknown error"}`);
      return;
    }
    loadJobsIntoMap(data.jobs);
    renderLedger();
    if (data.pending) {
      flashStatus(`Rename queued: "${data.new_filename}" (applied when download finishes)`);
    }
  } catch (e) {
    window.alert("Couldn't reach the server to rename that file.");
  }
}

// navigator.clipboard.writeText() only works on https:// or localhost -
// browsers gate it purely by URL scheme, so a plain-http Tailscale address
// (even though Tailscale itself encrypts the connection) gets refused,
// especially on mobile Safari/Chrome. Fall back to the older execCommand
// copy trick, and as a last resort a prompt() the user can manually
// select-and-copy from. Returns true if a real clipboard write succeeded
// (only then do we claim "copied" - the other paths tell the user what
// happened instead of overpromising).
async function copyTextToClipboard(text) {
  if (navigator.clipboard && window.isSecureContext) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (e) {
      // fall through to the legacy path below
    }
  }

  try {
    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.style.position = "fixed";
    textarea.style.top = "-1000px";
    textarea.style.opacity = "0";
    document.body.appendChild(textarea);
    textarea.focus();
    textarea.select();
    const ok = document.execCommand("copy");
    textarea.remove();
    if (ok) return true;
  } catch (e) {
    // fall through to the manual prompt below
  }

  window.prompt("Couldn't copy automatically - select and copy manually:", text);
  return false;
}

async function copyJobLink(filename, directUrl) {
  try {
    let urlToCopy = directUrl || "";
    if (!urlToCopy) {
      // Fallback for ledger entries with no recorded url (e.g. a file
      // picked up straight off disk with no queue record) - only the
      // history log might have it. Downloading/queued jobs always have
      // a url on the job object itself, so this path is skipped for them.
      const res = await fetch("/api/history-search", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: filename }),
      });
      const data = await res.json();
      urlToCopy = data.url || "";
    }
    if (urlToCopy) {
      const copied = await copyTextToClipboard(urlToCopy);
      if (copied) flashStatus("Link copied to clipboard.");
    } else {
      flashStatus("No link found for this file.");
    }
  } catch (e) {
    flashStatus("Couldn't copy the link.");
  }
}

async function copyJobFilename(filename) {
  try {
    const copied = await copyTextToClipboard(filename);
    if (copied) flashStatus(`Copied name: ${filename}`);
  } catch (e) {
    flashStatus("Couldn't copy the file name.");
  }
}

// Shows the Transfer Original / Transfer Converted / Cancel prompt and
// resolves with "original", "reencoded", or null (cancelled). Same modal
// for both twin kinds - info.kind ("reencoded" or "synchronized") just
// swaps the second card's label and button text.
function promptReencodeChoice(info) {
  return new Promise((resolve) => {
    const isSync = info.kind === "synchronized";
    reencodeChoiceTitle.textContent = isSync ? "Synchronized version found" : "Re-encoded version found";
    reencodeChoiceReencodedLabel.textContent = isSync ? "Synchronized" : "Re-encoded";
    reencodeChoiceReencodedBtn.textContent = isSync ? "Transfer Synchronized" : "Transfer Re-encoded";

    reencodeChoiceFilename.textContent = info.filename;
    reencodeChoiceOriginalSize.textContent = info.original.size_label || "Unknown size";
    reencodeChoiceOriginalRes.textContent = info.original.width && info.original.height
      ? `${info.original.width}\u00d7${info.original.height}` : "";
    reencodeChoiceReencodedSize.textContent = info.reencoded.size_label || "Unknown size";
    reencodeChoiceReencodedRes.textContent = info.reencoded.width && info.reencoded.height
      ? `${info.reencoded.width}\u00d7${info.reencoded.height}` : "";

    const cleanup = (result) => {
      reencodeChoiceModal.classList.add("hidden");
      reencodeChoiceCancelBtn.removeEventListener("click", onCancel);
      reencodeChoiceOriginalBtn.removeEventListener("click", onOriginal);
      reencodeChoiceReencodedBtn.removeEventListener("click", onReencoded);
      resolve(result);
    };
    const onCancel = () => cleanup(null);
    const onOriginal = () => cleanup("original");
    const onReencoded = () => cleanup("reencoded");

    reencodeChoiceCancelBtn.addEventListener("click", onCancel);
    reencodeChoiceOriginalBtn.addEventListener("click", onOriginal);
    reencodeChoiceReencodedBtn.addEventListener("click", onReencoded);
    reencodeChoiceModal.classList.remove("hidden");
  });
}

// Posts the actual move request. Returns "moved", "cancelled", or
// "error" (in which case an alert has already been shown).
async function requestMoveToTarget(filename, variant) {
  try {
    const res = await fetch("/api/jobs/move-to-target", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(variant ? { filename, variant } : { filename }),
    });
    const data = await res.json();
    if (res.status === 409 && data.needs_decision) {
      const choice = await promptReencodeChoice(data);
      if (!choice) return "cancelled";
      return requestMoveToTarget(filename, choice);
    }
    if (!res.ok) {
      window.alert(`Couldn't move "${filename}":\n${data.error || "Unknown error"}`);
      return "error";
    }
    return "moved";
  } catch (e) {
    window.alert("Couldn't reach the server to move that file.");
    return "error";
  }
}

async function moveJobToTarget(filename) {
  const result = await requestMoveToTarget(filename, null);
  if (result === "moved") {
    state.jobs.delete(filename);
    renderLedger();
    flashStatus(`Moved to target: ${filename}`);
  }
}

el("ctx-rename-file").addEventListener("click", () => {
  const filename = jobMenu.dataset.filename;
  closeMenus();
  renameJobPrompt(filename);
});

el("ctx-copy-link").addEventListener("click", () => {
  const filename = jobMenu.dataset.filename;
  const directUrl = jobMenu.dataset.url || "";
  closeMenus();
  copyJobLink(filename, directUrl);
});

el("ctx-copy-filename").addEventListener("click", () => {
  const filename = jobMenu.dataset.filename;
  closeMenus();
  copyJobFilename(filename);
});

el("ctx-move-to-target").addEventListener("click", () => {
  const filename = jobMenu.dataset.filename;
  closeMenus();
  moveJobToTarget(filename);
});

async function requestReplaceSource(filename, variant, deleteTagIds) {
  try {
    const body = { filename };
    if (variant) body.variant = variant;
    if (deleteTagIds && deleteTagIds.length) body.delete_tag_ids = deleteTagIds;
    const res = await fetch("/api/jobs/replace-source", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (res.status === 409 && data.needs_decision) {
      const choice = await promptReencodeChoice(data);
      if (!choice) return { status: "cancelled" };
      return requestReplaceSource(filename, choice, deleteTagIds);
    }
    if (!res.ok) {
      window.alert(`Couldn't replace the Stash source:\n${data.error || "Unknown error"}`);
      return { status: "error" };
    }
    return {
      status: "replaced",
      deleted_tag_names: data.deleted_tag_names || [],
      tag_delete_error: data.tag_delete_error || null,
    };
  } catch (e) {
    window.alert("Couldn't reach the server to replace the Stash source.");
    return { status: "error" };
  }
}

// Shows the replace-source confirm modal, with one checkbox per tag on
// job.stash_tags (the full tag list saved when the scene was imported -
// see stash_integration.import_stash_scene), so any combination of them
// can be picked for deletion from the Stash scene. Resolves null if
// cancelled, or { deleteTagIds } if confirmed.
function promptReplaceSourceConfirm(job) {
  return new Promise((resolve) => {
    const filenameEl = el("replace-source-filename");
    const tagsSection = el("replace-source-tags-section");
    const tagList = el("replace-source-tag-list");
    const modal = el("replace-source-modal");
    const cancelBtn = el("replace-source-cancel-btn");
    const confirmBtn = el("replace-source-confirm-btn");

    filenameEl.textContent = job.filename;
    tagList.innerHTML = "";
    const tags = job.stash_tags || [];
    if (tags.length) {
      tags.forEach((tag) => {
        const row = document.createElement("div");
        row.className = "checkbox-row";
        const checkboxId = `replace-source-tag-${tag.id}`;
        row.innerHTML = `<input type="checkbox" id="${checkboxId}" data-tag-id="${tag.id}"><label for="${checkboxId}"></label>`;
        row.querySelector("label").textContent = tag.name;
        tagList.appendChild(row);
      });
      tagsSection.classList.remove("hidden");
    } else {
      tagsSection.classList.add("hidden");
    }

    const cleanup = (result) => {
      modal.classList.add("hidden");
      cancelBtn.removeEventListener("click", onCancel);
      confirmBtn.removeEventListener("click", onConfirm);
      resolve(result);
    };
    const onCancel = () => cleanup(null);
    const onConfirm = () => {
      const deleteTagIds = Array.from(tagList.querySelectorAll("input[type=checkbox]:checked"))
        .map((cb) => cb.dataset.tagId);
      cleanup({ deleteTagIds });
    };

    cancelBtn.addEventListener("click", onCancel);
    confirmBtn.addEventListener("click", onConfirm);
    modal.classList.remove("hidden");
  });
}

el("ctx-replace-source").addEventListener("click", async () => {
  const filename = jobMenu.dataset.filename;
  closeMenus();
  const job = state.jobs.get(filename);
  if (!job || job.source_type !== "stash") return;
  const confirmChoice = await promptReplaceSourceConfirm(job);
  if (!confirmChoice) return;
  const result = await requestReplaceSource(filename, null, confirmChoice.deleteTagIds);
  if (result.status === "replaced") {
    state.jobs.delete(filename);
    renderLedger();
    if (result.deleted_tag_names.length) {
      flashStatus(`Replaced Stash source and removed tag(s) "${result.deleted_tag_names.join(", ")}": ${filename}`);
    } else if (result.tag_delete_error) {
      flashStatus(`Replaced Stash source: ${filename} (couldn't remove tag(s): ${result.tag_delete_error})`);
    } else {
      flashStatus(`Replaced Stash source: ${filename}`);
    }
  }
});

el("ctx-open-folder").addEventListener("click", async () => {
  const filename = jobMenu.dataset.filename;
  closeMenus();
  try {
    const res = await fetch("/api/jobs/open-folder", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename }),
    });
    const data = await res.json();
    if (!res.ok) {
      window.alert(`Couldn't open Explorer:\n${data.error || "Unknown error"}`);
    }
  } catch (e) {
    window.alert("Couldn't reach the server to open Explorer.");
  }
});

el("ctx-open-twin-folder").addEventListener("click", async () => {
  const filename = jobMenu.dataset.filename;
  closeMenus();
  try {
    const res = await fetch("/api/jobs/open-twin-folder", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename }),
    });
    const data = await res.json();
    if (!res.ok) {
      window.alert(`Couldn't open the twin folder:\n${data.error || "Twin not found."}`);
    }
  } catch (e) {
    window.alert("Couldn't reach the server to open the twin folder.");
  }
});

el("ctx-delete-twin").addEventListener("click", async () => {
  const filename = jobMenu.dataset.filename;
  closeMenus();
  if (!filename) return;
  if (!window.confirm(`Delete the twin for "${filename}"?\n\nThe original file will not be affected.`)) return;
  try {
    const res = await fetch("/api/jobs/delete-twin", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename }),
    });
    const data = await res.json();
    if (!res.ok) {
      window.alert(`Couldn't delete the twin:\n${data.error || "Unknown error"}`);
      return;
    }
    loadJobsIntoMap(data.jobs);
    renderLedger();
    flashStatus(`Deleted twin: ${filename}`);
  } catch (e) {
    window.alert("Couldn't reach the server to delete the twin.");
  }
});

// ── Search History Mode's per-entry menu actions ────────────────
el("ctx-history-copy-link").addEventListener("click", async () => {
  const url = historyMenu.dataset.url || "";
  closeMenus();
  if (!url) { flashStatus("No link recorded for this entry."); return; }
  try {
    const copied = await copyTextToClipboard(url);
    if (copied) flashStatus("Link copied to clipboard.");
  } catch (e) {
    flashStatus("Couldn't copy the link.");
  }
});

el("ctx-history-copy-name").addEventListener("click", async () => {
  const filename = historyMenu.dataset.filename || "";
  closeMenus();
  try {
    const copied = await copyTextToClipboard(filename);
    if (copied) flashStatus(`Copied name: ${filename}`);
  } catch (e) {
    flashStatus("Couldn't copy the file name.");
  }
});

el("ctx-history-open-location").addEventListener("click", async () => {
  if (!IS_LOCAL) { flashStatus(REMOTE_ONLY_TOOLTIP); return; }
  const filename = historyMenu.dataset.filename;
  closeMenus();
  try {
    const res = await fetch("/api/jobs/open-folder", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename }),
    });
    const data = await res.json();
    if (!res.ok) {
      window.alert(`Couldn't open Explorer:\n${data.error || "File not found - it may have been moved or deleted."}`);
    }
  } catch (e) {
    window.alert("Couldn't reach the server to open Explorer.");
  }
});

el("ctx-history-delete").addEventListener("click", async () => {
  const filename = historyMenu.dataset.filename;
  const url = historyMenu.dataset.url;
  const timestamp = historyMenu.dataset.timestamp;
  closeMenus();
  if (!window.confirm(`Remove "${filename}" from download history?\n\nThis only removes the history record - it doesn't delete any file.`)) return;

  try {
    const res = await fetch("/api/history/delete", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ timestamp, filename, url }),
    });
    const data = await res.json();
    if (!data.ok) {
      flashStatus("Couldn't find that entry to delete.");
      return;
    }
    state.historyEntries = state.historyEntries.filter(
      (e) => !(e.timestamp === timestamp && e.filename === filename && e.url === url)
    );
    renderLedger();
    flashStatus("Removed from history.");
  } catch (e) {
    window.alert("Couldn't reach the server to delete that history entry.");
  }
});

function flashStatus(message) {
  const original = inputField.placeholder;
  inputField.placeholder = message;
  setTimeout(() => { inputField.placeholder = original; }, 2500);
}

let lastMenuOpenAt = 0;
const MENU_CLOSE_GRACE_MS = 400;

function positionMenu(menu, x, y) {
  menu.classList.remove("hidden");
  const rect = menu.getBoundingClientRect();
  const maxX = window.innerWidth - rect.width - 8;
  const maxY = window.innerHeight - rect.height - 8;
  menu.style.left = `${Math.min(x, Math.max(8, maxX))}px`;
  menu.style.top = `${Math.min(y, Math.max(8, maxY))}px`;
  lastMenuOpenAt = Date.now();
}

function closeMenus() {
  ledgerFilterPresetMenu.classList.add("hidden");
  ledgerFilterPresetBtn.setAttribute("aria-expanded", "false");
  jobMenu.classList.add("hidden");
  historyMenu.classList.add("hidden");
  hideAllFlyouts();
}

document.addEventListener("click", (e) => {
  // Touch-to-mouse translation layers (e.g. Moonlight/Sunshine turning an
  // iPad long-press into a simulated right-click) can fire a stray ghost
  // click right after the long-press completes. Without this grace
  // period, that ghost click hits this same listener and closes the menu
  // before it's possible to actually tap an item in it.
  if (Date.now() - lastMenuOpenAt < MENU_CLOSE_GRACE_MS) return;
  const clickedInsideAMenu =
    jobMenu.contains(e.target) ||
    historyMenu.contains(e.target) ||
    ALL_FLYOUTS.some((flyout) => flyout.contains(e.target)) ||
    openTreeFlyouts.some((flyout) => flyout.contains(e.target));
  if (!clickedInsideAMenu) closeMenus();
});

// ── Auto-download (Clipboard Monitoring) inactivity timeout ────────
// This toggle is safety-sensitive: leaving it on unattended would mean
// anything copied to the clipboard gets auto-downloaded. On top of
// always starting disabled (see refreshDownloadPrefs), it's also
// switched off automatically after 10 minutes with no user activity
// in the app, rather than staying on indefinitely for a session left
// open and unattended.
const CLIPBOARD_MONITOR_IDLE_MS = 10 * 60 * 1000; // 10 minutes

let clipboardMonitorIdleTimer = null;

function disableClipboardMonitorForInactivity() {
  if (!state.clipboardMonitor) return;
  state.clipboardMonitor = false;
  syncPrefControls();
  saveDownloadPrefs();
  flashStatus("Clipboard monitoring disabled after 10 minutes of inactivity.");
}

function resetClipboardMonitorIdleTimer() {
  if (clipboardMonitorIdleTimer) {
    clearTimeout(clipboardMonitorIdleTimer);
    clipboardMonitorIdleTimer = null;
  }
  if (!state.clipboardMonitor) return;
  clipboardMonitorIdleTimer = setTimeout(disableClipboardMonitorForInactivity, CLIPBOARD_MONITOR_IDLE_MS);
}

// Any interaction with the app counts as activity and pushes the
// timeout back out; this only actually schedules a timer while
// clipboard monitoring is on (see the early return above).
for (const evt of ["mousemove", "mousedown", "keydown", "touchstart", "wheel"]) {
  document.addEventListener(evt, resetClipboardMonitorIdleTimer, { passive: true });
}

// ── Download resolution inactivity timeout ───────────────────────
// Resolution deliberately falls back to 480p after 10 minutes without
// interaction with the app. This is a safety/convenience default rather
// than a permanent preference; boot also starts at 480p (see
// refreshDownloadPrefs above).
const DOWNLOAD_RES_IDLE_MS = 10 * 60 * 1000;
let downloadResIdleTimer = null;

function resetDownloadResolutionIdleTimer() {
  if (downloadResIdleTimer) clearTimeout(downloadResIdleTimer);
  downloadResIdleTimer = setTimeout(() => {
    if (resDropdown.value !== "480p") {
      resDropdown.value = "480p";
      syncPrefControls();
      saveDownloadPrefs();
      flashStatus("Download resolution reset to 480p after 10 minutes of inactivity.");
    }
  }, DOWNLOAD_RES_IDLE_MS);
}

for (const evt of ["mousemove", "mousedown", "keydown", "touchstart", "wheel"]) {
  document.addEventListener(evt, resetDownloadResolutionIdleTimer, { passive: true });
}
resDropdown.addEventListener("change", resetDownloadResolutionIdleTimer);
resetDownloadResolutionIdleTimer();

// ══ Settings panel ═══════════════════════════════════════════════
// One panel (gear button) for every preference. The booleans below live in
// `state` and are saved through /api/download-prefs; each one has a switch in
// the panel and, optionally, an icon-only quick toggle in the navigation tray.
// setPref() is the only writer, so the two controls can never disagree.
const PREF_CONTROLS = [
  { key: "tagDomain",          input: "set-tag-domain",           tray: "tray-tag-toggle" },
  { key: "autoConfirmTitles",  input: "set-auto-confirm",         tray: "tray-auto-confirm-toggle" },
  { key: "titlePrefixEnabled", input: "set-title-prefix-enabled", tray: "tray-title-prefix-toggle" },
  { key: "detectRenames",      input: "set-detect-renames",       tray: "tray-detect-renames-toggle" },
  { key: "m3uSniffer",         input: "set-m3u-sniffer",          tray: "ctx-m3u-toggle" },
  { key: "autoM3uRetry",       input: "set-auto-m3u-retry",       tray: "ctx-auto-m3u-retry-toolbar-toggle" },
  { key: "clipboardMonitor",   input: "set-clipboard",            tray: "ctx-clipboard-monitor-toggle" },
];

const settingsModal = el("settings-modal");
const settingsSavedEl = el("settings-saved");
let settingsSavedTimer = null;

function reportSaved(ok) {
  settingsSavedEl.textContent = ok ? "Saved" : "Couldn't save";
  settingsSavedEl.classList.toggle("error", !ok);
  if (!ok) flashStatus("Couldn't save the setting - is the server running?");
  clearTimeout(settingsSavedTimer);
  settingsSavedTimer = setTimeout(() => { settingsSavedEl.textContent = ""; }, ok ? 1500 : 4000);
}

function updateTitlePreview() {
  const prefix = el("set-title-prefix").value;
  const tag = state.tagDomain ? " [example]" : "";
  const applied = state.titlePrefixEnabled && prefix;
  let text = `Preview: ${applied ? prefix : ""}Example title${tag}`;
  if (prefix && !state.titlePrefixEnabled) text += "  (prefix is switched off)";
  el("settings-title-preview").textContent = text;
}

// Pushes `state` out to every control that shows it.
function syncPrefControls() {
  for (const c of PREF_CONTROLS) {
    el(c.input).checked = !!state[c.key];
    const btn = el(c.tray);
    btn.classList.toggle("active", !!state[c.key]);
    btn.setAttribute("aria-pressed", state[c.key] ? "true" : "false");
  }
  el("set-res").value = resDropdown.value;
  el("set-folder-pin").checked = folderControlsPinned;
  const prefixInput = el("set-title-prefix");
  if (document.activeElement !== prefixInput) prefixInput.value = state.titlePrefix;
  updateTitlePreview();
}

function setPref(key, value) {
  state[key] = !!value;
  if (key === "m3uSniffer" && state.m3uSniffer) {
    inputField.placeholder = "Paste a link, then press ENTER...";
  }
  syncPrefControls();
  saveDownloadPrefs();
  if (key === "clipboardMonitor") {
    flashStatus(state.clipboardMonitor
      ? "Clipboard monitoring enabled. Feature will turn off after 10 minutes of inactivity."
      : "Clipboard monitoring disabled.");
    resetClipboardMonitorIdleTimer();
  }
}

for (const c of PREF_CONTROLS) {
  el(c.input).addEventListener("change", () => setPref(c.key, el(c.input).checked));
  el(c.tray).addEventListener("click", () => setPref(c.key, !state[c.key]));
}

el("set-res").addEventListener("change", () => {
  resDropdown.value = el("set-res").value;
  resDropdown.dispatchEvent(new Event("change"));   // same path as the tray dropdown: saves + restarts the idle timer
});
resDropdown.addEventListener("change", () => { el("set-res").value = resDropdown.value; });

el("set-folder-pin").addEventListener("change", () => setFolderControlsPinned(el("set-folder-pin").checked));

const titlePrefixField = el("set-title-prefix");
titlePrefixField.addEventListener("input", updateTitlePreview);
// "change" (blur/Enter) rather than every keystroke, so the server is written once per edit.
titlePrefixField.addEventListener("change", () => {
  state.titlePrefix = titlePrefixField.value;
  updateTitlePreview();
  saveDownloadPrefs();
});
titlePrefixField.addEventListener("keydown", (e) => {
  e.stopPropagation();
  if (e.key === "Enter") titlePrefixField.blur();
});

// ── Tray quick-access layout ─────────────────────────────────────
// Which icons the navigation tray shows, and in what order. Kept per browser
// (localStorage) because a phone and a desktop want different tray contents.
// The settings button is not listed: it must always stay reachable.
const TRAY_ITEMS = [
  { id: "resolution",     elId: "res-tray-item",                      label: "Max resolution",                 icon: "ti-resize",      pinned: true },
  { id: "m3u_sniffer",    elId: "ctx-m3u-toggle",                     label: "M3U sniffer mode",               icon: "ti-radar",       pinned: true },
  { id: "auto_m3u_retry", elId: "ctx-auto-m3u-retry-toolbar-toggle",  label: "Auto-retry via M3U",             icon: "ti-radar",       pinned: true, badge: "AUTO" },
  { id: "clipboard",      elId: "ctx-clipboard-monitor-toggle",       label: "Clipboard monitoring",           icon: "ti-clipboard",   pinned: true },
  { id: "tag_domain",     elId: "tray-tag-toggle",                    label: "Tag file with [Domain]",         icon: "ti-tag",         pinned: false },
  { id: "auto_confirm",   elId: "tray-auto-confirm-toggle",           label: "Auto-confirm titles",            icon: "ti-checks",      pinned: false },
  { id: "title_prefix",   elId: "tray-title-prefix-toggle",           label: "Apply title prefix",             icon: "ti-text-plus",   pinned: false },
  { id: "detect_renames", elId: "tray-detect-renames-toggle",         label: "Detect renamed files",           icon: "ti-replace",     pinned: false },
  { id: "stash",          elId: "stash-status-btn",                   label: "Stash menu",                     icon: "ti-database",    pinned: true, note: "Only appears while Stash is running." },
  { id: "url_args",       elId: "url-args-btn",                       label: "Custom yt-dlp arguments",        icon: "ti-code",        pinned: true },
  { id: "folder_pin",     elId: "folder-controls-toggle-btn",         label: "Keep folder controls visible",   icon: "ti-pin",         pinned: true },
];
const TRAY_STORAGE_KEY = "stashdlp_tray_layout";

function defaultTrayLayout() {
  return { order: TRAY_ITEMS.map((t) => t.id), pinned: TRAY_ITEMS.filter((t) => t.pinned).map((t) => t.id) };
}

function loadTrayLayout() {
  const fallback = defaultTrayLayout();
  try {
    const raw = JSON.parse(localStorage.getItem(TRAY_STORAGE_KEY) || "null");
    if (!raw || !Array.isArray(raw.order) || !Array.isArray(raw.pinned)) return fallback;
    const known = new Set(TRAY_ITEMS.map((t) => t.id));
    const order = raw.order.filter((id) => known.has(id));
    for (const id of fallback.order) if (!order.includes(id)) order.push(id);   // items added in a later version
    return { order, pinned: raw.pinned.filter((id) => known.has(id)) };
  } catch (err) {
    return fallback;
  }
}

let trayLayout = loadTrayLayout();

function saveTrayLayout() {
  try { localStorage.setItem(TRAY_STORAGE_KEY, JSON.stringify(trayLayout)); } catch (err) { /* localStorage unavailable */ }
  reportSaved(true);
}

function applyTrayLayout() {
  const container = gearBtn.parentElement;
  for (const id of trayLayout.order) {
    const item = TRAY_ITEMS.find((t) => t.id === id);
    const node = el(item.elId);
    container.insertBefore(node, gearBtn);          // the gear always stays last
    node.classList.toggle("tray-unpinned", !trayLayout.pinned.includes(id));
  }
}

function renderTrayList(focus) {
  const list = el("settings-tray-list");
  list.innerHTML = "";
  // The Stash menu row is a Stash option: listed only while Stash is running (its saved pin state is kept).
  const listed = trayLayout.order.filter((id) => stashRunning || id !== "stash");
  listed.forEach((id, index) => {
    const item = TRAY_ITEMS.find((t) => t.id === id);
    const pinned = trayLayout.pinned.includes(id);

    const row = document.createElement("div");
    row.className = "settings-tray-row" + (pinned ? "" : " unpinned");
    row.dataset.trayId = id;

    const icon = document.createElement("i");
    icon.className = `ti ${item.icon} settings-tray-icon`;
    icon.setAttribute("aria-hidden", "true");
    row.appendChild(icon);

    const text = document.createElement("div");
    text.className = "settings-tray-text";
    const label = document.createElement("div");
    label.className = "settings-row-label";
    label.textContent = item.label;
    text.appendChild(label);
    if (item.note) {
      const note = document.createElement("div");
      note.className = "settings-row-desc";
      note.textContent = item.note;
      text.appendChild(note);
    }
    row.appendChild(text);

    for (const [dir, glyph, name] of [[-1, "ti-arrow-up", "up"], [1, "ti-arrow-down", "down"]]) {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = `icon-btn settings-tray-move tray-move-${name}`;
      btn.title = `Move ${name}`;
      btn.setAttribute("aria-label", `Move ${item.label} ${name}`);
      btn.disabled = (dir < 0 && index === 0) || (dir > 0 && index === listed.length - 1);
      btn.innerHTML = `<i class="ti ${glyph}" aria-hidden="true"></i>`;
      btn.addEventListener("click", () => {
        // Swap with the neighbouring *listed* row so a hidden Stash row never causes a dead click.
        const a = trayLayout.order.indexOf(id);
        const b = trayLayout.order.indexOf(listed[index + dir]);
        [trayLayout.order[a], trayLayout.order[b]] = [trayLayout.order[b], trayLayout.order[a]];
        applyTrayLayout();
        saveTrayLayout();
        renderTrayList({ id, name });
      });
      row.appendChild(btn);
    }

    const sw = document.createElement("label");
    sw.className = "switch";
    sw.title = "Show in tray";
    const input = document.createElement("input");
    input.type = "checkbox";
    input.checked = pinned;
    input.setAttribute("aria-label", `Show ${item.label} in tray`);
    input.addEventListener("change", () => {
      trayLayout.pinned = trayLayout.pinned.filter((p) => p !== id);
      if (input.checked) trayLayout.pinned.push(id);
      applyTrayLayout();
      saveTrayLayout();
      row.classList.toggle("unpinned", !input.checked);
    });
    const track = document.createElement("span");
    track.className = "switch-track";
    track.setAttribute("aria-hidden", "true");
    sw.append(input, track);
    row.appendChild(sw);

    list.appendChild(row);
  });
  if (focus) {
    const target = list.querySelector(`[data-tray-id="${focus.id}"] .tray-move-${focus.name}`)
      || list.querySelector(`[data-tray-id="${focus.id}"] .settings-tray-move:not(:disabled)`);
    if (target) target.focus();
  }
}

el("settings-tray-reset").addEventListener("click", () => {
  trayLayout = defaultTrayLayout();
  applyTrayLayout();
  saveTrayLayout();
  renderTrayList();
});

applyTrayLayout();

// ── Panel open/close and section navigation ──────────────────────
let settingsSection = "downloads";

function showSettingsSection(name, focusNav) {
  if (name === "connections" && !stashRunning) name = "downloads";
  settingsSection = name;
  for (const btn of document.querySelectorAll("#settings-nav .settings-nav-btn")) {
    const active = btn.dataset.section === name;
    btn.classList.toggle("active", active);
    btn.setAttribute("aria-selected", active ? "true" : "false");
    btn.tabIndex = active ? 0 : -1;
    if (active && focusNav) btn.focus();
  }
  for (const sec of document.querySelectorAll(".settings-content .settings-section")) {
    sec.classList.toggle("hidden", sec.dataset.section !== name);
  }
  el("settings-nav").nextElementSibling.scrollTop = 0;
}

// Shows the Stash section only while Stash is running. If the section is open
// when Stash goes away, fall back to Downloads instead of showing a blank pane.
function applySettingsStashVisibility() {
  for (const node of document.querySelectorAll("#settings-modal [data-stash-only]")) {
    node.classList.toggle("stash-hidden", !stashRunning);
  }
  if (!stashRunning && settingsSection === "connections") showSettingsSection("downloads", false);
  if (stashRunning && !settingsModal.classList.contains("hidden")) loadStashConfig();
  renderTrayList();
}

function openSettingsModal(section) {
  closeMenus();
  syncPrefControls();
  applySettingsStashVisibility();
  refreshStashStatus();                // re-check now rather than waiting for the 30 s poll
  refreshSaveDir();
  refreshTargetDir();
  refreshVersion();
  loadAppInfo();
  settingsSavedEl.textContent = "";
  showSettingsSection(section || settingsSection, false);
  settingsModal.classList.remove("hidden");
  if (stashRunning) loadStashConfig();
  const active = document.querySelector("#settings-nav .settings-nav-btn.active");
  if (active) active.focus();
}

function closeSettingsModal() {
  settingsModal.classList.add("hidden");
  gearBtn.focus();
}

gearBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  openSettingsModal();
});
el("settings-close-btn").addEventListener("click", closeSettingsModal);

let settingsPressStartedOnOverlay = false;
settingsModal.addEventListener("mousedown", (e) => { settingsPressStartedOnOverlay = e.target === settingsModal; });
settingsModal.addEventListener("click", (e) => {
  if (settingsPressStartedOnOverlay && e.target === settingsModal) closeSettingsModal();
});

const settingsNavButtons = () => Array.from(document.querySelectorAll("#settings-nav .settings-nav-btn:not(.stash-hidden)"));
for (const btn of settingsNavButtons()) {
  btn.addEventListener("click", () => showSettingsSection(btn.dataset.section, false));
}
el("settings-nav").addEventListener("keydown", (e) => {
  const keys = { ArrowDown: 1, ArrowRight: 1, ArrowUp: -1, ArrowLeft: -1 };
  if (!(e.key in keys)) return;
  e.preventDefault();
  const buttons = settingsNavButtons();
  const current = buttons.findIndex((b) => b.dataset.section === settingsSection);
  showSettingsSection(buttons[(current + keys[e.key] + buttons.length) % buttons.length].dataset.section, true);
});

// ── Tools, Connections, About ────────────────────────────────────
el("settings-ytdlp-args-btn").addEventListener("click", () => openYtdlpArgsModal());

const STASH_SOURCE_LABEL = { settings: "saved in Settings", environment: "STASH_HOST environment variable", default: "default" };
const stashHostInput = el("set-stash-host");
const stashStatusLine = el("set-stash-status");

function setStashStatus(text, kind) {
  stashStatusLine.textContent = text;
  stashStatusLine.className = "settings-status" + (kind ? ` ${kind}` : "");
}

async function loadStashConfig() {
  try {
    const res = await fetch("/api/stash/config");
    const data = await res.json();
    stashHostInput.value = data.override || "";
    stashHostInput.placeholder = data.default;
    setStashStatus(`Using ${data.host} (${STASH_SOURCE_LABEL[data.source] || data.source}).`);
  } catch (e) {
    setStashStatus("Couldn't read the Stash address from the server.", "error");
  }
}

el("set-stash-save").addEventListener("click", async () => {
  setStashStatus("Saving...");
  try {
    const res = await fetch("/api/stash/config", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ host: stashHostInput.value }),
    });
    const data = await res.json();
    if (!res.ok) {
      setStashStatus(data.error || "Couldn't save the Stash address.", "error");
      return;
    }
    stashHostInput.value = data.override || "";
    setStashStatus(`Saved. Using ${data.host} (${STASH_SOURCE_LABEL[data.source] || data.source}).`, "ok");
    reportSaved(true);
    refreshStashStatus();
  } catch (e) {
    setStashStatus("Couldn't reach the server to save the address.", "error");
  }
});

el("set-stash-test").addEventListener("click", async () => {
  setStashStatus("Testing...");
  try {
    const res = await fetch("/api/stash/test", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ host: stashHostInput.value }),
    });
    const data = await res.json();
    setStashStatus(data.ok ? `Connected to Stash at ${data.host}.` : data.error, data.ok ? "ok" : "error");
  } catch (e) {
    setStashStatus("Couldn't reach the server to run the test.", "error");
  }
});

stashHostInput.addEventListener("keydown", (e) => {
  e.stopPropagation();
  if (e.key === "Enter") el("set-stash-save").click();
});

async function loadAppInfo() {
  try {
    const res = await fetch("/api/app/info");
    const info = await res.json();
    el("about-app-version").textContent = `Version ${info.version}`;
    const reach = info.lan ? "reachable from other devices on your network" : "this computer only";
    el("settings-server-info").textContent =
      `Listening on ${info.host}:${info.port} (${reach}).` +
      (info.tray ? "\nStarted by the tray launcher." : "") +
      "\nChange with STASH_DLP_HOST and STASH_DLP_PORT; start_tray_lan.bat listens on the network.";
  } catch (e) {
    el("about-app-version").textContent = "Version unavailable";
    el("settings-server-info").textContent = "Server details unavailable.";
  }
}

el("ctx-restart-app").addEventListener("click", async () => {
  closeMenus();
  const activeDownloads = Array.from(state.jobs.values()).filter((j) => j.status === "DOWNLOADING").length;
  const warning = activeDownloads > 0
    ? `Restart the app now?\n\n${activeDownloads} download(s) in progress will be interrupted.`
    : "Restart the app now?";
  if (!window.confirm(warning)) return;

  try {
    await fetch("/api/app/restart", { method: "POST" });
  } catch (e) {
    // The connection dying right as the process exits is expected here,
    // not a real failure - the reconnect logic below handles it either way.
  }
  inputField.disabled = true;
  inputField.placeholder = "Restarting... reconnecting automatically once it's back up.";
});

el("ctx-check-ytdlp-update").addEventListener("click", async () => {
  closeMenus();
  flashStatus("Checking for yt-dlp update...");
  try {
    const res = await fetch("/api/version/check", { method: "POST" });
    const data = await res.json();
    applyVersionState(data);
    if (!data.version) {
      flashStatus("Couldn't reach yt-dlp to check for an update.");
    } else if (data.just_updated) {
      flashStatus(`yt-dlp updated to v${data.version}.`);
    } else {
      flashStatus(`yt-dlp is up to date (v${data.version}).`);
    }
  } catch (e) {
    flashStatus("Couldn't check for a yt-dlp update.");
  }
});

el("ctx-change-folder").addEventListener("click", () => {
  closeMenus();
  downloadFolderModal.open();
});

el("ctx-change-target").addEventListener("click", () => {
  closeMenus();
  targetFolderModal.open();
});

el("ctx-manage-programs").addEventListener("click", () => {
  closeMenus();
  if (!IS_LOCAL) {
    flashStatus(REMOTE_ONLY_TOOLTIP);
    return;
  }
  openExternalProgramsModal();
});

// ── External programs (Manage / Add / Edit) ────────────────────
function openExternalProgramsModal() {
  renderExternalProgramsList();
  externalProgramsModal.classList.remove("hidden");
}

function closeExternalProgramsModal() {
  externalProgramsModal.classList.add("hidden");
}

function renderExternalProgramsList() {
  externalProgramsList.innerHTML = "";
  if (state.externalPrograms.length === 0) {
    const empty = document.createElement("div");
    empty.className = "program-empty-note";
    empty.textContent = "No external programs added yet.";
    externalProgramsList.appendChild(empty);
    return;
  }
  for (const prog of state.externalPrograms) {
    const row = document.createElement("div");
    row.className = "program-row";

    const info = document.createElement("div");
    info.className = "program-row-info";
    const nameEl = document.createElement("div");
    nameEl.className = "program-row-name";
    nameEl.textContent = prog.name;
    const pathEl = document.createElement("div");
    pathEl.className = "program-row-path";
    pathEl.textContent = prog.path;
    pathEl.title = prog.path;
    info.appendChild(nameEl);
    info.appendChild(pathEl);

    const editBtn = document.createElement("button");
    editBtn.className = "program-edit-btn";
    editBtn.textContent = "Edit";
    editBtn.addEventListener("click", () => openProgramForm(prog));

    row.appendChild(info);
    row.appendChild(editBtn);
    externalProgramsList.appendChild(row);
  }
}

el("add-program-btn").addEventListener("click", () => openProgramForm(null));
el("external-programs-close-btn").addEventListener("click", closeExternalProgramsModal);
externalProgramsModal.addEventListener("click", (e) => {
  if (e.target === externalProgramsModal) closeExternalProgramsModal();
});

let editingProgramId = null;

function openProgramForm(prog) {
  editingProgramId = prog ? prog.id : null;
  programFormTitle.textContent = prog ? "Edit Program" : "Add Program";
  programNameInput.value = prog ? prog.name : "";
  programPathInput.value = prog ? prog.path : "";
  programArgsInput.value = prog ? (prog.args || "") : "";
  programFormError.classList.add("hidden");
  programDeleteBtn.classList.toggle("hidden", !prog);
  programFormModal.classList.remove("hidden");
  programNameInput.focus();
}

function closeProgramForm() {
  programFormModal.classList.add("hidden");
  editingProgramId = null;
}

function showProgramFormError(message) {
  programFormError.textContent = message;
  programFormError.classList.remove("hidden");
}

el("program-form-cancel-btn").addEventListener("click", closeProgramForm);
programFormModal.addEventListener("click", (e) => {
  if (e.target === programFormModal) closeProgramForm();
});

el("program-browse-btn").addEventListener("click", async () => {
  const btn = el("program-browse-btn");
  programFormError.classList.add("hidden");
  const original = btn.textContent;
  btn.textContent = "...";
  btn.disabled = true;
  try {
    const res = await fetch("/api/browse-program-file", { method: "POST" });
    const data = await res.json();
    if (!res.ok) {
      showProgramFormError(data.error || "Couldn't open a file browser.");
    } else if (data.path) {
      programPathInput.value = data.path;
    }
    // empty data.path just means the dialog was cancelled - do nothing
  } catch (e) {
    showProgramFormError("Couldn't reach the server.");
  } finally {
    btn.textContent = original;
    btn.disabled = false;
  }
});

async function saveProgramForm() {
  const name = programNameInput.value.trim();
  const path = programPathInput.value.trim();
  const args = programArgsInput.value;
  if (!name) { showProgramFormError("Program name can't be empty."); return; }
  if (!path) { showProgramFormError("Program path can't be empty."); return; }

  const endpoint = editingProgramId ? "/api/external-programs/update" : "/api/external-programs";
  const body = editingProgramId
    ? { id: editingProgramId, name, path, args }
    : { name, path, args };

  try {
    const res = await fetch(endpoint, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) { showProgramFormError(data.error || "Unknown error"); return; }
    state.externalPrograms = data.programs || [];
    renderExternalProgramsList();
    closeProgramForm();
  } catch (e) {
    showProgramFormError("Couldn't reach the server to save that program.");
  }
}

el("program-form-save-btn").addEventListener("click", saveProgramForm);

el("program-delete-btn").addEventListener("click", async () => {
  if (!editingProgramId) return;
  if (!window.confirm(`Remove "${programNameInput.value.trim()}" from external programs?`)) return;
  try {
    const res = await fetch("/api/external-programs/delete", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: editingProgramId }),
    });
    const data = await res.json();
    if (!res.ok) { showProgramFormError(data.error || "Unknown error"); return; }
    state.externalPrograms = data.programs || [];
    renderExternalProgramsList();
    closeProgramForm();
  } catch (e) {
    showProgramFormError("Couldn't reach the server to delete that program.");
  }
});

for (const input of [programNameInput, programPathInput, programArgsInput]) {
  input.addEventListener("keydown", (e) => {
    e.stopPropagation(); // don't trigger the global Enter/Escape pipeline handlers
    if (e.key === "Enter") saveProgramForm();
    if (e.key === "Escape") closeProgramForm();
  });
}

function createFolderModalController({
  modal, input, errorEl, recentWrap, recentList, browseBtn, cancelBtn, setBtn,
  browseEndpoint, applyEndpoint, applyBodyKey, removeEndpoint,
  getCurrentPath, getRoots, setRoots, onApplied,
}) {
  function open() {
    input.value = getCurrentPath() || "";
    errorEl.classList.add("hidden");
    renderRoots();
    modal.classList.remove("hidden");
    input.focus();
    input.select();
  }

  function close() {
    modal.classList.add("hidden");
  }

  // The modal only ever shows the flat list of saved root folders - no
  // nesting here, that's what the quick dropdown is for (see
  // openFolderQuickDropdown). This is purely "manage your roots":
  // click one to make it the active folder, or delete it.
  function renderRoots() {
    recentList.innerHTML = "";
    const current = getCurrentPath() || "";
    const entries = getRoots().filter((p) => p !== current);
    if (entries.length === 0) {
      recentWrap.classList.add("hidden");
      return;
    }
    recentWrap.classList.remove("hidden");
    for (const path of entries) {
      const row = document.createElement("div");
      row.className = "modal-recent-row";

      const item = document.createElement("div");
      item.className = "modal-recent-item";
      item.textContent = path;
      item.title = path;
      item.addEventListener("click", () => apply(path));

      const removeBtn = document.createElement("button");
      removeBtn.className = "modal-recent-remove";
      removeBtn.textContent = "✕";
      removeBtn.title = "Remove this saved folder";
      removeBtn.addEventListener("click", (e) => {
        e.stopPropagation(); // don't also trigger the row's own click-to-select
        removeRoot(path);
      });

      row.appendChild(item);
      row.appendChild(removeBtn);
      recentList.appendChild(row);
    }
  }

  async function removeRoot(path) {
    try {
      const res = await fetch(removeEndpoint, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path }),
      });
      const data = await res.json();
      if (res.ok) {
        setRoots(data.roots || []);
        renderRoots();
      }
    } catch (e) {
      // best-effort - if this fails the entry just stays in the list, no harm done
    }
  }

  async function apply(path) {
    if (!path || !path.trim()) return;
    errorEl.classList.add("hidden");
    try {
      const res = await fetch(applyEndpoint, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ [applyBodyKey]: path.trim() }),
      });
      const data = await res.json();
      if (!res.ok) {
        errorEl.textContent = data.error || "Unknown error";
        errorEl.classList.remove("hidden");
        return;
      }
      onApplied(data);
      close();
    } catch (e) {
      errorEl.textContent = "Couldn't reach the server to change the folder.";
      errorEl.classList.remove("hidden");
    }
  }

  cancelBtn.addEventListener("click", close);
  modal.addEventListener("click", (e) => {
    if (e.target === modal) close();
  });

  browseBtn.addEventListener("click", async () => {
    errorEl.classList.add("hidden");
    const originalLabel = browseBtn.textContent;
    browseBtn.textContent = "...";
    browseBtn.disabled = true;
    try {
      const res = await fetch(browseEndpoint, { method: "POST" });
      const data = await res.json();
      if (!res.ok) {
        errorEl.textContent = data.error || "Couldn't open a folder browser.";
        errorEl.classList.remove("hidden");
      } else if (data.path) {
        input.value = data.path;
      }
      // empty data.path just means the dialog was cancelled - do nothing
    } catch (e) {
      errorEl.textContent = "Couldn't reach the server.";
      errorEl.classList.remove("hidden");
    } finally {
      browseBtn.textContent = originalLabel;
      browseBtn.disabled = false;
    }
  });

  setBtn.addEventListener("click", () => apply(input.value));

  input.addEventListener("keydown", (e) => {
    e.stopPropagation(); // don't trigger the global Enter/Escape pipeline handlers
    if (e.key === "Enter") apply(input.value);
    if (e.key === "Escape") close();
  });

  return { open, close, applyPath: apply };
}

const downloadFolderModal = createFolderModalController({
  modal: folderModal, input: folderInput, errorEl: folderError,
  recentWrap: folderRecentWrap, recentList: folderRecentList,
  browseBtn: el("folder-browse-btn"), cancelBtn: el("folder-cancel-btn"), setBtn: el("folder-set-btn"),
  browseEndpoint: "/api/browse-folder", applyEndpoint: "/api/settings", applyBodyKey: "save_dir",
  removeEndpoint: "/api/settings/roots/remove",
  getCurrentPath: () => ctxSaveDir.title || "",
  getRoots: () => state.saveDirRoots,
  setRoots: (roots) => { state.saveDirRoots = roots; },
  onApplied: (data) => {
    setSaveDirDisplay(data.save_dir, data.free_space);
    state.saveDirRoots = data.roots || [];
    loadJobsIntoMap(data.jobs);
    renderLedger();
  },
});

const targetFolderModal = createFolderModalController({
  modal: targetFolderModalEl, input: el("target-folder-input"), errorEl: el("target-folder-error"),
  recentWrap: el("target-folder-recent-wrap"), recentList: el("target-folder-recent-list"),
  browseBtn: el("target-folder-browse-btn"), cancelBtn: el("target-folder-cancel-btn"), setBtn: el("target-folder-set-btn"),
  browseEndpoint: "/api/browse-target-folder", applyEndpoint: "/api/target-settings", applyBodyKey: "target_dir",
  removeEndpoint: "/api/target-settings/roots/remove",
  getCurrentPath: () => ctxTargetDir.title || "",
  getRoots: () => state.targetDirRoots,
  setRoots: (roots) => { state.targetDirRoots = roots; },
  onApplied: (data) => {
    setTargetDirDisplay(data.target_dir, data.free_space);
    state.targetDirRoots = data.roots || [];
  },
});

resDropdown.addEventListener("click", (e) => e.stopPropagation());
resDropdown.addEventListener("change", saveDownloadPrefs);

// ── Mode buttons (Download / Search History) ───────────
function setAppModeDownload() {
  inputField.disabled = false;
  resetToReady();
  updateModeButtons();
  inputField.focus();
}

function setAppModeSearchHistory() {
  exitSelectionMode();
  state.appMode = "SEARCH_HISTORY";
  inputField.disabled = false;
  inputField.value = "";
  inputField.placeholder = "Paste target file name to find link...";
  inputField.focus();
  updateModeButtons();
  enterHistoryModeUI();
  refreshSearchHistory();
}

function updateModeButtons() {
  const isDl = state.appMode === "DOWNLOAD";
  const isHistory = state.appMode === "SEARCH_HISTORY";
  dlModeBtn.classList.toggle("active", isDl);
  historyModeBtn.classList.toggle("active", isHistory);
  dlModeBtn.title = isDl ? "Download Mode Active" : "Switch to Download Mode (Ctrl+D)";
  historyModeBtn.title = isHistory ? "Search History Mode Active" : "Switch to Search History Mode (Ctrl+F)";
}

// Search History Mode reuses the same ledger toolbar (filter + sort),
// but "Move All"/"Refresh", the audio-only filter, and the status
// filter chips don't apply to history records, and there's no file
// size to sort by.
function enterHistoryModeUI() {
  
  ledgerMoreBtn.classList.add("hidden");
  selectModeBtn.classList.add("hidden");
  // Disable the two size_* sort options - not meaningful for history
  // entries (no file-size info is logged there).
  for (const value of ["size_desc", "size_asc"]) {
    const opt = ledgerSortSelect.querySelector(`option[value="${value}"]`);
    if (opt) opt.disabled = true;
  }
  if (state.sortField === "size") {
    state.sortField = "added";
    state.sortDir = "desc";
    ledgerSortSelect.value = "added";
  }
}

function exitHistoryModeUI() {
  ledgerFilterPresetWrap.classList.remove("hidden");
  ledgerMoreBtn.classList.remove("hidden");
  selectModeBtn.classList.remove("hidden");
  for (const value of ["size_desc", "size_asc"]) {
    const opt = ledgerSortSelect.querySelector(`option[value="${value}"]`);
    if (opt) opt.disabled = false;
  }
}

downloadSubmitBtn.addEventListener("click", () => {
  const currentValue = inputField.value.trim();
  if (state.appMode === "SEARCH_HISTORY") {
    state.appMode = "DOWNLOAD";
    exitHistoryModeUI();
    updateModeButtons();
    renderLedger();
  }
  handleEnterPipeline();
});

dlModeBtn.addEventListener("click", () => {
  if (state.current === "EDITING") {
    handleEnterPipeline(); // proceed with the download using the current input as the title
    return;
  }
  const currentValue = inputField.value.trim();
  const isValidUrl = /^https?:\/\//i.test(currentValue);
  if (isValidUrl && state.current === "READY") {
    const wasHistoryMode = state.appMode === "SEARCH_HISTORY";
    state.appMode = "DOWNLOAD";
    if (wasHistoryMode) {
      exitHistoryModeUI();
      renderLedger();
    }
    updateModeButtons();
    beginDownloadPipeline(currentValue);
  } else {
    setAppModeDownload();
  }
});
historyModeBtn.addEventListener("click", setAppModeSearchHistory);

// ── Folder quick-select dropdowns (click the DL:/Target: line) ──
// Lists saved root folders for one-tap switching, nested with their
// actual on-disk subfolders (unlimited depth, live-scanned server
// side - see /api/settings/roots/tree). The whole tree for every root
// is fetched once per open, so expanding a nested chevron afterward is
// pure DOM work - no extra requests. Falls through to the full modal
// (Browse.../type a path) via the last entry, same as before.
//
// Nested levels beyond the root list can't be the dropdown's own fixed
// listEl (depth is unbounded), so each one is a freshly created flyout
// appended to <body> and tracked in openTreeFlyouts, positioned beside
// whichever row's chevron opened it via positionFlyoutNextTo - same
// mechanism the Copy/File submenus already use.
let openTreeFlyouts = [];

// Sort mode for the folder tree - "recent" mirrors the backend's
// default (most-recently-used first, from dir_last_used), "alpha" is
// a plain client-side re-sort by name. Persisted so a preference
// sticks across page reloads. Applied recursively so nested levels
// (expanded later, on demand) come pre-sorted the same way.
let folderSortMode = "recent";
try {
  folderSortMode = localStorage.getItem("stashdlp_folder_sort") || "recent";
} catch (e) {
  // localStorage unavailable (e.g. privacy mode) - fall back to default
}

function sortTreeNodes(nodes) {
  const sorted = nodes.slice();
  if (folderSortMode === "alpha") {
    sorted.sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: "base" }));
  } else {
    sorted.sort((a, b) => {
      const at = a.last_used || 0;
      const bt = b.last_used || 0;
      if (at !== bt) return bt - at; // most-recent first
      return a.name.localeCompare(b.name, undefined, { sensitivity: "base" });
    });
  }
  for (const node of sorted) {
    if (node.children && node.children.length > 1) {
      node.children = sortTreeNodes(node.children);
    }
  }
  return sorted;
}

function closeTreeFlyoutsFrom(depth) {
  for (let i = depth; i < openTreeFlyouts.length; i++) {
    openTreeFlyouts[i].remove();
  }
  openTreeFlyouts.length = depth;
}

function closeAllTreeFlyouts() {
  closeTreeFlyoutsFrom(0);
}

// Renders one level of the tree (the root list, or one root/folder's
// children) into `container`. `depth` identifies this level's slot in
// openTreeFlyouts - a chevron click at this depth replaces whatever
// was already open at that depth (a sibling's previously expanded
// flyout) and drops anything deeper than it.
function renderTreeLevel(nodes, container, { depth, current, applyPath, closeDropdown, onRemoveRoot }) {
  container.innerHTML = "";

  // Depth 0 is the dropdown's own root list - closing it just closes
  // the whole dropdown, no "back" needed. Anything deeper is one of
  // the dynamically-created flyouts, so give it a way back up besides
  // re-clicking the chevron that opened it or clicking away entirely.
  //
  // A flyout opened from a row at this level (see toggleChildren below)
  // is stored at openTreeFlyouts[depth] and rendered with depth + 1, so
  // *this* container - if depth > 0 - lives at openTreeFlyouts[depth - 1].
  // Back needs to drop from there (inclusive) to close itself and
  // anything opened deeper than it, not from `depth` itself.
  if (depth > 0) {
    const back = document.createElement("div");
    back.className = "ctx-item";
    back.innerHTML = '<i class="ti ti-arrow-left" aria-hidden="true"></i> Back';
    back.addEventListener("click", (e) => {
      e.stopPropagation();
      closeTreeFlyoutsFrom(depth - 1);
    });
    container.appendChild(back);
    const sep = document.createElement("div");
    sep.className = "ctx-separator";
    container.appendChild(sep);
  }

  for (const node of nodes) {
    const row = document.createElement("div");
    row.className = "ctx-item ctx-item-tree";
    if (node.path === current) row.classList.add("ctx-disabled");

    const label = document.createElement("span");
    label.className = "ctx-tree-label";
    label.textContent = node.name;
    label.title = node.path;
    row.appendChild(label);

    if (node.path !== current) {
      label.addEventListener("click", () => {
        closeDropdown();
        applyPath(node.path);
      });
    }

    if (node.children && node.children.length > 0) {
      const chevron = document.createElement("span");
      chevron.className = "ctx-chevron";
      chevron.textContent = "▸";
      row.appendChild(chevron);

      const toggleChildren = (e) => {
        e.stopPropagation();
        const alreadyOpenForThisRow =
          openTreeFlyouts[depth] && openTreeFlyouts[depth].dataset.forPath === node.path;
        closeTreeFlyoutsFrom(depth);
        if (alreadyOpenForThisRow) return;

        const flyout = document.createElement("div");
        flyout.className = "ctx-menu folder-quickmenu tree-flyout hidden";
        flyout.dataset.forPath = node.path;
        document.body.appendChild(flyout);
        openTreeFlyouts[depth] = flyout;
        renderTreeLevel(node.children, flyout, { depth: depth + 1, current, applyPath, closeDropdown, onRemoveRoot });
        positionFlyoutNextTo(flyout, row);
      };
      chevron.addEventListener("click", toggleChildren);
    }

    // Only root-level entries (depth 0) are "saved" folders that can be
    // unlisted - everything below that is just a live subfolder found
    // on disk, with nothing persisted to remove. Skip for the
    // already-active folder too; removing your current folder out from
    // under yourself is more confusing than useful here.
    if (depth === 0 && onRemoveRoot && node.path !== current) {
      const removeBtn = document.createElement("button");
      removeBtn.className = "ctx-tree-remove";
      removeBtn.textContent = "\u2212"; // minus sign, framed by the button's own border
      removeBtn.title = "Remove this saved folder";
      removeBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        // Swap the row's contents for an inline confirm instead of a
        // separate popup, so it's obvious exactly which folder is
        // about to be removed.
        row.innerHTML = "";
        row.classList.add("ctx-tree-confirm");

        const msg = document.createElement("span");
        msg.className = "ctx-tree-confirm-msg";
        msg.textContent = `Remove "${node.name}"?`;

        const yesBtn = document.createElement("button");
        yesBtn.className = "ctx-tree-confirm-btn ctx-tree-confirm-yes";
        yesBtn.textContent = "Remove";
        yesBtn.addEventListener("click", (ev) => {
          ev.stopPropagation();
          onRemoveRoot(node.path);
        });

        const noBtn = document.createElement("button");
        noBtn.className = "ctx-tree-confirm-btn ctx-tree-confirm-no";
        noBtn.textContent = "Cancel";
        noBtn.addEventListener("click", (ev) => {
          ev.stopPropagation();
          renderTreeLevel(nodes, container, { depth, current, applyPath, closeDropdown, onRemoveRoot });
        });

        row.append(msg, yesBtn, noBtn);
      });
      row.appendChild(removeBtn);
    }

    container.appendChild(row);
  }
}

async function openFolderQuickDropdown({ dropdownEl, listEl, anchorEl, treeEndpoint, removeEndpoint, getCurrentPath, applyPath, openAdvanced, noneLabel }) {
  closeOtherFlyouts(dropdownEl); // also tears down any tree flyouts from a previous open
  listEl.innerHTML = "";
  const loading = document.createElement("div");
  loading.className = "ctx-item ctx-disabled";
  loading.textContent = "Loading...";
  listEl.appendChild(loading);
  positionDropdownBelow(dropdownEl, anchorEl);

  const current = getCurrentPath() || "";
  const closeDropdown = () => {
    dropdownEl.classList.add("hidden");
    closeAllTreeFlyouts();
  };

  let roots = [];
  try {
    const res = await fetch(treeEndpoint);
    const data = await res.json();
    roots = data.roots || [];
  } catch (e) {
    // best-effort - falls through to the empty-state below
  }

  // The dropdown may have been closed (or reopened elsewhere) while
  // the fetch was in flight - don't resurrect it out from under the
  // user with stale content.
  if (dropdownEl.classList.contains("hidden")) return;

  roots = sortTreeNodes(roots);

  listEl.innerHTML = "";

  // Sort toggle, pinned above the scrollable tree area below.
  const sortBar = document.createElement("div");
  sortBar.className = "folder-sort-bar";
  const sortLabel = document.createElement("span");
  sortLabel.className = "folder-sort-label";
  sortLabel.textContent = "Sort";
  sortBar.appendChild(sortLabel);

  const treeScroll = document.createElement("div");
  treeScroll.className = "folder-tree-scroll";

  const renderRootLevel = () => {
    if (roots.length === 0) {
      treeScroll.innerHTML = "";
      const empty = document.createElement("div");
      empty.className = "ctx-item ctx-disabled";
      empty.textContent = noneLabel;
      treeScroll.appendChild(empty);
      return;
    }
    renderTreeLevel(roots, treeScroll, { depth: 0, current, applyPath, closeDropdown, onRemoveRoot });
  };

  async function onRemoveRoot(path) {
    try {
      const res = await fetch(removeEndpoint, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path }),
      });
      if (res.ok) {
        roots = roots.filter((n) => n.path !== path);
        renderRootLevel();
      }
    } catch (e) {
      // best-effort - if this fails the entry just stays in the list, no harm done
    }
    positionDropdownBelow(dropdownEl, anchorEl);
  }

  const modeButtons = [
    { mode: "recent", label: "Recent" },
    { mode: "alpha", label: "A\u2013Z" },
  ];
  for (const { mode, label } of modeButtons) {
    const btn = document.createElement("button");
    btn.className = "folder-sort-btn";
    btn.textContent = label;
    btn.classList.toggle("active", folderSortMode === mode);
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      if (folderSortMode === mode) return;
      folderSortMode = mode;
      try { localStorage.setItem("stashdlp_folder_sort", mode); } catch (err) { /* ignore */ }
      for (const b of sortBar.querySelectorAll(".folder-sort-btn")) b.classList.remove("active");
      btn.classList.add("active");
      roots = sortTreeNodes(roots);
      closeAllTreeFlyouts(); // nested flyouts held stale-ordered node refs
      renderRootLevel();
      positionDropdownBelow(dropdownEl, anchorEl);
    });
    sortBar.appendChild(btn);
  }
  listEl.appendChild(sortBar);

  renderRootLevel();
  listEl.appendChild(treeScroll);

  const sep = document.createElement("div");
  sep.className = "ctx-separator";
  listEl.appendChild(sep);

  const advanced = document.createElement("div");
  advanced.className = "ctx-item";
  advanced.textContent = "Browse / set custom folder...";
  advanced.addEventListener("click", () => {
    closeDropdown();
    openAdvanced();
  });
  listEl.appendChild(advanced);

  positionDropdownBelow(dropdownEl, anchorEl);
}

folderStatusSave.addEventListener("click", (e) => {
  e.stopPropagation();
  jobMenu.classList.add("hidden");
  historyMenu.classList.add("hidden");
  openFolderQuickDropdown({
    dropdownEl: dlFolderQuickMenu, listEl: dlFolderQuickList, anchorEl: folderStatusSave,
    treeEndpoint: "/api/settings/roots/tree",
    removeEndpoint: "/api/settings/roots/remove",
    getCurrentPath: () => ctxSaveDir.title || "",
    applyPath: downloadFolderModal.applyPath,
    openAdvanced: () => downloadFolderModal.open(),
    noneLabel: "No saved download folders yet",
  });
});

folderStatusTarget.addEventListener("click", (e) => {
  e.stopPropagation();
  jobMenu.classList.add("hidden");
  historyMenu.classList.add("hidden");
  openFolderQuickDropdown({
    dropdownEl: targetFolderQuickMenu, listEl: targetFolderQuickList, anchorEl: folderStatusTarget,
    treeEndpoint: "/api/target-settings/roots/tree",
    removeEndpoint: "/api/target-settings/roots/remove",
    getCurrentPath: () => ctxTargetDir.title || "",
    applyPath: targetFolderModal.applyPath,
    openAdvanced: () => targetFolderModal.open(),
    noneLabel: "No saved target folders yet",
  });
});

// ── Control bar ────────────────────────────────────────────────
let _refreshInFlight = false;
async function refreshDownloadLedger() {
  // Guards against overlapping calls piling up if a previous refresh
  // (manual click or the auto-refresh poll below) is still in flight -
  // e.g. on a slow network the poll interval could otherwise fire again
  // before the first request even returns.
  if (_refreshInFlight) return;
  _refreshInFlight = true;
  try {
    const res = await fetch("/api/refresh", { method: "POST" });
    const data = await res.json();
    loadJobsIntoMap(data.jobs);
    renderLedger();
  } finally {
    _refreshInFlight = false;
  }
}

el("refresh-btn").addEventListener("click", () => {
  ledgerMoreMenu.classList.add("hidden");
  refreshDownloadLedger();
});

// Keeps the queue (and in particular the has_twin/HAS TWIN pill, which
// only gets recomputed server-side on a scan) current without the user
// needing to press Refresh themselves - e.g. a twin dropped into
// Converted/ by hand, or Encode Manager history lost across a server
// restart, would otherwise only surface on the next manual Refresh.
// 30s (matching the Stash-status poll) rather than something tighter -
// everything the app does to its own jobs already arrives instantly
// over the websocket, so this poll's only real job is catching
// external changes (a file dropped in by hand), which was never on a
// tight SLA to begin with; a longer interval also matters more now
// that this does a full os.listdir() + Converted/ listing + potential
// ffprobe calls each tick, which isn't free on a networked path.
// Silently swallow failures (e.g. a momentary network blip on
// Tailscale) rather than spamming flashStatus every few seconds.
setInterval(() => {
  refreshDownloadLedger().catch(() => {});
}, 30000);


el("move-all-btn").addEventListener("click", async () => {
  ledgerMoreMenu.classList.add("hidden");
  const targetPath = ctxTargetDir.title || "";
  if (!targetPath) {
    window.alert("Set a target folder first (right-click the logo \u2192 Change Target Folder...).");
    return;
  }
  const completedCount = Array.from(state.jobs.values()).filter((j) => j.status === "DONE").length;
  if (completedCount === 0) {
    window.alert("Nothing completed to move.");
    return;
  }
  if (!window.confirm(`Move all ${completedCount} completed item(s) to:\n${targetPath}\n\nThis can't be undone.`)) {
    return;
  }

  try {
    const res = await fetch("/api/jobs/move-all-to-target", { method: "POST" });
    const data = await res.json();
    if (!res.ok) {
      window.alert(`Couldn't move files:\n${data.error || "Unknown error"}`);
      return;
    }
    loadJobsIntoMap(data.jobs);
    renderLedger();

    const movedNames = [...data.moved];
    const failed = [...data.failed];

    // Files with a re-encoded twin weren't touched yet - walk them one
    // at a time so each gets its own Original/Re-encoded/Cancel prompt.
    for (const info of data.pending_decisions || []) {
      const choice = await promptReencodeChoice(info);
      if (!choice) continue; // cancelled - leave it in the ledger
      const result = await requestMoveToTarget(info.filename, choice);
      if (result === "moved") {
        state.jobs.delete(info.filename);
        movedNames.push(info.filename);
      } else if (result === "error") {
        failed.push({ filename: info.filename, error: "Move failed - see alert." });
      }
    }
    renderLedger();

    let message = `Moved ${movedNames.length} item(s) to target.`;
    if (failed.length > 0) {
      message += `\n\n${failed.length} failed:\n` +
        failed.map((f) => `- ${f.filename}: ${f.error}`).join("\n");
    }
    window.alert(message);
  } catch (e) {
    window.alert("Couldn't reach the server to move files.");
  }
});

// ── Core pipeline: READY -> (fetch title | sniff m3u8) -> EDITING -> submit ──
function resetToReady() {
  const wasHistoryMode = state.appMode === "SEARCH_HISTORY";
  state.appMode = "DOWNLOAD";
  state.current = "READY";
  state.stagedUrl = "";
  state.targetUrl = "";
  inputField.disabled = false;
  modeContainer.style.pointerEvents = "";
  inputField.value = "";
  inputField.placeholder = "Paste a link, then press ENTER...";
  updateUrlArgsChip();
  updateModeButtons();
  if (wasHistoryMode) {
    exitHistoryModeUI();
    renderLedger();
  }
}

async function submitDownloadJob(url, filename, resCap, originalPastedUrl) {
  try {
    await fetch("/api/jobs", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url, filename, res_cap: resCap, original_pasted_url: originalPastedUrl,
      }),
    });
  } catch (e) { /* job_added will simply never arrive */ }
  resetToReady();
}

function updatePlaylistCancelButton() {
  const active = [...state.playlistBatchFiles].some((filename) => {
    const job = state.jobs.get(filename);
    return job && (job.status === "QUEUED" || job.status === "DOWNLOADING");
  });
  cancelPlaylistBtn.classList.toggle("hidden", !active);
}

async function cancelPlaylistBatch() {
  const filenames = [...state.playlistBatchFiles].filter((filename) => {
    const job = state.jobs.get(filename);
    return job && (job.status === "QUEUED" || job.status === "DOWNLOADING");
  });
  if (!filenames.length) {
    updatePlaylistCancelButton();
    return;
  }
  cancelPlaylistBtn.disabled = true;
  try {
    await fetch("/api/playlist/cancel", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filenames }),
    });
  } catch (e) {
    window.alert("Couldn't cancel the playlist downloads.");
  } finally {
    cancelPlaylistBtn.disabled = false;
    updatePlaylistCancelButton();
  }
}

cancelPlaylistBtn.addEventListener("click", cancelPlaylistBatch);

async function submitPlaylistBatch(entries, resCap, playlistTitle, autoStart = false) {
  const label = playlistTitle ? `"${playlistTitle}"` : "This playlist";
  const proceed = window.confirm(
    `${label} has ${entries.length} videos.\n\nQueue all ${entries.length} for download?`
  );
  if (!proceed) {
    resetToReady();
    return;
  }

  // Ask separately so the choice is explicit and applies to this playlist only.
  const numberTitles = window.confirm(
    `Add numbering to the ${entries.length} playlist titles?\n\n` +
    `If enabled, files will be named like:\n01-My Video\n02-Another Video\n03-Another One`
  );

  try {
    const response = await fetch("/api/playlist/queue", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ entries, res_cap: resCap, number_titles: numberTitles }),
    });
    if (!response.ok) throw new Error("playlist queue failed");
    const queuedData = await response.json();
    state.playlistBatchFiles = new Set(queuedData.queued || []);
    updatePlaylistCancelButton();
  } catch (e) {
    window.alert("Couldn't reach the server to queue the playlist.");
  }
  resetToReady();
}

async function handleEnterPipeline() {
  const typedValue = inputField.value.trim();

  if (state.current === "READY") {
    // A Stash scene URL in the main address bar uses the same import path
    // as the explicit Import from Stash action.
    if (/^https?:\/\/[^\s/]+(?:[:\/][^\s/]*)?\/scenes\/\d+\/?(?:[?#].*)?$/i.test(typedValue)) {
      await importStashSceneFromAddressBar(typedValue);
    } else if (/^https?:\/\//i.test(typedValue)) {
      await beginDownloadPipeline(typedValue);
    } else {
      inputField.value = "";
      inputField.placeholder = "No valid URL - paste a link and press ENTER.";
      setTimeout(() => { inputField.placeholder = "Paste a link, then press ENTER..."; }, 2500);
    }
  } else if (state.current === "EDITING") {
    const finalTitle = typedValue;
    if (finalTitle) {
      await submitDownloadJob(state.stagedUrl, finalTitle, resDropdown.value, state.targetUrl);
    }
  } else if (state.current === "FETCHING" || state.current === "INTERCEPTING") {
    // If we're in the middle of fetching, don't do anything — the pipeline is already running
    return;
  }
}

// Triggered when a normal download fails server-side: the failed job is
// pulled from the ledger before the user ever sees an ERROR card, and
// the input box is hijacked to run the same M3U sniffing flow a manual
// "Find Link Mode" submission would - message, sniff, then the fetched
// stream's suggested name is staged in the input box for the user to
// review/edit before pressing Enter to start the download (or submitted
// immediately if Auto-Confirm Titles is on).
async function beginM3uRetryPipeline(url, resCap, originalPastedUrl) {
  state.targetUrl = originalPastedUrl || url;
  state.current = "INTERCEPTING";
  inputField.disabled = true;
  modeContainer.style.pointerEvents = "none";
  inputField.value = "yt-dlp failed to download, trying M3U sniffing method...";
  try {
    const res = await fetch("/api/find-link", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url, tag_domain: state.tagDomain }),
    });
    if (!res.ok) {
      const err = await res.json();
      handleInterceptionFailure(err.error || "Unknown error");
      return;
    }
    const data = await res.json();
    if (resCap) resDropdown.value = resCap;
    if (state.autoConfirmTitles) {
      await submitDownloadJob(data.stream_url, data.suggested_title, resDropdown.value, state.targetUrl);
    } else {
      handleIntercepted(data.stream_url, data.suggested_title);
    }
  } catch (e) {
    handleInterceptionFailure(String(e));
  }
}

// Playlist/channel detection runs on every pasted URL, in parallel with
// whatever the normal single-item path (M3U sniff or fetch-title) is
// already doing - so the common single-video case pays no extra
// latency waiting on the playlist probe before it can proceed. If the
// probe comes back positive, the single-item result is discarded and
// every entry is queued as its own ledger item instead (see
// job_manager.start_playlist_batch - each playlist gets its own
// 3-concurrent-download cap, independent of any other playlist queued
// separately).
async function beginDownloadPipeline(url, forceAutoStart = false) {
  state.targetUrl = url;
  inputField.disabled = true;
  modeContainer.style.pointerEvents = "none";

  const probePromise = fetch("/api/playlist/probe", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url, tag_domain: state.tagDomain }),
  }).then((r) => r.json()).catch(() => ({ is_playlist: false }));

  if (state.m3uSniffer) {
    state.current = "INTERCEPTING";
    inputField.value = "Sniffing m3u...";
    try {
      const res = await fetch("/api/find-link", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url, tag_domain: state.tagDomain }),
      });
      const probeData = await probePromise;
      if (probeData.is_playlist) {
        await submitPlaylistBatch(probeData.entries, resDropdown.value, probeData.playlist_title, forceAutoStart);
        return;
      }
      if (!res.ok) {
        const err = await res.json();
        handleInterceptionFailure(err.error || "Unknown error");
        return;
      }
      const data = await res.json();
      if (forceAutoStart || state.autoConfirmTitles) {
        await submitDownloadJob(data.stream_url, data.suggested_title, resDropdown.value, state.targetUrl);
      } else {
        handleIntercepted(data.stream_url, data.suggested_title);
      }
    } catch (e) {
      const probeData = await probePromise;
      if (probeData.is_playlist) {
        await submitPlaylistBatch(probeData.entries, resDropdown.value, probeData.playlist_title, forceAutoStart);
        return;
      }
      handleInterceptionFailure(String(e));
    }
  } else {
    state.current = "FETCHING";
    state.stagedUrl = url;
    inputField.value = "Fetching Title metadata...";
    try {
      const res = await fetch("/api/fetch-title", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url, tag_domain: state.tagDomain }),
      });
      const data = await res.json();
      const probeData = await probePromise;
      if (probeData.is_playlist) {
        await submitPlaylistBatch(probeData.entries, resDropdown.value, probeData.playlist_title, forceAutoStart);
        return;
      }
      if (forceAutoStart || state.autoConfirmTitles) {
        await submitDownloadJob(url, data.title, resDropdown.value, state.targetUrl);
      } else {
        promptTitleEdit(data.title);
      }
    } catch (e) {
      const probeData = await probePromise;
      if (probeData.is_playlist) {
        await submitPlaylistBatch(probeData.entries, resDropdown.value, probeData.playlist_title, forceAutoStart);
        return;
      }
      if (forceAutoStart || state.autoConfirmTitles) {
        await submitDownloadJob(url, "Unknown Title", resDropdown.value, state.targetUrl);
      } else {
        promptTitleEdit("Unknown Title");
      }
    }
  }
}

function promptTitleEdit(title) {
  state.current = "EDITING";
  inputField.disabled = false;
  modeContainer.style.pointerEvents = "";
  inputField.value = title;
  inputField.focus();
  inputField.setSelectionRange(0, 0);
}

function handleIntercepted(streamUrl, suggestedTitle) {
  state.stagedUrl = streamUrl;
  state.current = "EDITING";
  inputField.disabled = false;
  modeContainer.style.pointerEvents = "";
  inputField.value = suggestedTitle;
  inputField.focus();
  inputField.setSelectionRange(0, 0);
}

function handleInterceptionFailure(message) {
  resetToReady();
  inputField.placeholder = `Failed: ${message}`;
}

async function executeHistorySearch() {
  const query = inputField.value.trim();
  if (!query) return "";
  try {
    const res = await fetch("/api/history-search", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query }),
    });
    const data = await res.json();
    return data.url || "";
  } catch (e) {
    return "";
  }
}

// ── Keyboard handling (mirrors keyPressEvent) ─────────────────
let baseFontSize = 12;

document.addEventListener("keydown", async (e) => {
  // ── Modals that should trap Esc ──────────────────────────────
  if (!stashImportModal.classList.contains("hidden")) return;
  if (!stashTagModal.classList.contains("hidden")) return;
  if (!stashTagResultsModal.classList.contains("hidden")) {
    if (e.key === "Escape") closeStashTagResultsModal();
    return;
  }
  if (!folderModal.classList.contains("hidden")) return;
  if (!targetFolderModalEl.classList.contains("hidden")) return;
  if (!externalProgramsModal.classList.contains("hidden")) {
    if (e.key === "Escape") closeExternalProgramsModal();
    return;
  }
  if (!programFormModal.classList.contains("hidden")) return;
  if (!videoModal.classList.contains("hidden")) {
    if (e.key === "Escape") closeMediaModal();
    return;
  }
  if (!syncAudioModal.classList.contains("hidden")) {
    if (e.key === "Escape") closeSyncAudioModal(true);
    return;
  }
  if (!newEncodeJobModal.classList.contains("hidden")) {
    if (e.key === "Escape") closeNewEncodeJobModal();
    return;
  }
  if (!settingsModal.classList.contains("hidden")) {
    const dialogOnTop = Array.from(document.querySelectorAll(".modal-overlay:not(.hidden)")).some((m) => m !== settingsModal);
    if (!dialogOnTop) {
      if (e.key === "Escape") closeSettingsModal();
      return;
    }
  }

  // ── Ctrl+ shortcuts ──────────────────────────────────────────
  if (e.ctrlKey || e.metaKey) {
    if (e.key === "=" || e.key === "+") {
      baseFontSize = Math.min(24, baseFontSize + 1);
      document.documentElement.style.setProperty("--base-font", `${baseFontSize}px`);
      e.preventDefault();
      return;
    }
    if (e.key === "-") {
      baseFontSize = Math.max(8, baseFontSize - 1);
      document.documentElement.style.setProperty("--base-font", `${baseFontSize}px`);
      e.preventDefault();
      return;
    }
    if (e.key.toLowerCase() === "f") { setAppModeSearchHistory(); e.preventDefault(); return; }
    if (e.key.toLowerCase() === "d") { setAppModeDownload(); e.preventDefault(); return; }
    if (e.key.toLowerCase() === "s" && state.appMode === "DOWNLOAD") {
      e.preventDefault();
      openStashMenuFlyout();
      return;
    }
  }

  // ── Escape: cancel editing or close ─────────────────────────
  if (e.key === "Escape") {
    if (["EDITING", "FETCHING", "INTERCEPTING"].includes(state.current)) {
      resetToReady();
      inputField.placeholder = "Cancelled. Paste a link and press ENTER.";
      setTimeout(() => { inputField.placeholder = "Paste a link, then press ENTER..."; }, 2500);
    } else {
      resetToReady();
    }
    return;
  }

  // ── Enter: only if the input field is focused ──────────────
  if (e.key === "Enter" && document.activeElement === inputField) {
    e.preventDefault();
    if (state.appMode === "SEARCH_HISTORY") {
      const found = await executeHistorySearch();
      if (found) {
        inputField.value = found;
        inputField.focus();
        inputField.select();
      } else {
        inputField.value = "";
        inputField.placeholder = "No matches found in history.";
      }
    } else {
      handleEnterPipeline();
    }
  }
});

// ── Encode Manager (settings modal only - no dedicated queue view;
// encode progress/status now shows inline on the source download's
// ledger card, see buildJobCard/findEncodeJobFor) ────────────────
const openConvertedBtn = el("open-converted-btn");
const newEncodeJobModal = el("new-encode-job-modal");
const closeEncodeJobModalBtn = el("close-encode-job-modal");
const cancelEncodeJobModalBtn = el("cancel-encode-job-modal");
const addEncodeJobBtn = el("add-encode-job-btn");
const encodeSourceDisplay = el("encode-source-display");
const encodeSourceInfo = el("encode-source-info");
const encodeModeCrfBtn = el("encode-mode-crf-btn");
const encodeModeSizeBtn = el("encode-mode-size-btn");
const encodeCrfFields = el("encode-crf-fields");
const encodeSizeFields = el("encode-size-fields");
const encodeCodecSelect = el("encode-codec-select");
const encodeBackendSelect = el("encode-backend-select");
const encodeCrfSlider = el("encode-crf-slider");
const encodeCrfValue = el("encode-crf-value");
const encodeCrfHint = el("encode-crf-hint");
const encodePresetSelect = el("encode-preset-select");
const encodeTargetSizeInput = el("encode-target-size-input");
const encodeResolutionSelect = el("encode-resolution-select");
const encodeResolutionLabel = el("encode-resolution-label");
const encodeForceArCheck = el("encode-force-ar-check");
const encodeAspectQuickRow = el("encode-aspect-quick-row");
const encodeArWidthInput = el("encode-ar-width-input");
const encodeArHeightInput = el("encode-ar-height-input");
const encodeDeinterlaceCheck = el("encode-deinterlace-check");
const encodeAutocropCheck = el("encode-autocrop-check");
const encodeAudioSelect = el("encode-audio-select");
const encodeContainerSelect = el("encode-container-select");
const encodeDenoiseCheck = el("encode-denoise-check");
const encodeSubtitlesSelect = el("encode-subtitles-select");
const encodeOversizedSelect = el("encode-oversized-select");
const encodeEstimateOriginal = el("encode-estimate-original");
const encodeEstimateLabel = el("encode-estimate-label");
const encodeEstimateValue = el("encode-estimate-value");
const encodeEstimateSavings = el("encode-estimate-savings");
const encodeEstimateRefreshBtn = el("encode-estimate-refresh-btn");
const encodeJobError = el("encode-job-error");
const encodeSavedPresetSelect = el("encode-saved-preset-select");
const encodePresetAddBtn = el("encode-preset-add-btn");
const encodePresetEditBtn = el("encode-preset-edit-btn");
const encodePresetDeleteBtn = el("encode-preset-delete-btn");
let encodeSavedPresets = [];

async function loadEncodeCapabilities() {
  try {
    const res = await fetch("/api/encode/capabilities");
    state.encodeCapabilities = await res.json();
  } catch (e) {
    state.encodeCapabilities = null;
  }
}

async function loadEncodeJobsSnapshot() {
  try {
    const res = await fetch("/api/encode/jobs");
    const jobs = await res.json();
    state.encodeJobs.clear();
    for (const job of jobs) state.encodeJobs.set(job.id, job);
    renderLedger();
  } catch (e) {
    // backend not reachable yet; ignore
  }
}

function formatDuration(seconds) {
  if (!seconds) return "";
  const s = Math.round(seconds);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const rem = s % 60;
  return h > 0
    ? `${h}:${String(m).padStart(2, "0")}:${String(rem).padStart(2, "0")}`
    : `${m}:${String(rem).padStart(2, "0")}`;
}


// Reused by the inline cancel button on a card's live encode-progress
// row (see buildJobCard) - the actual UI removal/rebuild happens when
// the resulting "encode_job_updated" (status -> CANCELLED) broadcasts
// back and renderLedger() picks it up, same as every other job update.
async function cancelEncodeJob(id) {
  await fetch("/api/encode/jobs/cancel", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ job_id: id }),
  });
}

openConvertedBtn.addEventListener("click", async () => {
  ledgerMoreMenu.classList.add("hidden");
  try {
    const res = await fetch("/api/encode/open-converted-folder", { method: "POST" });
    const data = await res.json();
    if (!res.ok) flashStatus(data.error || "Couldn't open the folder.");
  } catch (e) {
    flashStatus("Couldn't reach the server.");
  }
});

// ── New Encode Job modal ────────────────────────────────────────
async function loadEncodePresets(selectedName = "") {
  try {
    const res = await fetch("/api/encode/presets");
    const data = await res.json();
    encodeSavedPresets = Array.isArray(data.presets) ? data.presets : [];
  } catch (e) {
    encodeSavedPresets = [];
  }
  encodeSavedPresetSelect.innerHTML = "";
  const placeholder = document.createElement("option");
  placeholder.value = "";
  placeholder.textContent = encodeSavedPresets.length ? "Saved presets" : "No saved presets";
  encodeSavedPresetSelect.appendChild(placeholder);
  for (const preset of encodeSavedPresets) {
    const opt = document.createElement("option");
    opt.value = preset.name;
    opt.textContent = preset.name;
    encodeSavedPresetSelect.appendChild(opt);
  }
  encodeSavedPresetSelect.value = selectedName && encodeSavedPresets.some(p => p.name === selectedName) ? selectedName : "";
  updateEncodePresetButtons();
}

function updateEncodePresetButtons() {
  const hasSelection = !!encodeSavedPresetSelect.value;
  encodePresetEditBtn.disabled = !hasSelection;
  encodePresetDeleteBtn.disabled = !hasSelection;
}

function encodePresetOptions() {
  return { ...collectEncodeOptions() };
}

async function saveEncodePreset(name, replaceName = null) {
  name = String(name || "").trim();
  if (!name) return false;
  try {
    const res = await fetch("/api/encode/presets", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, options: encodePresetOptions() }),
    });
    const data = await res.json();
    if (!res.ok) {
      flashStatus(data.error || "Couldn't save the encoding preset.");
      return false;
    }
    if (replaceName && replaceName !== name) {
      await fetch("/api/encode/presets/delete", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: replaceName }),
      });
    }
    await loadEncodePresets(name);
    return true;
  } catch (e) {
    flashStatus("Couldn't reach the server.");
    return false;
  }
}

async function applyEncodePreset(name) {
  const preset = encodeSavedPresets.find(p => p.name === name);
  if (!preset?.options) return;
  const o = preset.options;

  if (o.codec) {
    encodeCodecSelect.value = o.codec;
    onEncodeCodecChange();
  }
  if (o.encoder_backend && [...encodeBackendSelect.options].some(x => x.value === o.encoder_backend)) {
    encodeBackendSelect.value = o.encoder_backend;
  }
  if (o.crf != null) {
    encodeCrfSlider.value = o.crf;
    encodeCrfValue.textContent = o.crf;
  }
  if (o.preset != null && [...encodePresetSelect.options].some(x => x.value === String(o.preset))) encodePresetSelect.value = o.preset;
  if (o.resolution_cap) encodeResolutionSelect.value = o.resolution_cap;
  if (o.audio_mode) encodeAudioSelect.value = o.audio_mode;
  if (o.subtitles_mode) encodeSubtitlesSelect.value = o.subtitles_mode;
  if (o.container) encodeContainerSelect.value = o.container;
  if (o.oversized_behavior) encodeOversizedSelect.value = o.oversized_behavior;
  if (o.target_size_mb != null) encodeTargetSizeInput.value = o.target_size_mb; else encodeTargetSizeInput.value = "";
  encodeDeinterlaceCheck.checked = !!o.deinterlace;
  encodeAutocropCheck.checked = !!o.auto_crop;
  encodeDenoiseCheck.checked = !!o.denoise;
  encodeForceArCheck.checked = !!o.force_ar;
  encodeArWidthInput.value = o.force_ar_width ?? "";
  encodeArHeightInput.value = o.force_ar_height ?? "";

  encodeAspectQuickRow.querySelectorAll(".aspect-quick-btn").forEach(btn => {
    btn.classList.toggle("active", !!o.force_ar && btn.dataset.ratio === o.force_ar_label);
  });
  if (o.mode === "size") {
    setEncodeMode("size");
  } else {
    setEncodeMode("crf");
  }
  requestEncodeEstimate();
}

encodeSavedPresetSelect.addEventListener("change", () => {
  updateEncodePresetButtons();
  if (encodeSavedPresetSelect.value) applyEncodePreset(encodeSavedPresetSelect.value);
});

encodePresetAddBtn.addEventListener("click", async () => {
  const name = window.prompt("Preset name:");
  if (name) await saveEncodePreset(name);
});

encodePresetEditBtn.addEventListener("click", async () => {
  const oldName = encodeSavedPresetSelect.value;
  if (!oldName) return;
  const name = window.prompt("Preset name:", oldName);
  if (name) await saveEncodePreset(name, oldName);
});

encodePresetDeleteBtn.addEventListener("click", async () => {
  const name = encodeSavedPresetSelect.value;
  if (!name || !window.confirm(`Delete encoding preset "${name}"?`)) return;
  try {
    const res = await fetch("/api/encode/presets/delete", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name }),
    });
    const data = await res.json();
    if (!res.ok) {
      flashStatus(data.error || "Couldn't delete the encoding preset.");
      return;
    }
    encodeSavedPresets = Array.isArray(data.presets) ? data.presets : [];
    await loadEncodePresets();
  } catch (e) {
    flashStatus("Couldn't reach the server.");
  }
});

function presetOptionsFor(kind) {
  if (kind === "x26x") {
    return ["ultrafast", "superfast", "veryfast", "faster", "fast", "medium", "slow", "slower", "veryslow"]
      .map((p) => [p, p]);
  }
  if (kind === "svt") {
    // libsvtav1: 0 (best/slowest) .. 13 (fastest)
    return [["2", "2 (slow, best)"], ["4", "4"], ["6", "6 (balanced)"], ["8", "8"], ["10", "10"], ["12", "12 (fast)"]];
  }
  if (kind === "vpx") {
    // libvpx-vp9 -cpu-used: 0 (best/slowest) .. 5 (fastest)
    return [["0", "0 (slow, best)"], ["1", "1"], ["2", "2 (balanced)"], ["3", "3"], ["4", "4"], ["5", "5 (fast)"]];
  }
  return [];
}

function populateEncodeCodecSelect() {
  encodeCodecSelect.innerHTML = "";
  if (!state.encodeCapabilities) return;
  for (const [key, def] of Object.entries(state.encodeCapabilities.codecs)) {
    const opt = document.createElement("option");
    opt.value = key;
    opt.textContent = def.label;
    encodeCodecSelect.appendChild(opt);
  }
  encodeCodecSelect.value = "h265";
}

function populateEncodeResolutionSelect() {
  encodeResolutionSelect.innerHTML = "";
  const caps = (state.encodeCapabilities && state.encodeCapabilities.resolution_caps)
    || ["source", "2160p", "1440p", "1080p", "720p", "480p"];
  for (const cap of caps) {
    const opt = document.createElement("option");
    opt.value = cap;
    opt.textContent = cap === "source" ? "Source (no downscale)" : cap;
    encodeResolutionSelect.appendChild(opt);
  }
}

function applyActiveAspectRatio() {
  const activeBtn = encodeAspectQuickRow.querySelector(".aspect-quick-btn.active");
  if (!activeBtn || activeBtn.dataset.ratio === "Custom" || !state.encodeSourceInfo) return;
  const [rw, rh] = activeBtn.dataset.ratio.split(":").map(Number);
  const h = state.encodeSourceInfo.height;
  encodeArHeightInput.value = h;
  encodeArWidthInput.value = Math.round((h * (rw / rh)) / 2) * 2; // keep it even
}

function populateAspectQuickRow() {
  encodeAspectQuickRow.innerHTML = "";
  const ratios = (state.encodeCapabilities && state.encodeCapabilities.aspect_ratios) || ["16:9", "4:3", "21:9"];
  for (const ratio of [...ratios, "Custom"]) {
    const btn = document.createElement("div");
    btn.className = "aspect-quick-btn";
    btn.textContent = ratio;
    btn.dataset.ratio = ratio;
    btn.addEventListener("click", () => {
      encodeAspectQuickRow.querySelectorAll(".aspect-quick-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      applyActiveAspectRatio();
      // The preset row is always visible now (not gated behind the
      // checkbox), so picking a ratio here is itself the signal that
      // the user wants it forced - flip the checkbox on to match.
      if (!encodeForceArCheck.checked) {
        encodeForceArCheck.checked = true;
      }
      requestEncodeEstimate();
    });
    encodeAspectQuickRow.appendChild(btn);
  }
  encodeAspectQuickRow.firstChild?.classList.add("active");
}

function onEncodeCodecChange() {
  const codec = encodeCodecSelect.value;
  const def = state.encodeCapabilities?.codecs?.[codec];
  if (!def) return;

  encodeBackendSelect.innerHTML = "";
  for (const backend of def.available_backends) {
    const opt = document.createElement("option");
    opt.value = backend;
    opt.textContent = backend === "software" ? "Software (recommended)" : `${backend.toUpperCase()} (hardware, faster, larger files)`;
    encodeBackendSelect.appendChild(opt);
  }
  encodeBackendSelect.value = "software";

  const [crfMin, crfMax] = def.crf_range;
  encodeCrfSlider.min = crfMin;
  encodeCrfSlider.max = crfMax;
  encodeCrfSlider.value = def.default_crf;
  encodeCrfValue.textContent = def.default_crf;
  encodeCrfHint.textContent = `Lower = higher quality, bigger file. This codec's typical default is ${def.default_crf}.`;

  encodePresetSelect.innerHTML = "";
  for (const [value, label] of presetOptionsFor(def.preset_kind)) {
    const opt = document.createElement("option");
    opt.value = value;
    opt.textContent = label;
    encodePresetSelect.appendChild(opt);
  }
  encodePresetSelect.value = def.default_preset;

  encodeContainerSelect.value = def.container_default;

  requestEncodeEstimate();
}
encodeCodecSelect.addEventListener("change", onEncodeCodecChange);
encodeBackendSelect.addEventListener("change", requestEncodeEstimate);
encodePresetSelect.addEventListener("change", requestEncodeEstimate);
encodeResolutionSelect.addEventListener("change", requestEncodeEstimate);
encodeAudioSelect.addEventListener("change", requestEncodeEstimate);
encodeDenoiseCheck.addEventListener("change", requestEncodeEstimate);
encodeCrfSlider.addEventListener("input", () => {
  encodeCrfValue.textContent = encodeCrfSlider.value;
  requestEncodeEstimate();
});
encodeTargetSizeInput.addEventListener("input", requestEncodeEstimate);

encodeForceArCheck.addEventListener("change", () => {
  requestEncodeEstimate();
});

encodeModeCrfBtn.addEventListener("click", () => setEncodeMode("crf"));
encodeModeSizeBtn.addEventListener("click", () => setEncodeMode("size"));
function setEncodeMode(mode) {
  encodeModeCrfBtn.classList.toggle("active", mode === "crf");
  encodeModeSizeBtn.classList.toggle("active", mode === "size");
  encodeCrfFields.style.display = mode === "crf" ? "block" : "none";
  encodeSizeFields.style.display = mode === "size" ? "block" : "none";
  requestEncodeEstimate();
}

function currentSourceRequestBody() {
  return state.encodeModalFilename ? { filename: state.encodeModalFilename } : null;
}

async function probeSelectedSource() {
  const body = currentSourceRequestBody();
  if (!body) return;
  // Guard against out-of-order responses: if the user switches from a
  // slow-to-probe file (e.g. a large newly-pasted one) to another file
  // before the first probe returns, an older response arriving after a
  // newer one must not overwrite the display with the wrong file's info.
  const mySeq = ++state.encodeProbeSeq;
  encodeSourceInfo.textContent = "Probing source file...";
  try {
    const res = await fetch("/api/encode/probe", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (mySeq !== state.encodeProbeSeq) return; // superseded by a newer selection
    if (!res.ok) {
      state.encodeSourceInfo = null;
      encodeSourceInfo.textContent = data.error || "Couldn't read that file.";
      encodeEstimateOriginal.textContent = "-";
      encodeEstimateValue.textContent = "-";
      encodeEstimateSavings.textContent = "-";
      return;
    }
    state.encodeSourceInfo = data;
    encodeSourceInfo.textContent = `${data.width}×${data.height} · ${formatDuration(data.duration)} · ${data.size_label}`;
    encodeResolutionLabel.textContent = `Resolution cap (downscale only) — source is ${data.width}×${data.height}`;
    encodeEstimateOriginal.textContent = data.size_label || "-";
    encodeEstimateSavings.textContent = "-";
    encodeArWidthInput.value = data.width;
    encodeArHeightInput.value = data.height;
    applyActiveAspectRatio();
    requestEncodeEstimate();
  } catch (e) {
    if (mySeq !== state.encodeProbeSeq) return; // superseded by a newer selection
    state.encodeSourceInfo = null;
    encodeSourceInfo.textContent = "Couldn't reach the server to probe that file.";
  }
}

function collectEncodeOptions() {
  const mode = encodeModeCrfBtn.classList.contains("active") ? "crf" : "size";
  const activeRatioBtn = encodeAspectQuickRow.querySelector(".aspect-quick-btn.active");
  return {
    mode,
    codec: encodeCodecSelect.value,
    encoder_backend: encodeBackendSelect.value,
    crf: parseInt(encodeCrfSlider.value, 10),
    preset: encodePresetSelect.value,
    target_size_mb: encodeTargetSizeInput.value ? parseFloat(encodeTargetSizeInput.value) : null,
    resolution_cap: encodeResolutionSelect.value,
    force_ar: encodeForceArCheck.checked,
    force_ar_label: activeRatioBtn ? activeRatioBtn.dataset.ratio : "",
    force_ar_width: encodeForceArCheck.checked ? (parseInt(encodeArWidthInput.value, 10) || null) : null,
    force_ar_height: encodeForceArCheck.checked ? (parseInt(encodeArHeightInput.value, 10) || null) : null,
    deinterlace: encodeDeinterlaceCheck.checked,
    auto_crop: encodeAutocropCheck.checked,
    denoise: encodeDenoiseCheck.checked,
    audio_mode: encodeAudioSelect.value,
    subtitles_mode: encodeSubtitlesSelect.value,
    container: encodeContainerSelect.value,
    oversized_behavior: encodeOversizedSelect.value,
  };
}

let encodeEstimateTimer = null;
function requestEncodeEstimate() {
  clearTimeout(encodeEstimateTimer);
  encodeEstimateTimer = setTimeout(doRequestEncodeEstimate, 250);
}

encodeEstimateRefreshBtn.addEventListener("click", async () => {
  clearTimeout(encodeEstimateTimer);
  encodeEstimateRefreshBtn.classList.remove("spinning");
  void encodeEstimateRefreshBtn.offsetWidth; // restart animation if clicked repeatedly
  encodeEstimateRefreshBtn.classList.add("spinning");
  // If a previous probe failed or never landed (e.g. a manually-pasted
  // file that was still being copied when it was first selected),
  // state.encodeSourceInfo is null and doRequestEncodeEstimate() would
  // silently no-op below - leaving the estimate stuck with no visible
  // feedback even though the user just pressed Refresh. Re-probe the
  // source first so a since-completed copy (or any other transient
  // failure) gets picked up instead of refusing to update forever.
  if (!state.encodeSourceInfo) await probeSelectedSource();
  doRequestEncodeEstimate();
});

async function doRequestEncodeEstimate() {
  const sourceBody = currentSourceRequestBody();
  if (!sourceBody || !state.encodeSourceInfo) return;
  const mySeq = ++state.encodeEstimateSeq;
  const options = collectEncodeOptions();
  encodeEstimateLabel.textContent = options.mode === "size" ? "Target" : "Estimated";
  try {
    const res = await fetch("/api/encode/estimate", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...sourceBody, options }),
    });
    const data = await res.json();
    if (mySeq !== state.encodeEstimateSeq) return; // superseded by a newer request
    if (!res.ok) {
      encodeEstimateValue.textContent = "-";
      encodeEstimateSavings.textContent = "-";
      return;
    }
    const prefix = options.mode === "size" ? "" : "~";
    encodeEstimateValue.textContent = data.estimated_size_label ? `${prefix}${data.estimated_size_label}` : "-";

    const sourceBytes = state.encodeSourceInfo?.size_bytes;
    encodeEstimateSavings.classList.remove("good", "bad");
    if (sourceBytes && data.estimated_bytes) {
      const pct = Math.round((1 - data.estimated_bytes / sourceBytes) * 100);
      encodeEstimateSavings.textContent = pct >= 0 ? `-${pct}%` : `+${Math.abs(pct)}%`;
      encodeEstimateSavings.classList.add(pct >= 0 ? "good" : "bad");
    } else {
      encodeEstimateSavings.textContent = "-";
    }
  } catch (e) {
    if (mySeq === state.encodeEstimateSeq) {
      encodeEstimateValue.textContent = "-";
      encodeEstimateSavings.textContent = "-";
    }
  }
}

async function openNewEncodeJobModal(filename) {
  encodeJobError.classList.add("hidden");
  if (!state.encodeCapabilities) await loadEncodeCapabilities();
  await loadEncodePresets();

  state.encodeModalFilename = filename;
  encodeSourceDisplay.textContent = filename;

  populateEncodeCodecSelect();
  populateEncodeResolutionSelect();
  populateAspectQuickRow();

  encodeEstimateOriginal.textContent = "-";
  encodeEstimateValue.textContent = "-";
  encodeEstimateSavings.textContent = "-";
  encodeEstimateSavings.classList.remove("good", "bad");
  encodeForceArCheck.checked = false;
  encodeArWidthInput.value = "";
  encodeArHeightInput.value = "";
  encodeDeinterlaceCheck.checked = false;
  encodeAutocropCheck.checked = false;
  encodeDenoiseCheck.checked = false;
  encodeAudioSelect.value = "copy";
  encodeSubtitlesSelect.value = "copy";
  encodeOversizedSelect.value = "flag";
  encodeTargetSizeInput.value = "";
  setEncodeMode("crf");

  onEncodeCodecChange();
  await probeSelectedSource();

  newEncodeJobModal.classList.remove("hidden");
  const modalBox = newEncodeJobModal.querySelector(".modal-box");
  if (modalBox) modalBox.scrollTop = 0;
}

function closeNewEncodeJobModal() {
  newEncodeJobModal.classList.add("hidden");
}

closeEncodeJobModalBtn.addEventListener("click", closeNewEncodeJobModal);
cancelEncodeJobModalBtn.addEventListener("click", closeNewEncodeJobModal);
newEncodeJobModal.addEventListener("click", (e) => { if (e.target === newEncodeJobModal) closeNewEncodeJobModal(); });

addEncodeJobBtn.addEventListener("click", async () => {
  encodeJobError.classList.add("hidden");
  const sourceBody = currentSourceRequestBody();
  if (!sourceBody) {
    encodeJobError.textContent = "Choose a source file first.";
    encodeJobError.classList.remove("hidden");
    return;
  }
  const options = collectEncodeOptions();
  if (options.mode === "size" && !options.target_size_mb) {
    encodeJobError.textContent = "Enter a target size in MB.";
    encodeJobError.classList.remove("hidden");
    return;
  }

  addEncodeJobBtn.disabled = true;
  try {
    const res = await fetch("/api/encode/jobs", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...sourceBody, options }),
    });
    const data = await res.json();
    if (!res.ok) {
      encodeJobError.textContent = data.error || "Couldn't queue that job.";
      encodeJobError.classList.remove("hidden");
      return;
    }
    state.encodeJobs.set(data.job.id, data.job);
    renderLedger();
    closeNewEncodeJobModal();
  } catch (e) {
    encodeJobError.textContent = "Couldn't reach the server.";
    encodeJobError.classList.remove("hidden");
  } finally {
    addEncodeJobBtn.disabled = false;
  }
});

boot();
