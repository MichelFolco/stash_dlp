"""Thin GraphQL client for pushing completed downloads into Stash
(https://github.com/stashapp/stash): trigger a targeted library scan on
the moved file, wait for the resulting Scene to appear, then write the
original source URL onto it.

Schema note: this targets the modern Stash schema, where Scene.urls is
a string list. Older Stash releases (pre the url -> urls migration)
used a single Scene.url string field instead - if sceneUpdate below
comes back with a GraphQL error mentioning an unknown "urls" field,
your Stash predates that change and set_scene_url() needs `url` (a
plain string, not a list) instead. Easiest way to check: open your
Stash's built-in GraphQL playground at <stash_url>/playground and look
at the Scene type's fields.
"""
import asyncio
import os

import httpx

from settings import get_stash_url, get_stash_api_key

SCAN_POLL_INTERVAL = 1.5
SCAN_POLL_TIMEOUT = 60
REQUEST_TIMEOUT = 30


class StashError(Exception):
    """Raised for anything that stops a file from being fully handed
    off to Stash - not configured, unreachable, a GraphQL error, or the
    scanned file never showing up as a Scene in time."""
    pass


def _endpoint() -> str:
    url = get_stash_url()
    if not url:
        raise StashError("No Stash URL configured yet.")
    return f"{url}/graphql"


async def _graphql(query: str, variables: dict) -> dict:
    headers = {"Content-Type": "application/json"}
    api_key = get_stash_api_key()
    if api_key:
        headers["ApiKey"] = api_key

    try:
        async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as client:
            resp = await client.post(_endpoint(), json={"query": query, "variables": variables}, headers=headers)
    except httpx.RequestError as e:
        raise StashError(f"Couldn't reach Stash: {e}")

    if resp.status_code >= 400:
        raise StashError(f"Stash returned HTTP {resp.status_code}.")

    try:
        payload = resp.json()
    except ValueError:
        raise StashError("Stash returned a non-JSON response.")

    if payload.get("errors"):
        raise StashError(payload["errors"][0].get("message", "Stash GraphQL error."))
    return payload.get("data", {})


async def trigger_scan(paths: list) -> None:
    """Kicks off a targeted library scan on just the given path(s), so
    Stash doesn't have to rescan the whole library for one new file."""
    query = """
        mutation ScanFile($paths: [String!]) {
          metadataScan(input: { paths: $paths })
        }
    """
    await _graphql(query, {"paths": paths})


async def find_scene_id_by_path(file_path: str) -> str:
    """Returns the Scene id for an exact file path, or '' if Stash
    hasn't picked it up (yet)."""
    query = """
        query FindScene($path: String!) {
          findScenes(scene_filter: { path: { value: $path, modifier: EQUALS } }) {
            scenes { id }
          }
        }
    """
    data = await _graphql(query, {"path": file_path})
    scenes = (data.get("findScenes") or {}).get("scenes") or []
    return scenes[0]["id"] if scenes else ""


async def wait_for_scene(file_path: str, timeout: float = SCAN_POLL_TIMEOUT) -> str:
    """Polls for the Scene Stash creates for file_path after a scan.
    Raises StashError if it doesn't show up within timeout - the scan
    job itself is async on Stash's side, so this is the only reliable
    way to know when it's actually done without wiring up Stash's
    separate job-subscription API."""
    elapsed = 0.0
    while elapsed < timeout:
        scene_id = await find_scene_id_by_path(file_path)
        if scene_id:
            return scene_id
        await asyncio.sleep(SCAN_POLL_INTERVAL)
        elapsed += SCAN_POLL_INTERVAL
    raise StashError("Timed out waiting for Stash to import the file.")


async def set_scene_url(scene_id: str, url: str) -> None:
    query = """
        mutation SetSceneUrl($id: ID!, $urls: [String!]) {
          sceneUpdate(input: { id: $id, urls: $urls }) { id }
        }
    """
    await _graphql(query, {"id": scene_id, "urls": [url]})


async def send_completed_file(file_path: str, source_url: str) -> str:
    """Full pipeline: scan -> wait for the Scene -> tag it with the
    source URL. Returns the new Scene's id. Raises StashError on any
    failure - callers should catch this and surface it as a soft
    warning, since by the time this runs the file has already been
    moved successfully regardless of whether Stash cooperates.

    Scans the file's containing folder rather than the exact file path:
    metadataScan is built around scanning library directories, and a
    single filename may not resolve to anything even though Stash picks
    the same file up fine on a manual "Scan" from its own UI."""
    folder = os.path.dirname(file_path)
    await trigger_scan([folder])
    scene_id = await wait_for_scene(file_path)
    if source_url:
        await set_scene_url(scene_id, source_url)
    return scene_id
