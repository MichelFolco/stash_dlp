@echo off
cd /d "%~dp0"
set STASH_DLP_HOST=0.0.0.0
rem Use "start" so this .bat's terminal window closes immediately.
rem Running pythonw in the foreground here used to keep a blank,
rem never-updated terminal window open for the whole session.
rem The tray (and the server it starts) inherit STASH_DLP_HOST above.
start "" pythonw tray_launcher.py
exit /b
