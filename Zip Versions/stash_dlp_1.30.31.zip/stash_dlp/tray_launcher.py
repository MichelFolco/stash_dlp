"""StashDLP Windows system-tray launcher.

The launcher deliberately does not reimplement the FastAPI/uvicorn startup.
It starts the existing backend/main.py as a separate process and only owns
that process's lifetime and the tray UI.

Why there is no console window any more (v1.30.31): the old launcher ran the
server with CREATE_NEW_CONSOLE and then hid that console via
AttachConsole()/GetConsoleWindow()/ShowWindow(SW_HIDE) so the tray menu
could show/hide it. On Windows 11 machines whose default terminal app is
Windows Terminal, GetConsoleWindow() does not return the real terminal
window - it returns a proxy handle - and ShowWindow() on it leaves the
actual Windows Terminal window transparent and unresponsive (a "ghost"
window whose content never paints). The .bat files made it two windows:
they ran ``pythonw tray_launcher.py`` in the foreground, so the .bat's own
terminal window also stayed open for the whole session even though nothing
ever printed to it.

The fix removes console manipulation entirely: the server now runs with
CREATE_NO_WINDOW and its stdout/stderr go to tray_launcher.log next to
this file. The tray's "Show Console Log" menu item opens a small viewer
window (owned by this launcher, tailing that log file) - that is where
the terminal content is displayed now. It works the same regardless of
the machine's default terminal app.
"""
from __future__ import annotations

import ctypes
import os
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path

import pystray
from PIL import Image

from backend.config import PORT

PROJECT_ROOT = Path(__file__).resolve().parent
APP_NAME = "Stash DLP Web"
APP_URL = f"http://127.0.0.1:{PORT}"
APP_ENTRY = PROJECT_ROOT / "backend" / "main.py"
LOGO_PATH = PROJECT_ROOT / "static" / "logo.png"
LOG_PATH = PROJECT_ROOT / "tray_launcher.log"

ERROR_ALREADY_EXISTS = 183

kernel32 = ctypes.windll.kernel32
kernel32.CreateMutexW.restype = ctypes.c_void_p
kernel32.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_bool, ctypes.c_wchar_p]
kernel32.GetLastError.restype = ctypes.c_uint32


class TrayLauncher:
    def __init__(self) -> None:
        self.process: subprocess.Popen | None = None
        self.icon: pystray.Icon | None = None
        self._stopping = False
        self._log_file = None
        self._mutex_handle = None
        self._viewer_thread: threading.Thread | None = None
        self._viewer_raise_requests = 0

    # ------------------------------------------------------------------
    # Server process
    # ------------------------------------------------------------------
    def start_server(self) -> None:
        if self.process is not None and self.process.poll() is None:
            return

        # This is the app's existing startup entry point. The server itself
        # still calls uvicorn.run(...); this launcher does not duplicate it.
        python_exe = Path(sys.executable)
        if python_exe.name.lower() == "pythonw.exe":
            python_exe = python_exe.with_name("python.exe")
        command = [str(python_exe), str(APP_ENTRY)]

        # The server gets NO console window at all, so there is nothing for
        # Windows Terminal / conhost to turn into a ghost window. Its
        # output is not lost: stdout and stderr both go to the log file,
        # which the tray's "Show Console Log" viewer tails.
        env = os.environ.copy()
        # Without this, the child's stdout is block-buffered when it is a
        # file instead of a tty, and log lines would only show up in
        # large delayed chunks.
        env["PYTHONUNBUFFERED"] = "1"

        log_target = subprocess.DEVNULL
        try:
            self._log_file = open(LOG_PATH, "a", encoding="utf-8", buffering=1)
            self._log_file.write(
                "\n--- StashDLP server starting {} ---\n".format(
                    time.strftime("%Y-%m-%d %H:%M:%S")
                )
            )
            log_target = self._log_file
        except OSError:
            self._log_file = None

        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        self.process = subprocess.Popen(
            command,
            cwd=str(PROJECT_ROOT),
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=log_target,
            stderr=subprocess.STDOUT,
            creationflags=creationflags,
        )

    def stop_server(self) -> None:
        process = self.process
        self.process = None
        if process and process.poll() is None:
            # main.py uses reload=False, so there is no uvicorn supervisor
            # tree. Still use taskkill /T as a defensive Windows
            # process-tree cleanup.
            try:
                subprocess.run(
                    ["taskkill", "/PID", str(process.pid), "/T", "/F"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    check=False,
                )
            except OSError:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
        if self._log_file is not None:
            try:
                self._log_file.close()
            except OSError:
                pass
            self._log_file = None

    def restart_server(self, _icon=None, _item=None) -> None:
        self.stop_server()
        if not self._stopping:
            self.start_server()

    # ------------------------------------------------------------------
    # Console-log viewer (replaces the old Show/Hide Console)
    # ------------------------------------------------------------------
    def show_console_log(self, _icon=None, _item=None) -> None:
        self._viewer_raise_requests += 1
        if self._viewer_thread is not None and self._viewer_thread.is_alive():
            return  # already open; the viewer notices the raise request
        self._viewer_thread = threading.Thread(
            target=self._run_log_viewer, name="StashDLPLogViewer", daemon=True
        )
        self._viewer_thread.start()

    def _run_log_viewer(self) -> None:
        # All tkinter calls stay on this thread; the tray callbacks above
        # only bump a counter that this thread's poll loop picks up.
        try:
            import tkinter as tk
        except Exception:
            # tkinter ships with python.org Windows builds, so this is
            # only a fallback: at least show the content in Notepad.
            try:
                subprocess.Popen(["notepad.exe", str(LOG_PATH)])
            except OSError:
                pass
            return

        root = tk.Tk()
        root.title(f"{APP_NAME} - Server Log")
        root.geometry("900x520")

        frame = tk.Frame(root)
        frame.pack(fill="both", expand=True)
        scrollbar = tk.Scrollbar(frame)
        scrollbar.pack(side="right", fill="y")
        text = tk.Text(
            frame,
            wrap="none",
            state="disabled",
            yscrollcommand=scrollbar.set,
            font=("Consolas", 10),
        )
        text.pack(side="left", fill="both", expand=True)
        scrollbar.config(command=text.yview)

        # First load shows at most the tail of the log so a long-lived
        # file doesn't make the viewer slow to open.
        try:
            offset = max(0, LOG_PATH.stat().st_size - 200_000)
        except OSError:
            offset = 0
        seen_raise = self._viewer_raise_requests
        first_load = offset > 0

        def _poll() -> None:
            nonlocal offset, seen_raise, first_load
            try:
                with open(LOG_PATH, "r", encoding="utf-8", errors="replace") as fh:
                    fh.seek(offset)
                    if first_load:
                        fh.readline()  # drop the partial first line
                        first_load = False
                    chunk = fh.read()
                    offset = fh.tell()
                if chunk:
                    at_bottom = text.yview()[1] >= 0.999
                    text.configure(state="normal")
                    text.insert("end", chunk)
                    text.configure(state="disabled")
                    if at_bottom:
                        text.see("end")
            except OSError:
                pass
            if self._viewer_raise_requests != seen_raise:
                seen_raise = self._viewer_raise_requests
                try:
                    root.deiconify()
                    root.lift()
                    root.focus_force()
                except tk.TclError:
                    return
            try:
                root.after(500, _poll)
            except tk.TclError:
                pass  # window was closed

        _poll()
        root.mainloop()

    # ------------------------------------------------------------------
    # Tray UI
    # ------------------------------------------------------------------
    def open_app(self, _icon=None, _item=None) -> None:
        webbrowser.open(APP_URL)

    def quit(self, _icon=None, _item=None) -> None:
        self._stopping = True
        self.stop_server()
        if self.icon:
            self.icon.stop()

    def build_icon(self) -> pystray.Icon:
        image = Image.open(LOGO_PATH).convert("RGBA")
        menu = pystray.Menu(
            pystray.MenuItem(f"Open {APP_NAME}", self.open_app, default=True),
            pystray.MenuItem("Show Console Log", self.show_console_log),
            pystray.MenuItem("Restart Server", self.restart_server),
            pystray.MenuItem("Quit", self.quit),
        )
        self.icon = pystray.Icon("StashDLP", image, APP_NAME, menu)
        return self.icon

    def run(self) -> None:
        # Single instance: launching the .bat again while the tray is
        # already running used to start a second server, which then
        # failed to bind the port and left another stray window behind.
        self._mutex_handle = kernel32.CreateMutexW(
            None, False, "Local\\StashDLP-TrayLauncher"
        )
        if kernel32.GetLastError() == ERROR_ALREADY_EXISTS:
            return
        self.start_server()
        icon = self.build_icon()
        icon.run()


if __name__ == "__main__":
    TrayLauncher().run()
