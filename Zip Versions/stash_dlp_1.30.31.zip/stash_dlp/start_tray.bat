@echo off
cd /d "%~dp0"
rem Use "start" so this .bat's terminal window closes immediately.
rem Running pythonw in the foreground here used to keep a blank,
rem never-updated terminal window open for the whole session.
start "" pythonw tray_launcher.py
exit /b
